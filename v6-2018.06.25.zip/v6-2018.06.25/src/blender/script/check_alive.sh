#!/bin/sh

export APP_NAME=blender_server
export APP_PATH=/export/App/jd_search/blender/server
source ${APP_PATH}/monitor/fun.sh

pid=`get_pid $APP_NAME`
if [ "x" != "x${pid}" ]; then
    echo "$APP_NAME is running :${pid}"
else
    SeverAlarm 'search.blender.running.call' "check_alive:$APP_NAME is not running!!" 
    sh $APP_PATH/bin/start.sh
fi

