#include <boost/lexical_cast.hpp> 
#include <iostream>
#include "blender_parser.h"
#include "blender_header.h"
#include "i_command_parser.h"
#include "def.h"
#include "Qtags.h"
#include "blender_config.h"
#include "not_personalkey_data.h"
#include "str_util.h"
#include "blender_config_data.h"
#include "client2env_data.h"
BLENDER_BEGIN;
using namespace search_frame;

#define BLD_TRANS_STRING_PARAM(pb_param, url_param, default_value)\
{\
    std::string tmpvalue = url_parser.ParseString(url, url_param, default_value);\
    query->set_##pb_param(tmpvalue);\
}

#define BLD_TRANS_STRING_PARAM_CAPITAL(pb_param, url_param, default_value)\
{\
    std::string tmpvalue = url_parser.ParseString(url, url_param, default_value, true);\
    query->set_##pb_param(tmpvalue);\
}

#define BLD_TRANS_STRING_PARAM_IF(pb_param, url_param)\
{\
    std::string tmpvalue = url_parser.ParseString(url, url_param, "");\
    if ( !tmpvalue.empty() ) {\
        query->set_##pb_param(tmpvalue);\
    }\
}

#define BLD_TRANS_STRING_PARAM_IF_CAPITAL(pb_param, url_param)\
{\
    std::string tmpvalue = url_parser.ParseString(url, url_param, "", true);\
    if ( !tmpvalue.empty() ) {\
        query->set_##pb_param(tmpvalue);\
    }\
}

#define BLD_TRANS_INT_PARAM(pb_param, url_param, default_value)\
{\
    int tmpvalue = url_parser.ParseInteger(url, url_param, default_value);\
    query->set_##pb_param(tmpvalue);\
}

#define BLD_TRANS_INT_PARAM_IF(pb_param, url_param)\
{\
    std::string tmpvalue = url_parser.ParseString(url, url_param, "");\
    if ( !tmpvalue.empty() ) {\
        try{\
            query->set_##pb_param(boost::lexical_cast<int>(tmpvalue));\
        }catch(...)\
        {\
        }\
    }\
}

#define BLD_TRANS_BOOL_PARAM(pb_param, url_param, default_value)\
{\
    std::string tmpvalue = url_parser.ParseString(url, url_param, default_value);\
    query->set_##pb_param( tmpvalue == "yes" );\
}

#define BLD_TRANS_BOOL_PARAM_IF(pb_param, url_param)\
{\
    std::string tmpvalue = url_parser.ParseString(url, url_param, "");\
    if ( !tmpvalue.empty() ) {\
        query->set_##pb_param(tmpvalue == "yes");\
    }\
}

void BlenderParser::parseUrl(const std::string &url, blender::BlenderAnalysisData *analysisData) 
{
    jd::search::request::JdSearchQuery *query = analysisData->query();
    jd::search::request::QPRequest *qp_query = analysisData->qpQuery(); 
    I_CommandParser url_parser;

    MsTimer stTimer;
    stTimer.Start();
    query->set__client_id( url_parser.ParseString(url, "client", "") );   //µ÷ÓÃ·½±êÊ¶
    query->set__req_type( url_parser.ParseInteger(url, "client", 0) );    //ÇëÇóÀàÐÍ:ÕÅÑåÉý
    query->set__time_out( url_parser.ParseInteger(url, "time_out", 5000) );  //³¬Ê±ÉèÖÃms

    analysisData->m_env = Client2EnvData::getInstance()->caller_env( query->_client_id() );
    analysisData->setBlenderConf ( BlenderConfigData::getInstance(analysisData->m_env, true) );

    string key = url_parser.ParseQueryKey(url);
    if ( key.size() > (unsigned int)_blender_conf->m_g_key_length_limit )
    {
        query->set__key( key );                    //²éÑ¯´Ê
        return;
    }

    query->set__original_key( key );                //Ô­Ê¼²éÑ¯´Ê
    query->set__key( key );                    //²éÑ¯´Ê

    std::string expression_key = url_parser.ParseString(url, EXPRESSION_KEY_PARA, DEFAULT_EXPRESSION_KEY_VALUE);
    query->set__expression_key( expression_key );                   //É¸Ñ¡´Ê
    
    //query->set__expand_key( m_expand_key );                  //À©Õ¹´Ê:QP
    //query->set__normalized_key( m_normalized_query );                  //±ê×¼»¯´Ê:QP
    query->set__sir_key( url_parser.ParseString(url, SEARCH_IN_RESULTS_KEY_PARA, DEFAULT_SEARCH_IN_RESULTS_KEY_VALUE) );                    //ÔÚ½á¹ûÖÐÔÙËÑË÷´Ê

    //query->//JdQueryKeyInfo _key_items_info(  );                   //²éÑ¯´ÊÓï·¨Ê÷
    //query->//JdQueryKeyInfo _expression_key_items_info(  );                  //É¸Ñ¡´ÊÓï·¨Ê÷
    //query->//JdQueryKeyInfo _normalized_key_items_info(  );                  //±ê×¼»¯´ÊÓï·¨Ê÷
    //query->//JdQueryKeyInfo _expand_key_items_info(  );                 //À©Õ¹´ÊÓï·¨Ê÷
    //query->//JdQueryKeyInfo _sir_key_items_info(  );                    //ÔÙËÑË÷´ÊÓï·¨Ê÷

    string tmp_user_pin = url_parser.ParseString(url,"user_pin","",true);

    if(_blender_conf->m_g_url_key_whitelist_valid )
    {
        string newkey; 
        clsGlobal::promotion_normalize(query->_key(), newkey);
        if ( NotPersonalkeyData::getInstance()->not_personalkey( newkey ) )
        {
            analysisData->m_cache_persional_down = true;
            // Trace_cnt(BLD_STAT_PERSONALIZE_WHITELIST_KEY_HIT_COUNT, 1, analysisData->m_ump2_tag);
        }
    }

#if 0
    if(_blender_conf->m_g_need_personalize_degrade || analysisData->m_cache_persional_down)
    {
        std::string _turl = url;
        const char* eparams[] = {"deviceid=", "mtest=", NULL};
        for ( int i = 0; NULL != eparams[i]; i++ )
        {
            size_t pos = _turl.find(eparams[i]);
            if ( pos != string::npos )
            {
                size_t endpos = _turl.find('&', pos); 
                if ( endpos == string::npos )
                {
                    endpos = _turl.length();
                }
                if ( (pos > 0 ) && ('&' == _turl[pos-1]) )
                {
                    pos -= 1;
                }
                if ( pos < endpos)
                {
                    _turl.erase(pos, endpos-pos);
                }
            }
        }

        query->set__url( _turl);
    }
    else
    {
        query->set__url( url );
    }
#else
    if(_blender_conf->m_g_need_personalize_degrade || analysisData->m_cache_persional_down)
    {
        query->set__downgrade_model(1);
    }
    query->set__url( url );
#endif
    
    if(!_blender_conf->m_g_need_personalize_degrade && !analysisData->m_cache_persional_down)
    {
        query->set__user_pin( tmp_user_pin );                    //ÓÃ»§pin
        BLD_TRANS_STRING_PARAM_IF_CAPITAL(_visitkey, "visitkey");
        BLD_TRANS_STRING_PARAM_IF_CAPITAL(_openid, "openid");
    }

    //abtest·Ö²ã±êÖ¾
    if( (tmp_user_pin.length() != 0) && _blender_conf->m_g_qp_testuser_valid)
    {
        map<string,string>::iterator it = analysisData->blenderConf()->m_g_qp_testuser_whitelist_map.find(tmp_user_pin);
        string tmp_mtest = url_parser.ParseString(url, MTEST);

        if(it != analysisData->blenderConf()->m_g_qp_testuser_whitelist_map.end())
        {
            analysisData->m_user_is_testuser = true;
            std::pair<string, string> k2v;
            if( StrUtil::splitPair(key, ":qpab:", k2v) )
            {                
                if(tmp_mtest.length() != 0)
                    query->set__mtest( k2v.second + "," +  tmp_mtest );
                else
                    query->set__mtest( k2v.second );

                key = k2v.first;
                query->set__key( key ); 
                query->set__original_key( key );
            }
            else
            {
                query->set__mtest( tmp_mtest );
            }
        }
        else
        {
            query->set__mtest( tmp_mtest );
        }
    }
    else
    {
        query->set__mtest( url_parser.ParseString(url, MTEST) );                 
    }

    if ( !query->_mtest().empty() && !analysisData->blenderConf()->m_g_qp_mtest_blacklist.empty() )
    {
        std::string new_mtest;
        std::vector<std::string> tmp_vec = StrUtil::split(query->_mtest(), ",");
        std::vector<std::string>::iterator vit = tmp_vec.begin();
        for(; vit != tmp_vec.end(); vit++ )
        {
            if ( analysisData->blenderConf()->m_g_qp_mtest_blacklist.find(*vit) != analysisData->blenderConf()->m_g_qp_mtest_blacklist.end() )
            {
                continue;
            }
            if ( !new_mtest.empty() )
            {
                new_mtest.append(",");
            }
            new_mtest.append(*vit);
        }
        query->set__mtest( new_mtest );
    }
    
    query->set__sort_xtest_type( url_parser.ParseInteger(url, SORT_XTEST_TYPE, DEFAULT_SORT_XTEST_TYPE));                  //
    query->set__sort_type( url_parser.ParseSortType(url) );
    query->set__sort_type_show_more( url_parser.ParseString(url, SORT_TYPE_SHOW_MORE, DEFAULT_SORT_TYPE_SHOW_MORE) == SORT_TYPE_SHOW_MORE_YES );
    query->set__model_rank_gamma( url_parser.ParseString(url, MODEL_RANK_GAMMA, DEFAULT_MODEL_RANK_GAMMA) );                 //add by wujian
    query->set__debug_model( url_parser.ParseInteger(url, MODEL_DEBUG_MODEL, DEFAULT_MODEL_DEBUG_MODEL) );

    int location_id = 0;
    url_parser.ParseAreaParameters(url, location_id, analysisData->m_area_ids);
    int area_id_level_cnt = 0;
    for ( vector<int>::iterator it = analysisData->m_area_ids.begin(); it != analysisData->m_area_ids.end(); ++it )
    {
        area_id_level_cnt++;
        query->add__area_ids(*it);
        if ( ( _blender_conf->m_g_area_id_level_limit > 0) && (area_id_level_cnt >= _blender_conf->m_g_area_id_level_limit) )
        {
            break;
        }
    }

    string coordinates = url_parser.ParseString(url, "coordinates", "");
    std::pair<string, string> latitude2longitude;
    if( StrUtil::splitPair(coordinates, ",", latitude2longitude) )
    {
        // initialized as invalid coordinates
        float latitude = 361;
        float longitude = 361;

        try
        {
            latitude = boost::lexical_cast<float>(latitude2longitude.first);
            longitude = boost::lexical_cast<float>(latitude2longitude.second);

            query->add__coordinates(latitude);
            query->add__coordinates(longitude);
        }
        catch(...)
        {

        }
    }




    if (0 != _blender_conf->_exclude_filt.count(FILT_LOCATION_ID))
    {
        string area_info = url_parser.ParseString(url, AREA_ID_PARA, DEFAULT_AREA_ID_VALUE);
        if (area_info.empty())
        {
            try
            {
                area_info = boost::lexical_cast<string>(location_id); 
            }
            catch (...)
            {
                BLD_ERROR(analysisData->logStream(), "Cast Error!");
                area_info = "0";
            }
        }
        jd::search::common::JdStringPair *spair = query->add__filt_info();
        spair->set_key(FILT_LOCATION_ID);
        spair->set_value(area_info);
    }


    //query->set__shop_count( m_shop_count );   //QP
    //query->set__shop_id( m_hit_shop_id );        //QP

    query->set__use_attr_cache( url_parser.ParseInteger(url, ATTR_CACHE, 1) == 1 );
    query->set__use_page_cache( url_parser.ParsePageCachePlug(url) == "yes" );
    query->set__use_doc_cache( url_parser.ParseString(url, "use_doccache", "yes") == "yes" ); 
    query->set__use_cache( !(url_parser.ParseString(url, USE_CACHE, "yes", DEFAULT_USE_CACHE) == USE_CACHE_NO) ); 
    query->set__brand_col( url_parser.ParseString(url, BRAND_ATTR_COLLECTION, DEFAULT_BRAND_ATTR_COLLECTION) == BRAND_ATTR_COLLECTION_YES );                   //Æ·ÅÆ»ã×Ü²ÎÊý¿ØÖÆ£¬ÒÀÀµËã·¨½á¹û£¬ÓÐ¿ÉÄÜ×îÖÕ²»»ã×Ü
    query->set__force_brand_col( url_parser.ParseString(url, FORCE_BRAND_COLLECTION, DEFAULT_FORCE_BRAND_COLLECTION) == FORCE_BRAND_COLLECTION_YES );                  //Ç¿ÖÆÆ·ÅÆ»ã×Ü£¬²»ÔÙÒÀÀµËã·¨½á¹û
    query->set__expattr_col( url_parser.ParseString(url, EXTEND_ATTR_COLLECTION, DEFAULT_EXTEND_ATTR_COLLECTION) == EXTEND_ATTR_COLLECTION_YES );                 //À©Õ¹ÊôÐÔ»ã×Ü²ÎÊý¿ØÖÆ£¬£¬ÒÀÀµËã·¨½á¹û£¬ÓÐ¿ÉÄÜ×îÖÕ²»»ã×Ü
    query->set__force_expattr_col( url_parser.ParseString(url, FORCE_ATTR_COLLECTION, DEFAULT_FORCE_ATTR_COLLECTION) == FORCE_ATTR_COLLECTION_YES );                //Ç¿ÖÆÀ©Õ¹ÊôÐÔ»ã×Ü£¬²»ÔÙÒÀÀµËã·¨½á¹û
    query->set__new_product_col( url_parser.ParseString(url, NEW_PRODUCT_COLLECTION, DEFAULT_NEW_PRODUCT_COLLECTION) == NEW_PRODUCT_COLLECTION_YES );                  //ÊÇ·ñÓÐÐÂÆ·¼ì²â
    query->set__price_col( url_parser.ParseString(url, PRICE_COLLECTION, DEFAULT_PRICE_COLLECTION) == PRICE_COLLECTION_YES );                   //¼Û¸ñ»ã×Ü²ÎÊý¿ØÖÆ£¬ÒÀÀµËã·¨½á¹û£¬ÓÐ¿ÉÄÜ×îÖÕ²»»ã×Ü
    query->set__force_price_col( url_parser.ParseString(url, FORCE_PRICE_COLLECTION, FORCE_DEFAULT_PRICE_COLLECTION) == FORCE_PRICE_COLLECTION_YES );                  //Ç¿ÖÆ¼Û¸ñ»ã×Ü£¬²»ÔÙÒÀÀµËã·¨½á¹û
    query->set__url_encode( url_parser.ParseString(url, ENC_URL, DEFAULT_ENC_URL) == ENC_URL_YES );                  //¶Ô·µ»Ø½á¹û½øÐÐurl encode²ÎÊý¿ØÖÆ
    query->set__color_col( url_parser.ParseString(url, COLOR_ATTR_COLLECTION, DEFAULT_COLOR_ATTR_COLLECTION) == COLOR_ATTR_COLLECTION_YES );                   //ÑÕÉ«»ã×Ü²ÎÊý¿ØÖÆ£¬ÒÀÀµËã·¨½á¹û£¬ÓÐ¿ÉÄÜ×îÖÕ²»»ã×Ü
    query->set__size_col( url_parser.ParseString(url, SIZE_ATTR_COLLECTION, DEFAULT_SIZE_ATTR_COLLECTION) == SIZE_ATTR_COLLECTION_YES );                    //³ßÂë»ã×Ü²ÎÊý¿ØÖÆ£¬ÒÀÀµËã·¨½á¹û£¬ÓÐ¿ÉÄÜ×îÖÕ²»»ã×Ü
    query->set__merge_sku( url_parser.ParseString(url, MERGESKU, DEFAULT_MERGESKU) == MERGESKU_YES );                   //Ö÷´ÓºÏ²¢²ÎÊý¿ØÖÆ£¬ÒÀÀµËã·¨½á¹û£¬ÓÐ¿ÉÄÜ×îÖÕ²»ºÏ²¢
    query->set__force_merge_sku( url_parser.ParseString(url, FORCE_MERGESKU, FORCE_DEFAULT_MERGESKU) == FORCE_MERGESKU_YES );                  //Ç¿ÖÆÖ÷´ÓºÏ²¢²ÎÊý¿ØÖÆ£¬²»ÒÀÀµËã·¨½á¹û£¬ÓÃÓÚ´¹Ö±Õ¾
    query->set__merge_sku_vertical_type( strtoll(url_parser.ParseSkuVerticalMergeType(url).c_str(), NULL, 10) );                   //Ö÷´ÓºÏ²¢ÀàÐÍ£¬ÓÃÓÚ´¹Ö±Õ¾
    query->set__multi_suppliers( url_parser.ParseString(url, MULTI_SUPPLIERS, DEFAULT_MULTI_SUPPLIERS) == MULTI_SUPPLIERS_YES );                  //Í¼ÊéÒ»Æ·¶àÉÌºÏ²¢²ÎÊý¿ØÖÆ
    query->set__excute_suite( url_parser.ParseString(url, SUITE_STATE_COLLECTION, DEFAULT_SUITE_STATE) == SUITE_STATE_YES );                //×éÌ×ÉÌÆ·ºÏ²¢²ÎÊý¿ØÖÆ
    query->set__gzip(false); //²»ÐèÒª´«Õâ¸ö²ÎÊý¸ømerger 
    //query->set__shop_dimension( ParseShopDimension(url) );                  //Õâ¸ö±äÁ¿²»ÓÃÁË

    query->set__shop_search_url_valid( url_parser.ParseString(url, SHOP_SEARCH_CONTROL_PARAM, DEFAULT_SHOP_SEARCH_CONTROL_PARAM) == SHOP_SEARCH_CONTROL_PARAM_YES );                 //±êÊ¶ÊÇ·ñÍ¨¹ýURLÊ¶±ðÎªÓÐÐ§
    query->set__shop_page_size( url_parser.ParseShopPageSize(url) );                  //µêÆÌÕ¹Ê¾³¡¾°ÏÂ£¬Ã¿Ò³Õ¹Ê¾µêÆÌµÄÊýÁ¿
    query->set__is_mshop( url_parser.ParseString(url, MSHOP, DEFAULT_MSHOP) == MSHOP_YES );                    //ÊÇ·ñÊÇÒÆ¶¯µêÆÌÇëÇó£¬ÒÆ¶¯¶ËÒªÇó±ØÐë³öÒÑ×°ÐÞµÄµêÆÌ
    query->set__only_cid_col( url_parser.ParseString(url, ONLY_CIDCOL, DEFAULT_ONLY_CIDCOL) == ONLY_CIDCOL_YES );                //½ö×ö·ÖÀà»ã×Ü
    query->set__multi_select( url_parser.ParseString(url, MULTI_SELECT, DEFAULT_MULTI_SELECT) == MULTI_SELECT_YES );                //ÊÇ·ñ¶àÑ¡ÇëÇó
    query->set__ext_attr_sort( url_parser.ParseString(url, EXPAND_ATTRS_SORT, DEFAULT_EXPAND_ATTRS_SORT) == EXPAND_ATTRS_YES );                //ÊÇ·ñ½øÐÐÊôÐÔÅÅÐò
    query->set__x_json_null( url_parser.ParseString(url, EXCLUDE_JSON_NULL, DEFAULT_EXCLUDE_JSON_NULL) == EXCLUDE_JSON_NULL_YES );                 //ÊÇ·ñÊä³ö¿Õ×Ö·û´®×Ö¶Î
    query->set__joindata_col( url_parser.ParseString(url, JOIN_DATA_COLLECTION, JOIN_DATA_COLLECTION_NO) == EXCLUDE_JSON_NULL_YES );                //joindata»ã×Ü£¬Í¨ÓÃËÑË÷Ê¹ÓÃ
    query->set__not_compute_text_rel( url_parser.ParseString(url, NOT_COMPUTE_TEXT_RELEVANCE, DEFAULT_NOT_COMPUTE_TEXT_RELEVANCE) == NOT_COMPUTE_TEXT_RELEVANCE_YES );                   //ÊÇ·ñ¼ÆËãÎÄ±¾Ïà¹ØÐÔ²ÎÊý¿ØÖÆ
    query->set__is_new_brand_val( url_parser.ParseString(url, NEW_BRAND_VAL, DEFAULT_NEW_BRAND_VAL) == NEW_BRAND_VAL_YES );                 //ÐÂµÄÆ·ÅÆ»ã×Ü¿ª¹Ø£¬ÓëÔ­À´Æ·ÅÆ»ã×ÜÂß¼­Ò»ÖÂ£¬½öÆ·ÅÆ·Ö¸ô·û·¢Éú±ä»¯
    query->set__listp_price_model( url_parser.ParseString(url, PLIST_PRICE_MODEL_TEST, "") );                    //ÁÐ±íÒ³¼Û¸ñÄ£ÐÍÊý¾Ý
    query->set__shop_filt_type( (url_parser.ParseString(url, SHOP_FILT_TYPE, SHOP_FILT_NONE) == SHOP_FILT_SELF_SUPPORT)? jd::search::common::FILT_SELF_SUPPORT : jd::search::common::FILT_NONE );                //µêÆÌ¹ýÂËÀàÐÍ
    query->set__exwarehouse_score_test( url_parser.ParseString(url, EXWAREHOUSE_QUALITY_TEST, "") == EXWAREHOUSE_QUALITY_TEST_YES );                //Ê¹ÓÃ³ö¿âÉÌÆ·ÖÊÁ¿·Ö²âÊÔ¿ª¹Ø
    query->set__inquire_by_list( url_parser.ParseInquireType(url) == DEFAULT_INQUIRE_FOR );                  //ÊÇ·ñÁÐ±íÒ³ÐèÇó
    query->set__new_brand_model_test( url_parser.ParseString(url, NEW_BRAND_MODEL_TEST, DEFAULT_NEW_BRAND_MODEL_TEST) == NEW_BRAND_MODEL_TEST_YES );                   //Ê¹ÓÃÐÂÆ·ÅÆÄ£ÐÍ¿ª¹Ø£¬ÐÂÆ·ÅÆÄ£ÐÍ×ÉÑ¯ÕÅÏþÃô
    query->set__ranking_product_list( url_parser.ParseString(url, RANKING_PRODUCT_LIST, "") );                  //ÉÌÆ·idÁÐ±í£¬ÓÃÓÚ²éÑ¯¶ÔÓ¦ÉÌÆ·ÅÅÃû
    int shop_warelist_count = url_parser.ParseShopWareListCount(url);
    if ( shop_warelist_count < 0 ) 
    {
        shop_warelist_count = 0;
    }
    query->set__shop_warelist_count( shop_warelist_count );                  //Ã¿¸öµêÆÌÏÂÕ¹Ê¾ÉÌÆ·ÊýÁ¿
    int mobile_shop_createtime = url_parser.ParseMobileShopCreatetime(url);
    if (mobile_shop_createtime < 0)
    {
        mobile_shop_createtime = 1;
    }
    query->set__mobile_shop_createtime( mobile_shop_createtime );                   //ÒÆ¶¯µêÆÌÀàÐÍ£¬È¡ÖµÎª1¡¢2¡¢3ºÍÆäËû£¬¾ßÌåº¬Òå×ÉÑ¯ÔªÄÐ
    query->set__is_cod_flag( url_parser.ParseCashOnDelivery(url) == "yes" );                 //ÊÇ·ñ·µ»Ø»õµ½¸¶¿î±êÊ¶
    int expand_type = url_parser.ParseExpandType(url);
    if ( expand_type < 0 ) 
    {
        expand_type = 0;
    }
    query->set__expand_type( expand_type );                //À©Õ¹´ÊÀàÐÍ£¬ÓÃÓÚ¶à´Î½»»¥ÖÐ±£³Ö×´Ì¬Ò»ÖÂ
    int shoehat_extattr = url_parser.ParseShoeHatExtAttr(url);
    if (shoehat_extattr < 0)
    {
        shoehat_extattr = 0;
    }
    query->set__shoehat_extattr( shoehat_extattr );                 //·µ»Ø¸øÇ°¶Ë£¬±£³Ö¶à´Î½»»¥µÄÒ»ÖÂÐÔ
    query->set__query_auto_recovery( url_parser.ParseString(url, QUERY_AUTO_RECOVERY, "yes") == QUERY_AUTO_RECOVERY_DEFAULT );                   //ÊÇ·ñÔÊÐíÀ©Õ¹´ÊÖ±½ÓÌæ»»Ô­´Ê
    query->set__brand_select( url_parser.ParseString(url, BRAND_ATTR_SELECT, DEFAULT_BRAND_ATTR_SELECT) == "yes" );                //ÊÇ·ñ½øÐÐÁËÆ·ÅÆ¹´Ñ¡£¬ÓÃÓÚÓÃ»§Ö÷¶¯¹´Ñ¡ÁËÆ·ÅÆ»òÕßQPÄ¬ÈÏ¹´Ñ¡³¡¾°ÏÂ£¬ÓÃ»§Ö÷¶¯È¡Ïû¹´Ñ¡

    query->set__doc_max_len( url_parser.ParseInteger(url,DOC_MAX_LEN_PARA,DEFAULT_DOC_MAX_LEN) );                //docµ¥¸öfieldµÄ×î´ó³¤¶È

    //ÉÌÆ·ÁÐ±í¹¦ÄÜ£¬´«ÈëµÄ¶à¸öÉÌÆ·idÁÐ±í×Ö·û´®£¬ÒÔ¶ººÅ·Ö¸ô
    if ( query->_key().empty() )
    {
        std::vector<std::string> tmp = clsGlobal::GetStrings(url_parser.ParseString(url,"product_list",""), ",");
        for ( size_t i = 0; i < tmp.size(); i++ )
        {
            try 
            {
                query->add__product_list( boost::lexical_cast<int64>(tmp[i]) );
            }
            catch(...){}
        }
    }
    query->set__no_key( url_parser.ParseString(url,"no_key","") == "yes" );                 //±êÊ¶Ã»ÓÐkey£¬×ßÌØÊâÂß¼­
    query->set__is_clothing_mall( url_parser.ParseString(url, CLOTHING_MALL, DEFAULT_CLOTHING_MALL) == CLOTHING_MALL_YES );                  //ÊÇ·ñ·þ×°³ÇÇëÇó
    if (query->_is_clothing_mall())
    {
        query->set__no_key("yes");
    }

    query->set__is_clothing_reco( url_parser.ParseString(url, CLOTHING_RECO, DEFAULT_CLOTHING_RECO) == CLOTHING_RECO_YES );                 //ÊÇ·ñ·þ×°³ÇÍÆ¼öÇëÇó
    //query->set__qp_have_influence( m_qp_have_influence );                //QPÊÇ·ñ¶Ô½á¹û¼¯ÊýÁ¿²úÉúÓ°Ïì
    //query->//QPResult _qp_result(  );                    //QP·µ»ØµÄ½á¹û¼¯
    //query->//UserModelData _user_model_data(  );                   //ÓÃ»§Ä£ÐÍÊý¾Ý
    //query->//OPResponse _op_result(  );                  //ÔËÓªÆ½Ì¨Êý¾Ý

    /* ¶ÔÓÚµêÆÌÎ¬¶ÈÕ¹Ê¾£¬È¡µêÆÌpagesize */
    int page_size = 0;
    page_size = url_parser.ParsePageSize(url);
    if (page_size < 0)
    {   
        page_size = DEFAULT_PAGE_SIZE_VALUE;
    }
    query->set__page_size( page_size );

    int page_idx  = url_parser.ParsePageIndex(url);
    int start_pos = url_parser.ParseInteger(url, "start", 0);
    analysisData->m_url_has_start = (start_pos > 0) ? true : false;
    if( (start_pos > 0) && (page_idx > 0) )
    {
        //Nothing to do
    }
    else if(page_idx > 0)
    {
        start_pos = (page_idx - 1) * query->_page_size() + 1;
    }
    else if(start_pos > 0)
    {
        page_idx = (int)((double)(start_pos - 1)/query->_page_size() + 0.5) + 1; //¸ù¾Ýstart¼ÆËãpage_index£¬²ÉÓÃËÄÉáÎåÈë·½·¨¼ÆËã
    } 
    else
    {
        page_idx = 1;
        start_pos = 1;
    }
    query->set__start_pos(start_pos);
    query->set__page_index(page_idx);

    query->set__debug( url_parser.ParseString(url, DEBUG_MODE, DEFAULT_DEBUG_MODE) == DEBUG_MODE_YES );
    if ( _blender_conf->m_g_onlinedebug_valid )
    {
        BLD_TRANS_STRING_PARAM_IF(_debug_level, "debug_level");
        BLD_TRANS_STRING_PARAM_IF(_debug_level, "online_debug");
    }
    query->set__use_detail_server( url_parser.ParseString(url, "use_detail_server", "yes") == "yes");
    query->set__shop_col( url_parser.ParseString(url, "shop_col", "no") == "yes");
    std::string return_pos_sku64_list = url_parser.ParseString(url, "return_pos_sku", "");
    if (!return_pos_sku64_list.empty()) {
        query->set__return_pos_sku64_list(return_pos_sku64_list);
    }
    //query->set__return_pos_sku64( url_parser.ParseInteger(url, "return_pos_sku", 0));
    query->set__um_app( url_parser.ParseString(url, "um_app"));
    BLD_TRANS_INT_PARAM_IF(_car_module_id, "car_model_id");
    BLD_TRANS_INT_PARAM_IF(_brand_slice, "brand_slice");
    query->set__cat_simplify( url_parser.ParseString(url, "cat_simplify", "no") == "yes");
    BLD_TRANS_INT_PARAM_IF(_platform, "platform");
    query->set__jd_market_sort( url_parser.ParseString(url, "jd_market_sort", "no") == "yes");
    BLD_TRANS_BOOL_PARAM_IF(_flush_cache, "flush_cache");
    if ( query->has__flush_cache() && query->_flush_cache() )
    {
        query->set__use_cache(false);
    }
    BLD_TRANS_BOOL_PARAM(_laoke_redpackage, "oc", "no");
    BLD_TRANS_INT_PARAM_IF(_rs_addition, "rs_addition");
    BLD_TRANS_BOOL_PARAM(_use_rank, "use_rank", "yes");
    BLD_TRANS_BOOL_PARAM(_old_ware, "oldware", "no");
    BLD_TRANS_STRING_PARAM_IF(_log_id, "log_id");
    BLD_TRANS_STRING_PARAM_IF(_baby_plan_age, "baby_age");
    BLD_TRANS_STRING_PARAM_IF(_baby_plan_sex, "baby_sex");
    BLD_TRANS_BOOL_PARAM(_disable_syn, "disable_syn", "no");
	BLD_TRANS_BOOL_PARAM(_jimi_req, "jimi_req", "no");

    analysisData->m_url_filt_info = url_parser.ParseFiltType(url);
    for ( size_t i = 0; i < analysisData->m_url_filt_info.size(); i++ )
    {
        jd::search::common::JdStringPair *spair = query->add__filt_info();
        spair->set_key(analysisData->m_url_filt_info[i].first);
        spair->set_value(analysisData->m_url_filt_info[i].second);
    }
    if ( _blender_conf->m_g_auction_valid )
    {
        bool _auction = (url_parser.ParseString(url, "auction", "") == "yes");
        if ( !_auction )
        {
            jd::search::common::JdStringPair *spair = query->add__filt_info();
            spair->set_key("not_cid1");
            spair->set_value("L12650M12650");
        }
    }
    if ( _blender_conf->m_g_lightspeed_valid )
    {
        bool _auction = (url_parser.ParseString(url, "lightspeed", "") == "no");
        if ( _auction )
        {
            jd::search::common::JdStringPair *spair = query->add__filt_info();
            spair->set_key("not_lightspeed");
            spair->set_value("");
        }
    }

    for ( size_t i = 0; i < analysisData->blenderConf()->m_g_url_param_ext_vec.size(); i++ )
    {
        std::string ext_key = analysisData->blenderConf()->m_g_url_param_ext_vec[i];
        if ( !ext_key.empty() )
        {
            if(_blender_conf->m_g_need_personalize_degrade || analysisData->m_cache_persional_down)
            {
                if ( ("uuid" == ext_key) )
                {
                    continue;
                }
            }

            std::string ext_value = url_parser.ParseString(url, ext_key, "", true);
            if ( !ext_value.empty() )
            {
                if ( ("uuid" == ext_key) )
                {
                    analysisData->m_uuid = ext_value;
                }
                jd::search::common::JdStringPair *spair = query->add_url_param_ext();
                spair->set_key(ext_key);
                spair->set_value(ext_value);

            }
        }
    }
	
    //È¯¹º¡¢´ÙÏú´Õµ¥½âÎö
    std::string activity_coupon_id = url_parser.ParseString(url, "activity_id", "");
    std::string ecard_id     = url_parser.ParseString(url, "ecard_id", "");
    std::string coupon_batch = url_parser.ParseString(url, "coupon_batch", "");
    std::string rebate_id    = url_parser.ParseString(url, "rebate_id", "");
    std::string scene_id    = url_parser.ParseString(url, "scene_id", "");
    std::string select_sku   = url_parser.ParseString(url, "select_sku", "");

    analysisData->m_reqtype = "main";
    jd::search::request::CouponInfo* conponQuery = qp_query->mutable_conpon_query();
    if ( !activity_coupon_id.empty() )
    {
        try{
            analysisData->m_reqtype = "activity";
            query->mutable__recall_rule()->set_request_id(boost::lexical_cast<long>(activity_coupon_id));
            query->mutable__recall_rule()->set_request_type(BlenderAnalysisData::PROMOTION_ACTIVITY);
            
            if(_blender_conf->m_g_op_coupon_valid)
            {
                conponQuery->set_coupon_id( boost::lexical_cast<long>(activity_coupon_id) );
                conponQuery->set_coupon_type(BlenderAnalysisData::PROMOTION_ACTIVITY);

                if( query->_original_key().empty() && query->_sir_key().empty() )
                {
                    conponQuery->set_coupon_op_only(true);
                }
            }
        }catch(...){}
    }
    else if ( !ecard_id.empty() )
    {
        try{
            analysisData->m_reqtype = "ecard";
            query->mutable__recall_rule()->set_request_id(boost::lexical_cast<long>(ecard_id));
            query->mutable__recall_rule()->set_request_type(BlenderAnalysisData::PROMOTION_ECARD);
        }catch(...){}
    }
    else if ( !coupon_batch.empty() )
    {
        try{
            analysisData->m_reqtype = "coupon";
            query->mutable__recall_rule()->set_request_id(boost::lexical_cast<long>(coupon_batch));
            query->mutable__recall_rule()->set_request_type(BlenderAnalysisData::PROMOTION_COUPON);
                
            if(_blender_conf->m_g_op_coupon_valid)
            {
                conponQuery->set_coupon_id( boost::lexical_cast<long>(coupon_batch) );
                conponQuery->set_coupon_type(BlenderAnalysisData::PROMOTION_COUPON);
                if( query->_original_key().empty() && query->_sir_key().empty() )
                {
                    conponQuery->set_coupon_op_only(true);
                }
            }
        }catch(...){}
    }
    else if ( !rebate_id.empty() )
    {
        try{
            analysisData->m_reqtype = "rebate";
            query->mutable__recall_rule()->set_request_id(boost::lexical_cast<long>(rebate_id));
            query->mutable__recall_rule()->set_request_type(BlenderAnalysisData::PROMOTION_REBATE); 
            if(_blender_conf->m_g_op_coupon_valid)
            {
                conponQuery->set_coupon_id( boost::lexical_cast<long>(rebate_id) );
                conponQuery->set_coupon_type(BlenderAnalysisData::PROMOTION_REBATE);
                if( query->_original_key().empty() && query->_sir_key().empty() )
                {
                    conponQuery->set_coupon_op_only(true);
                }
            }
        }catch(...){}
    }
    else if ( !scene_id.empty() )
    {
        try{
            analysisData->m_reqtype = "scene";
            query->mutable__recall_rule()->set_request_id(boost::lexical_cast<long>(scene_id));
            query->mutable__recall_rule()->set_request_type(BlenderAnalysisData::PROMOTION_SCENE); 
            if(_blender_conf->m_g_op_coupon_valid)
            {
                conponQuery->set_coupon_id( boost::lexical_cast<long>(scene_id) );
                conponQuery->set_coupon_type(BlenderAnalysisData::PROMOTION_SCENE);
                if( query->_original_key().empty() && query->_sir_key().empty() )
                {
                    conponQuery->set_coupon_op_only(true);
                }
            }

        }catch(...){}
    }

    if ( !select_sku.empty() && query->mutable__recall_rule()->has_request_id() )
    {
        try{
            query->mutable__recall_rule()->set_select_sku(boost::lexical_cast<long>(select_sku));
        }catch(...){}
    }

    //blender µÄÏà¹Ø±äÁ¿
    {
        analysisData->m_op_disable = url_parser.ParseString(url, "op_disable", "") == "yes";
        analysisData->m_qp_disable = url_parser.ParseString(url, QP_DISABLE, "") == "yes";
        analysisData->m_qp_exclude_value = url_parser.ParseInteger(url, QP_EXCLUDE, DEFAULT_QP_EXCLUDE);
        analysisData->m_qptest = url_parser.ParseString(url, QP_TEST, QP_TEST_DEFAULT);

        analysisData->m_gzip = url_parser.ParseString(url, GZ, DEFAULT_GZ) == GZ_YES;//½á¹ûÊÇ·ñ½øÐÐgzipÑ¹Ëõ

        //blenderÐÂÔö
        analysisData->promotion_url_valid  = (url_parser.ParseString(url, PROMOTIONS, DEFAULT_PROMOTIONS) == PROMOTIONS_YES);
        analysisData->advert_url_valid = (url_parser.ParseString(url, ADVERT, DEFAULT_ADVERT) == ADVERT_YES);
        analysisData->ad_jda = url_parser.ParseString(url, AD_JDA, DEFAULT_AD_JDA);
        analysisData->m_route = url_parser.ParseString(url, "route", "");
        analysisData->m_bld_debug = (url_parser.ParseString(url, "blender_debug", "no") == "yes");
        analysisData->m_bld_app_xflag = url_parser.ParseInteger(url, "xflag", 0);
        analysisData->redpackets_url_valid = (url_parser.ParseString(url, "re", "no") == "yes");

        analysisData->m_forcebot = url_parser.ParseString(url, "forcebot", "");
        analysisData->m_ump2_tag = blender::ump2tag(analysisData->query()->_client_id(), analysisData->m_reqtype);
        
        if(_blender_conf->m_g_support_only_rcount)   // ´Ë´¦±£Áô0 À´²»´«only_rcount ²ÎÊýµ½merge 
        {
            analysisData->m_only_rcount_url_valid = url_parser.ParseString(url, ONLY_RCOUNT_MODE, DEFAULT_ONLY_RCOUNT_MODE) == ONLY_RCOUNT_MODE_YES ;
            //query->set__only_count( url_parser.ParseString(url, ONLY_RCOUNT_MODE, DEFAULT_ONLY_RCOUNT_MODE) == ONLY_RCOUNT_MODE_YES );                  //Ö»È¡½á¹ûÊý
        }

        analysisData->m_app_version = url_parser.ParseString(url, "client_version", "0.0.0");

        analysisData->m_storetab_url_valid = (url_parser.ParseString(url, "storetab", "no") == "yes");
        analysisData->m_shoptab_url_valid = (url_parser.ParseString(url, "shoptab_valid", "no") == "yes");
        analysisData->m_mg_disable = (url_parser.ParseString(url, "mg_disable", "no") == "yes");
        analysisData->m_artc_tab_url_valid    = (url_parser.ParseString(url, "article_tab", "no") == "yes");
        analysisData->m_artc_tab_filt_type = url_parser.ParseString(url, "at_filt_type", "");
        analysisData->m_artc_insert_url_valid = (url_parser.ParseString(url, "article_insert", "no") == "yes");
        analysisData->m_artc_daren_insert_url_valid = (url_parser.ParseString(url, "article_daren", "no") == "yes");
        analysisData->m_scene_insert_url_valid = (url_parser.ParseString(url, "sc", "no") == "yes");
        analysisData->m_onebox_mode = url_parser.ParseInteger(url, "onebox_mod", 0);

        analysisData->m_enc_url_gbk = (url_parser.ParseString(url, "enc_url_gbk", "no") == "yes");
        vector<string> mttmp = GetStrings(query->_mtest(), ",");
        for ( size_t i = 0; i < mttmp.size(); i++ )
        {
#ifdef BLD_QP_AB_VALID
            if ( _blender_conf->m_g_qp_ab_valid && !analysisData->m_qp_is_req_ab )
            {
                vector<string>::iterator it = std::find(analysisData->blenderConf()->m_g_qp_ab_bucketlist.begin(), analysisData->blenderConf()->m_g_qp_ab_bucketlist.end(), mttmp[i]);
                if ( it != analysisData->blenderConf()->m_g_qp_ab_bucketlist.end() )
                {   
                    analysisData->m_qp_is_req_ab = true;
                }
            }
#endif
            if( !mttmp[i].empty() )
            {
                analysisData->m_mtest_set.insert(mttmp[i]);
            }
        }   
    }

    //Èç¹ûQP disable£¬Ôò´ÓurlÖÐ½âÎöurlÖÐÖ¸¶¨µÄÏà¹ØÐÅÏ¢
    if ( analysisData->m_qp_disable )
    {
        LocalQueryProcess(url, analysisData);
    }
	
	stTimer.End();
	BLD_INFO(NULL, "parse url time cost:"<<stTimer.CostUs());

    return;
}


bool BlenderParser::LocalQueryProcess(const string &url, blender::BlenderAnalysisData *analysisDat)
{
    I_CommandParser url_parser;
    jd::search::request::JdSearchQuery *query = analysisDat->query();
    jd::search::request::QPResult* qpResult = query->mutable__qp_result();
    
    //disable qb, it means web use the qb
    analysisDat->m_qp_invoke_success = 0;
    qpResult->set__query_type(url_parser.ParseQueryType(url));

    // price_range: µ±Ç°²éÑ¯´Ê, cid3µ½¼Û¸ñÇø¼äµÄÓ³Éä
    boost::unordered_map<int, std::pair<int, int> > cid3_to_price_interval;
    ParsePriceInterval(url, cid3_to_price_interval);
    boost::unordered_map<int, std::pair<int, int> >::iterator iter = cid3_to_price_interval.begin();
    for (; iter != cid3_to_price_interval.end(); iter++)
    {
        jd::search::request::CatPriceRange *priceRange = qpResult->add__reasonable_cat_price_range();
        priceRange->set__catid(iter->first);
        priceRange->set__lower_bound((iter->second).first);
        priceRange->set__high_bound((iter->second).second);
    }

    /*********************È¡ËÑË÷¸ßÏà¹ØÐÔÊý¾ÝÐ§¹ûÊµÑé´úÂë****************/
    //rel_cat:¸ñÊ½category3=1483,1482:category2=1463 
    vector<int> hc_cid3s;
    ParseCategory(url, hc_cid3s);
    for (vector<int>::iterator it = hc_cid3s.begin(); it != hc_cid3s.end(); ++it )
    {
        qpResult->add__hc_cid3s(*it);
    }

    
    //query_key:
    std::string tmp_str = url_parser.ParseQueryCenterKey(url);
    query->set__query_center_key(tmp_str);

    //expression_key:
    tmp_str = url_parser.ParseString(url, EXPRESSION_KEY_PARA, DEFAULT_EXPRESSION_KEY_VALUE);
    if ( !tmp_str.empty() )
    {
        query->set__expression_key(tmp_str);
    }

    //expression_key:
    tmp_str = url_parser.ParseQueryExpandKey(url);
    if ( !tmp_str.empty() )
    {
        query->set__expand_key(tmp_str);
    }

    //query tags:
    string queryBrand;
    string queryProduct;
    vector<QueryTermType> termTypes;
    if ( ParseTermType(url_parser.ParseString(url, QUERY_TERM_TAGS, ""), queryBrand, queryProduct, termTypes) )
    {
        for (vector<QueryTermType>::iterator it = termTypes.begin(); it != termTypes.end(); it++ )
        {
            jd::search::request::TermTag *termTag = qpResult->add__term_tags();
            termTag->set__term(it->termWord);
            termTag->set__tag(it->termType);
            termTag->set__is_key_term(it->ckeyTerm);
        }
        if ( !queryProduct.empty() )
        {
            qpResult->set__query_product(queryProduct);
        }
        if ( !queryBrand.empty() && ((analysisDat->m_qp_exclude_value & search_frame::BRAND_QP_FILTER) != search_frame::BRAND_QP_FILTER) )
        {
            qpResult->set__query_brand(queryBrand);
        }
    }

    //expand_status
    if ( !query->_expand_key().empty() )
    {
        query->set__expand_status(url_parser.ParseQueryExpandStatus(url));
    }

    bool qp_control_advert      = false;
    bool qp_control_promotions  = false;
    bool url_control_advert     = false;
    bool url_control_promotions = false;

    url_control_advert     = (url_parser.ParseString(url, ADVERT, DEFAULT_ADVERT) == ADVERT_YES);
    url_control_promotions = (url_parser.ParseString(url, PROMOTIONS, DEFAULT_PROMOTIONS) == PROMOTIONS_YES);

    if (url_control_promotions)
    {
        int type = url_parser.ParseInteger(url, PROMOTION_TYPE, PROMOTION_TYPE_DEFAULT);
        if (type == 1 || type == 2)
        {
            if (query->_page_size() == 60)
                type += 2;
            analysisDat->promotions.type = type - 1;
            qp_control_promotions = true;
            if (url_control_advert)
            {
                qp_control_advert = true;
            }
            analysisDat->promotions.blacklist = url_parser.ParseString(url, PROMOTION_BLACKLIST, PROMOTION_BLACKLIST_DEFAULT);
        }
    }

    // if no promotions and enable advert, we will set type
    if (url_control_advert && qp_control_promotions == false)
    {
        int type = url_parser.ParseInteger(url, ADVERT_TYPE, ADVERT_TYPE_DEFAULT);
        if (type == 1 || type == 2)
        {
            if (query->_page_size() == 60)
                type += 2;
            analysisDat->promotions.type = type - 1;
            qp_control_advert = true;
        }
    }

    analysisDat->advert_qp_valid        = qp_control_advert;
    analysisDat->promotion_qp_valid     = qp_control_promotions;
    analysisDat->advert_url_valid       = url_control_advert;
    analysisDat->promotion_url_valid    = url_control_promotions;

    return false;
}


#if S_DSC("I_CommandParser ÖÐÃ»ÓÐµÄ½âÎö²¿·Ö£¬ÒÆµ½ÁËÕâÀï")
bool BlenderParser::ParsePriceInterval(const string& commandLine, boost::unordered_map<int, pair<int, int> >& cid3ToPriceinterval)
{
    I_CommandParser url_parser;
    std::string price_interval_str = url_parser.ParseString(commandLine, PRICE_INTERVAL, DEFAULT_PRICE_INTERVAL_VALUE);
    vector<string> tmp = blender::GetStrings(price_interval_str, ";");
    if (tmp.empty())
    {
        return false;
    }

    for (size_t i = 0; i < tmp.size(); ++i)
    {
        string cid_info_str = tmp[i];
        vector<string> cid_info_tmp = blender::GetStrings(cid_info_str, "(");
        if (cid_info_tmp.size() != 2)
        {
            continue;
        }

        int cid3 = 0;
        try
        {
            cid3 = boost::lexical_cast<int>(cid_info_tmp[0]);
        }
        catch (...)
        {
            continue;
        }
        
        string price_info_str = cid_info_tmp[1];
        vector<string> price_info_tmp = blender::GetStrings(price_info_str, ")");
        if (price_info_tmp.empty())
        {
            continue;
        }

        string price_str = price_info_tmp[0];
        vector<string> price_tmp = blender::GetStrings(price_str, ",");
        if (price_tmp.size() != 2)
        {
            continue;
        }

        pair<int, int> price_pair;
        try
        {
            int price_f = boost::lexical_cast<int>(price_tmp[0]);
            int price_e = boost::lexical_cast<int>(price_tmp[1]);

            price_pair.first = price_f;
            price_pair.second = price_e;

            cid3ToPriceinterval[cid3] = price_pair;
        }
        catch (...)
        {
            return false;
        }
    }

    return true;
}


bool BlenderParser::ParseCategory(const string& commandLine, vector<int>& m_hc_cid3s)
{
    I_CommandParser url_parser;
    std::string cate_str = url_parser.ParseString(commandLine, REL_CAT, DEFAULT_REL_CAT_VALUE);
    // ¸ñÊ½category3=1483,1482:category2=1463 
    vector<string> tmp = blender::GetStrings(cate_str, ":");
    if (tmp.empty())
    {
       return false; 
    }
    for (size_t i = 0; i < tmp.size(); i++)
    {
        std::string paraName;
        if (i ==0 )
        {
            paraName = "category3=";
            size_t equ = tmp[i].find(paraName, 0);
            if (equ != std::string::npos)
            {
                std::string tempStr = tmp[i].substr(equ+ paraName.length(), std::string::npos); 
                std::vector<std::string> cate3_str = blender::GetStrings(tempStr, ",");
                std::vector<int> cid3s;
                for (size_t j = 0; j < cate3_str.size(); j++) 
                {
                    try 
                    {
                        int cid = boost::lexical_cast<int>(cate3_str[j]);
                        cid3s.push_back(cid);
                    }
                    catch (...)
                    {
                        BLD_ERROR(NULL, "error-param:" << cate3_str[j]); 
                        return false;
                    }
                }
                m_hc_cid3s = cid3s;
                if (m_hc_cid3s.size() > 0)
                {
                    return true;
                }
            }
        }
        /*
        if (i ==1)
        {   // ÔÝÊ±²»´¦Àícategory2
            paraName = "category2";
        }
        */
    }	 
    return false;	
}


// Translates a two-char hex representation in his corresponding value.
char BlenderParser::HexToChar(char c1, char c2) 
{
    if(c1>='A' && c1<='Z')                                                                                                                              
        c1 = tolower(c1);
    if(c2>='A' && c2<='Z')
        c2 = tolower(c2);
    // Some browsers/servers send uppercase values.
    return ((c2 < 'a')? c2 - '0' : c2 - 'a' + 10) + 
        ((c1 < 'a')? c1 - '0' : c1 - 'a' + 10) * 16;
}

string BlenderParser::Decode(const string &cod)
{
     string dec = cod;
     // Buffer.
     //register unsigned int get;
     unsigned int get;
     // Origin index.
     //register unsigned int set;
     unsigned int set;
     // Target index.

     for (get = 0, set = 0 ; get < dec.length() ; set++, get++)

               //·ÀÖ¹urlÊäÈëkey=c++Ê±±»½âÎö³É´íÎóµÄ½á¹û
               //       if (dec[get] == '+')
               //                 dec[set] = ' ';
               // Pluses in spaces.
               //       else

               if (dec[get] == '%')
               {
                        dec[set] = HexToChar(dec[get + 1], dec[get + 2]);
                        get += 2;
               }
               // Hex values in their represented char.
               else
                        dec[set] = dec[get];
        
        dec.resize(set);

       // Cut the rest of the buffer.
       return dec;
}


bool BlenderParser::ParseTermType(const string& queryTermTags,
                string& queryBrand,
                string& queryProduct,
                vector<QueryTermType>& termTypes)
{
    string src = Decode(queryTermTags);

    int flags = Qtags::JSON;
    flags = Qtags::TEXT;
    Qtags tags_obj;
    if (!tags_obj.Build(src, flags))
    {
        return false;
    }

    // ¼ÙÉèµÚÒ»¸öÆ·ÅÆ´ÊÎªÖÐÐÄÆ·ÅÆ´Ê
    bool found_brand = false;

    vector<stQTag> tags = tags_obj.GetQTags();
    for (vector<stQTag>::iterator it = tags.begin(); it != tags.end(); ++it)
    {
        const stQTag& qtag = (*it);
        bool ckeyTerm = false;

        if (qtag.flags)
        {
            queryProduct = qtag.entity;
            ckeyTerm = true;
        }

        if (not found_brand
                && "brand" == qtag.tagname)
        {
            queryBrand = qtag.entity;
            found_brand = true;
        }

        for (unsigned int j = 0; j < qtag.terms.size(); ++j)
        {
            string term_word = qtag.terms[j];
            QueryTermType term_type_info = {term_word, qtag.tagname, ckeyTerm};
            termTypes.push_back(term_type_info);
        }
    }

    return true;
}


std::string BlenderParser::ParseRoute(const string& source)
{
    std::string r;
    r.assign(source);
    if ( source.empty() )
    {
        return r;
    }

    for ( size_t i = 0; i < r.length(); i++ )
    {
        if ( ('0' <= r[i]) && (r[i] <= '9') )
        {
            continue;
        }
        // CM_NODE_TYPE
        switch(r[i])
        {
            case 's': r[i] = '0'; break; //searcher
            case 'w': r[i] = '1'; break; //wrapper-detail
            case 'm': r[i] = '2'; break; //merger
            case 'd': r[i] = '3'; break; //detail-merger
            case 'o': r[i] = '5'; break; //operation
            default:break;
        }
    }

    return r;
}

#endif

BLENDER_END;
