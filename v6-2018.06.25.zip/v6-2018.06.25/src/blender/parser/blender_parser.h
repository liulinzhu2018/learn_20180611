#ifndef BLENDER_QUERY_H_
#define BLENDER_QUERY_H_

#include "blender_header.h"
#include "jd_search_request.pb.h"
#include "blender_analysis_data.h"
#include "jd_merge_response.pb.h"
#include <boost/unordered_map.hpp>
#include <boost/unordered_set.hpp>
BLENDER_BEGIN;
//��ʱ���壬����ͳһ���̶����ļ�
struct QueryTermType
{
    std::string termWord;
    std::string termType;
    bool ckeyTerm;
};

class BlenderParser
{
public:
    static BlenderParser singleton()
    {
        return BlenderParser();
    }
    ~BlenderParser() {}

    /* parse blender input url */       
    void parseUrl(const std::string &url, blender::BlenderAnalysisData *analysisData);

    //����I_CommandParser��û�еĺ���
    static bool LocalQueryProcess(const std::string &url, blender::BlenderAnalysisData *analysisDat);
    static bool ParseCategory(const std::string& commandLine, std::vector<int>& m_hc_cid3s);
    static bool ParsePriceInterval(const std::string& commandLine, boost::unordered_map<int, std::pair<int, int> >& cid3ToPriceinterval);
    static std::string Decode(const std::string &cod);
    static char HexToChar(char c1, char c2);
    static bool ParseTermType(const std::string& queryTermTags,
                std::string& queryBrand,
                std::string& queryProduct,
                std::vector<QueryTermType>& termTypes);
    
    static int ParseShopDimension(const string &command);
    static std::string ParseRoute(const string& source);
    
private:
    BlenderParser() {}

};


BLENDER_END;
#endif

