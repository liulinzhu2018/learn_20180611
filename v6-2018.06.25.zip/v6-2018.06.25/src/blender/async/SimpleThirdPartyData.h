#ifndef __SIMPLE_THIRDPARTY_DATA_H__
#define __SIMPLE_THIRDPARTY_DATA_H__

#include <string>
#include <stdint.h>

namespace blender
{

struct SimpleThirdPartyData
{
public:
    int promotion_flag;
    int64_t id;
    std::string show_name;
    std::string url;
    std::string banner_url;
    std::string from;
	std::string desc;
	std::string exposal_url;

    SimpleThirdPartyData():
        promotion_flag(0),
        id(0)
    {
    }
};

}

#endif
