#ifndef __PROMOTIONS_DATA_H__
#define __PROMOTIONS_DATA_H__

#include "SimpleThirdPartyData.h"

#include <vector>
#include <string>

namespace blender
{

typedef SimpleThirdPartyData PromotionsDetail;

struct PromotionsResult
{
public:
    int type;
    bool intersection_valid;
    int intersect_valid_pagesize;
    std::vector<PromotionsDetail> info;
    std::string blacklist;
    std::string cid3;
    std::string cid2;
    std::string cid1;
    std::string addkey;
    std::string error;
    PromotionsResult():
        intersection_valid(false),
        intersect_valid_pagesize(0)
    {}
};

}

#endif
