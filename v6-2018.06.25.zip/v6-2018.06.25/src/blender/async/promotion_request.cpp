#include "promotion_request.h"
#include "def.h"
#include "concurrence.h"
#include "blender_analysis_data.h"
#include "blender_master.h"
#include "blender_header.h"
#include "blender_config.h"
#include <boost/lexical_cast.hpp>
#include "json/json.h"
#include "bld_global.h"
#include "blender_logdata.h"
#include "jdsz_logtrace_manager.h"
#include "encode_convert.h"
#include "category_tree_data.h"

using namespace blender;

const char* PromotionRequest::REQUEST_NAME_Promotion  = "promotion";
void PromotionRequest::makeParam(BlenderAnalysisData* analysisDat, bool has_promotion_id)
{
    std::string& request_url = _request.request_url;
    request_url.clear();
    if (!has_promotion_id)
    {
        request_url.append(search_frame::KEY_PARA).append("=").append(analysisDat->query()->_key()).append(analysisDat->promotions.addkey);
        request_url.append("&").append(search_frame::PAGE_SIZE_PARA).append("=").append(boost::lexical_cast<string>(_blender_conf->m_g_pm_limit));
        request_url.append("&sort_type=sort_pc_activity_desc");

        if (analysisDat->promotions.blacklist.empty() == false)
            request_url.append("&pm_blist=").append(analysisDat->promotions.blacklist);

        if (analysisDat->promotions.cid1.empty() == false)
            request_url.append("&cid1=").append(analysisDat->promotions.cid1);

        if (analysisDat->promotions.cid2.empty() == false)
            request_url.append("&cid2=").append(analysisDat->promotions.cid2);

        if (analysisDat->promotions.cid3.empty() == false)
            request_url.append("&cid3=").append(analysisDat->promotions.cid3);
    }  
    else
    {
        //request_url.append(analysisDat->_promotion_id_list);
    }
    setCacheUrl(request_url);
    _request.__isset.request_url = true;
    BLD_DEBUG(analysisDat->logStream(), "SetRequest SearchRequest.request_url:"<<request_url.c_str());
}


inline bool PomotionValid(BlenderAnalysisData *_analysisData)
{
    _analysisData->promotion_online_valid = true; /*(search_frame::PromotionsService::_promotion_online_valid == 1);*/

    if (_analysisData->blenderConf()->m_g_pm_valid == false)
        _analysisData->promotions.error.assign("conf");
    else if (_analysisData->promotion_url_valid == false)
        _analysisData->promotions.error.assign("url");
    else if (_analysisData->promotion_online_valid == false)
        _analysisData->promotions.error.assign("online");
    else if (_analysisData->promotion_qp_valid == false)
        _analysisData->promotions.error.assign("qp");

    bool flag = (_analysisData->blenderConf()->m_g_pm_valid  &&
            _analysisData->promotion_url_valid        &&
            _analysisData->promotion_online_valid     &&
            _analysisData->promotion_qp_valid);

    _analysisData->promotions_flag = flag;

    return flag;
}


inline bool ShouldGetPromotionsData(BlenderAnalysisData* _analysisData, const jd::search::request::JdSearchQuery* pbQuery)
{
    bool flag = (pbQuery->_sort_type().compare(search_frame::DEFAULT_SORTER_VALUE)==0);

    if (flag == false)
    {
        _analysisData->promotions.error.assign("sort");
    }

    if (flag && (pbQuery->_expression_key().empty() == false))
    {
        vector<string> tmp;
        vector<string> keys = blender::GetStrings(pbQuery->_expression_key(), search_frame::FQUERY_SPLITER);
        size_t key_size = keys.size();
        std::string out;
        for (size_t i = 0; i < key_size; ++i)
        {
            tmp = blender::GetStrings(keys[i], search_frame::FQUERY_PARA_SPLITER);
            if ((tmp.size() == 2) &&
                    (tmp[0].compare("brand") == 0 || tmp[0].compare("publishers") == 0))
            {
                Normalize(tmp[1], out);
                _analysisData->promotions.addkey.append(" ").append(out);
            }
            else
            {
                flag = false;
                _analysisData->promotions.error.assign("expression_key");
                break;
            }
        }
    }

    if (flag)
    {
        size_t filt_info_size = _analysisData->m_url_filt_info.size();
        for (size_t i = 0; i < filt_info_size; ++i)
        {
            const std::string& filter_name = _analysisData->m_url_filt_info[i].first;
            const std::string& value = _analysisData->m_url_filt_info[i].second;
            if (filter_name.compare("cid2") == 0)
            {
                _analysisData->promotions.cid2 = _analysisData->m_url_filt_info[i].second;
            }
            else if (filter_name.compare("catid") == 0)
            {
                _analysisData->promotions.cid3 = _analysisData->m_url_filt_info[i].second;
            }
            else if (filter_name.compare("otc") == 0)
            {
                continue;
            }
            else if ((filter_name == "productext2") && (value == "b15v0") && (1 == filt_info_size) )
            {
                continue;
            }
            else
            {
                flag = false;
                _analysisData->promotions.error.assign("filt_type");
                break;
            }
        }
    }

    _analysisData->promotions_flag = flag;
    return flag;
}


void ProcessPromotionsRequest(BlenderAnalysisData* analysisDat, jd::search::request::JdSearchQuery* query)
{
    jd_search_merger::CategoryTree &cate_tree = *(CategoryTreeData::getInstance()->_cat_tree);
    bool cate_flag = false;

    if (analysisDat->promotions.cid2.empty() == false)
    {
        std::string cid2_str_param = analysisDat->promotions.cid2;
        boost::to_lower(cid2_str_param);

        const char* p = cid2_str_param.c_str();
        const char* pl = strchr(p, 'l');
        const char* pm = strchr(p, 'm');

        if (pl && pm)
        {
            std::string& cid2_str = analysisDat->promotions.cid2;
            cid2_str = cid2_str_param.substr(pl-p+1, pm-pl-1);

            try
            {
                int cid2 = boost::lexical_cast<int>(cid2_str);
                int cid1 = cate_tree.ParentCatID(cid2);
                analysisDat->promotions.cid1 = boost::lexical_cast<std::string>(cid1);
                cate_flag = true;
            }
            catch (...)
            {
            }
        }
    }
    else if (analysisDat->promotions.cid3.empty() == false)
    {
        std::string cid3_str_param = analysisDat->promotions.cid3;
        boost::to_lower(cid3_str_param);

        const char* p = cid3_str_param.c_str();
        const char* pl = strchr(p, 'l');
        const char* pm = strchr(p, 'm');

        if (pl && pm)
        {
            std::string cid3_str = cid3_str_param.substr(pl-p+1, pm-pl-1);

            try
            {
                int cid3 = boost::lexical_cast<int>(cid3_str);
                int cid2 = cate_tree.ParentCatID(cid3);
                int cid1 = cate_tree.ParentCatID(cid2);
                analysisDat->promotions.cid2 = boost::lexical_cast<std::string>(cid2);
                analysisDat->promotions.cid1 = boost::lexical_cast<std::string>(cid1);
                cate_flag = true;
            }
            catch (...)
            {
            }
        }
    }

    if ( _blender_conf->m_g_pm_hc_cate_filt == false )
    {
        analysisDat->promotions.cid2.clear();
        analysisDat->promotions.cid1.clear();
        return;
    }

    const jd::search::request::QPResult &qp_result = query->_qp_result();
    if ( (cate_flag == false) && (qp_result._hc_cid3s_size() > 0) )
    {
        analysisDat->promotions.cid3.clear();
        analysisDat->promotions.cid2.clear();
        analysisDat->promotions.cid1.clear();
        cate_flag = true;

        for (int i = 0; i < qp_result._hc_cid3s_size(); ++i)
        {
            int cid3 = qp_result._hc_cid3s(i);
            int cid2 = cate_tree.ParentCatID(cid3);
            int cid1 = cate_tree.ParentCatID(cid2);

            try
            {
                analysisDat->promotions.cid3.append(boost::lexical_cast<std::string>(cid3)).append(",");
                analysisDat->promotions.cid2.append(boost::lexical_cast<std::string>(cid2)).append(",");
                analysisDat->promotions.cid1.append(boost::lexical_cast<std::string>(cid1)).append(",");
            }
            catch (...)
            {
                cate_flag = false;
                break;
            }
        }
    }

    if ( (cate_flag == false) && (qp_result._hc_cid2s_size() > 0 ))
    {
        analysisDat->promotions.cid3.clear();
        analysisDat->promotions.cid2.clear();
        analysisDat->promotions.cid1.clear();
        cate_flag = true;

        for (int i = 0; i < qp_result._hc_cid2s_size(); ++i)
        {
            int cid2 = qp_result._hc_cid2s(i);
            int cid1 = cate_tree.ParentCatID(cid2);

            try
            {
                analysisDat->promotions.cid2.append(boost::lexical_cast<std::string>(cid2)).append(",");
                analysisDat->promotions.cid1.append(boost::lexical_cast<std::string>(cid1)).append(",");
            }
            catch (...)
            {
                cate_flag = false;
                break;
            }
        }
    }

    if ( (cate_flag == false) && (qp_result._hc_cid1s_size() > 0))
    {
        analysisDat->promotions.cid3.clear();
        analysisDat->promotions.cid2.clear();
        analysisDat->promotions.cid1.clear();
        cate_flag = true;

        for (int i = 0; i < qp_result._hc_cid1s_size(); ++i)
        {
            int cid1 = qp_result._hc_cid1s(i);

            try
            {
                analysisDat->promotions.cid1.append(boost::lexical_cast<std::string>(cid1)).append(",");
            }
            catch (...)
            {
                cate_flag = false;
                break;
            }
        }
    }

    if (cate_flag == false)
    {
        analysisDat->promotions.cid2.clear();
        analysisDat->promotions.cid1.clear();
    }
}


int PromotionRequest::reqPromotion()
{
    BlenderAnalysisData *_analysisData = master()->analysisData();
    
    if ( PomotionValid(_analysisData) && ShouldGetPromotionsData(_analysisData, _analysisData->query()) )
    {
        ProcessPromotionsRequest(_analysisData, _analysisData->query());

        makeParam(_analysisData, false);
        if ( 0 != asyncSend() )
        {
            Trace_cnt(BLD_STAT_PM_ERROR, 1, _analysisData->m_ump2_tag);
            BLD_ERROR(master()->logStream(), master()->getStrSeqno() <<  "sendRequestAsync(promotion) failed"); 
            return -1;
        }

        _analysisData->promotions_getting = true;
        return 0;
    }

    //不需要发送活动
    return 9;
}


int PromotionRequest::handelResponse(int err_no)
{
    BlenderAnalysisData* _analysisData = master()->analysisData();
    if ( 0 != _response.error.error_code )
    {
        BLD_WARN(_analysisData->logStream(), "GetResponse _response.error.error_code:"<<_response.error.error_code);
        err_no = 200 + _response.error.error_code;
    }

    if ( 0 == err_no )
    {
        std::vector< ::si_search::ActivityDocData>& ret_vec = _response.activity_result_data.doc_data;
        size_t sz = ret_vec.size();
        if (sz == 0)
        {
            _analysisData->promotions.error.assign("empty");
        }
        else
        {
            master()->logData()->ext_add("pminsert_size", cast2string(sz));
            //_analysisData->promotions.type = 0;
            std::vector<PromotionsDetail>& info = _analysisData->promotions.info;
            info.resize(sz);

            for (size_t i = 0; i < sz; ++i)
            {
                PromotionsDetail& info_item = info[i];
                ::si_search::ActivityDocData& ret_vec_item = ret_vec[i];

                info_item.from.assign("promotions");
                if(ret_vec_item.__isset.activity_id)
                {
                    info_item.id = ret_vec_item.activity_id;
                }

                if(ret_vec_item.__isset.activity_name)
                {
                    info_item.show_name = ret_vec_item.activity_name;
                }

                if(ret_vec_item.__isset.activity_url)
                {
                    info_item.url = ret_vec_item.activity_url;
                }

                if(ret_vec_item.__isset.banner_url)
                {
                    info_item.banner_url = ret_vec_item.banner_url;
                }

                if(ret_vec_item.__isset.description)
                {
                    info_item.desc = ret_vec_item.description;
                }
            }
        }
    }

    _analysisData->promotion_req_err_no = err_no;
    _analysisData->promotions_flag = !_analysisData->promotions.info.empty();
    if ( 0 != err_no )
    {
        Trace_cnt(BLD_STAT_PM_ERROR, 1, _analysisData->m_ump2_tag); 
    }
    return err_no;
}
