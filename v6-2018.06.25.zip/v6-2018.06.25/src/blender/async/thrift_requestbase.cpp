
#include "thrift_requestbase.h"

using namespace blender;

void ThriftRequestBase::setCacheUrl(const std::string &url)
{
    m_cacheUrl = url;
    m_cacheKey = name() + "_" + JimDBClient::md5string(m_cacheUrl);
}
