#ifndef __BLD_SYNC_REQUEST_BASE_H__
#define __BLD_SYNC_REQUEST_BASE_H__

#include "http_session.h"
#include "blender_request.h"
#include "bld_timer.h"
#include "log_trace.h"
#include "blender_header.h"

using namespace time_util;
namespace blender{

class AsyncRequestBase : public BlenderRequest
{
public:
    AsyncRequestBase(const std::string &name, BlenderMaster_ptr master, int msg_type, BlenderRequest::ASYNCType rt = BlenderRequest::REQUEST_SYNC_SERVICE)
        : BlenderRequest(name, master, msg_type, rt)
    {
    }
    
    virtual ~AsyncRequestBase(){}

    /*return <0:error, =0:send ok, >0:no need send*/
    int asyncSend();

    /*
    send and wait recv
    return <>0:error, =0:ok
    */
    virtual int syncSendRecv() = 0;

    /*
    handle reponse info 
    input : err_no, 0--success, others has error
    output:return <>0:error, =0:ok
    */
    virtual int handelResponse(int err_no) = 0;

    virtual std::string serviceName() = 0;

protected:
    static util::Mutex g_service_lock;
};

class SyncServiceMng
{
public:
    static SyncServiceMng* instance();
    void* get(const std::string &name, bool &exist) const;
    void set(const std::string &name, void* client);
private:
    std::map<std::string, void*> m_clientMap;
};

}//end namespace
#endif

