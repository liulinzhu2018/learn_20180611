#include "artc_request.h"
#include "concurrence.h"
#include "encode_convert.h"
#include "url_code.h"
#include "def.h"
#include "blender_analysis_data.h"
#include "blender_header.h"
#include "qp_state.h"
#include "blender_config.h"
#include "json/json.h"
#include <sstream>
#include <boost/lexical_cast.hpp>
#include "jdsz_logtrace_manager.h"
#include "bld_global.h"
#include "def.h"
#include "encode_convert.h"
#include "scene_artc_strategy.h"

using namespace blender;
const char* ArticleRequest::REQUEST_NAME_ArtcInsertTop   = "artc_insert_top";
const char* ArticleRequest::REQUEST_NAME_ArtcTab         = "artctab";
const char* ArticleRequest::REQUEST_NAME_ArtcInsertDaren = "artc_insert_daren";

int ArticleRequest::request(const std::string &req_url, std::string &req_info)
{
    _request.request_url = req_url;
    setCacheUrl(req_url);
    BLD_DEBUG(master()->logStream(), "SetRequest: ArticleRequest("<<name()<<").request_url:" << req_url);
    if ( 0 != asyncSend() )
    {
        Trace_cnt(BLD_STAT_ARTC_ERROR, 1);
        BLD_ERROR(master()->logStream(), master()->getStrSeqno() <<  "ArticleRequest asyncSend faild:"<<name()); 
        req_info = "blender: send req failed";
        return -1;
    }
    return 0;
}


inline bool ArtcInsertValid(BlenderAnalysisData* _analysisData)
{
    if ( !_analysisData->blenderConf()->m_g_artc_insert_valid )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcInsertValid cfg invalid");
        _analysisData->m_artc_insert_info = "cfg:artc_insert_valid invalid";
        return false;
    }
    if ( !_analysisData->m_artc_insert_url_valid )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcInsertValid url invalid");
        _analysisData->m_artc_insert_info = "url:artc_tab_url_validinvalid";
        return false;
    }
    //_analysisData->m_artc_insert_op_valid = true;
    if ( !_analysisData->m_artc_insert_op_valid )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcInsertValid op invalid");
        _analysisData->m_artc_insert_info = "op:key not in white list";
        return false;
    }
    if ( _analysisData->blenderConf()->m_g_artc_insert_pos_vec.size() == 0 )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcInsertValid cfg:artc_insert_pos_vec empty");
        _analysisData->m_artc_insert_info = "cfg:artc_insert_pos_vec empty";
        return false;
    }
    if ( ((_analysisData->query()->_start_pos() + _analysisData->query()->_page_size()) < _analysisData->blenderConf()->m_g_artc_insert_pos_vec[0])
        || (_analysisData->blenderConf()->m_g_artc_insert_pos_vec[_analysisData->blenderConf()->m_g_artc_insert_pos_vec.size() - 1] < _analysisData->query()->_start_pos())
            )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcInsertValid line: over insert range");
        _analysisData->m_artc_insert_info = "page:over insert range";
        return false;
    }
    if ( _analysisData->query()->_qp_result()._hc_cid3s_size() == 0 )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcInsertValid line:qp no hc_cid3s");
        _analysisData->m_artc_insert_info = "line:qp no hc_cid3s";
        return false;
    }
    return true;
}


int ArticleRequest::reqArtcInsertTop()
{
    BlenderAnalysisData *_analysisData = master()->analysisData();

    if ( ArtcInsertValid(_analysisData) )
    {
        std::string req_url;
        std::string urlenc_key;
        utils::urlEncode(_analysisData->query()->_original_key(), urlenc_key);
        req_url.append("key=").append(urlenc_key);
        req_url.append("&enc_url_gbk=yes");
        req_url.append("&page=").append(boost::lexical_cast<std::string>(_analysisData->query()->_page_index()));
        req_url.append("&pagesize=").append(boost::lexical_cast<std::string>(_analysisData->blenderConf()->m_g_artc_insert_pos_vec.size()));
        req_url.append("&client=").append(_analysisData->query()->_client_id());
        req_url.append("&sort_type=").append(_blender_conf->m_g_artc_insert_sort_type);
        req_url.append("&doc_max_len=4096");
        req_url.append("&filt_type=").append(_blender_conf->m_g_artc_insert_filt_type);
        req_url.append(";cid3,");
        jd::search::request::QPResult* qpResult = _analysisData->query()->mutable__qp_result();
        for ( int i = 0; i < qpResult->_hc_cid3s_size(); i++ )
        {
            int cid = qpResult->_hc_cid3s(i);
            if ( i > 0 )
            {
                req_url.append("||");
            }
            req_url.append("L").append(boost::lexical_cast<std::string>(cid));
            req_url.append("M").append(boost::lexical_cast<std::string>(cid));
        }

        return request(req_url, _analysisData->m_artc_insert_info);
    }

    //不需要发送
    return 9;
}


inline bool ArtcTabValid(BlenderAnalysisData* _analysisData)
{
    if ( !_analysisData->blenderConf()->m_g_artc_tab_valid )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcTabValid cfg invalid");
        _analysisData->m_artc_tab_info = "cfg:artc_tab_valid invalid";
        return false;
    }
    if ( !_analysisData->m_artc_tab_url_valid )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcTabValid url invalid");
        _analysisData->m_artc_tab_info = "url:artc_tab_url_valid invalid";
        return false;
    }
    if ( _analysisData->m_qp_is_brand_query )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "is brand query");
        _analysisData->m_artc_tab_info = "url:is brand query";
        return false;
    }
    //_analysisData->m_artc_tab_op_valid = true;
    if ( !_analysisData->m_artc_tab_op_valid )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcTabValid op invalid");
        _analysisData->m_artc_tab_info = "op:key not in white list";
        return false;
    }
    if ( _analysisData->query()->_page_index() > 1 )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "not first page");
        _analysisData->m_artc_tab_info = "not first page";
        return false;

    }
    return true;
}

int ArticleRequest::reqArtcTab()
{
    BlenderAnalysisData *_analysisData = master()->analysisData();

    if ( ArtcTabValid(_analysisData) )
    {
        std::string req_url;
        std::string urlenc_key;
        utils::urlEncode(_analysisData->query()->_original_key(), urlenc_key);
        req_url.append("key=").append(urlenc_key);
        req_url.append("&enc_url_gbk=yes");
        req_url.append("&client=1516345463041");
        if ( _blender_conf->m_g_artc_tab_only_rcount_valid )
        {
            req_url.append("&only_rcount=yes");
        }
        else
        {
            req_url.append("&page=").append(boost::lexical_cast<std::string>(_analysisData->query()->_page_index()));
            req_url.append("&pagesize=").append(boost::lexical_cast<std::string>(_blender_conf->m_g_artc_tab_minisize + 10));
            req_url.append("&sort_type=").append(_blender_conf->m_g_artc_tab_sort_type);
            req_url.append("&doc_max_len=4096");
        }
        if ( _analysisData->m_artc_tab_filt_type.empty() )
        {
            req_url.append("&filt_type=").append(_analysisData->blenderConf()->m_g_artc_tab_filt_type);
        }
        else
        {
            req_url.append("&filt_type=").append(_analysisData->m_artc_tab_filt_type);
        }

        return request(req_url, _analysisData->m_artc_tab_info);
    }

    //不需要发送
    return 9;
}


inline bool ArtcDarenInsertValid(BlenderAnalysisData* _analysisData)
{
    // if ( _analysisData->m_qp_is_brand_query )
    // {
    //     BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "is brand query");
    //     _analysisData->m_artc_daren_insert_info = "url:is brand query";
    //     return false;
    // }
#if 1
    _analysisData->m_artc_daren_insert_op_valid = true;
#else
    if ( !_analysisData->m_artc_daren_insert_op_valid )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcDarenInsertValid op invalid");
        _analysisData->m_artc_daren_insert_info = "op:key not in white list";
        return false;
    }
#endif

    if ( _analysisData->query()->_qp_result()._hc_cid3s_size() == 0 )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcDarenInsertValid line:qp no hc_cid3s");
        _analysisData->m_artc_daren_insert_info = "line:qp no hc_cid3s";
        return false;
    }

    //filt_type blacklist check
    for ( size_t i = 0; i < _analysisData->m_url_filt_info.size(); ++i )
    {
        std::pair<std::string, std::string> &kv = _analysisData->m_url_filt_info[i];

        int ret = checkFiltTypeInBlacklist(kv, _blender_conf->m_g_artc_daren_insert_filttype_blacklist);
        if ( 0 == ret )
        {
            //in blacklist
            _analysisData->m_artc_daren_insert_info = "filt_type: in blacklist key:" + kv.first;
            return false;
        }
    }

    if ( _analysisData->m_artc_insert_op_wblist == 1 ) //op������
    {   
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcDarenInsertValid op:key is black list");
        _analysisData->m_artc_daren_insert_info = "op: force not insert";
        return false;
    }
    else if ( _analysisData->m_artc_insert_op_wblist == 0 )//op������,���ÿ��Ƿ�qp�İ�������
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcDarenInsertValid op:key  white list");
        _analysisData->m_artc_daren_insert_info = "op: force insert";
    }
    else
    {   
        //full data
        BlenderQPState::getExtraIdsBy(_analysisData->query()->mutable__qp_result(), "article_insert", _analysisData->m_artc_qp_whitelist);
        bool in_qp_whitelist = false;
        for(size_t idx = 0;  idx < _analysisData->m_artc_qp_whitelist.size(); idx++)
        {
            if( 2 == _analysisData->m_artc_qp_whitelist[idx] )
            {
                in_qp_whitelist = true;
                break;
            } 
        }

        //ab data
        if ( !in_qp_whitelist )
        {
            if ( _blender_conf->m_g_artc_daren_insert_ab_mtest_set.empty() )
            {
                BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcDarenInsertValid conf mtest invalid");
                _analysisData->m_artc_daren_insert_info = "line:conf mtest invalid";
                return false;
            }

            if ( _analysisData->m_mtest_set.empty() )
            {
                BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcDarenInsertValid no mtest in mtest list");
                _analysisData->m_artc_daren_insert_info = "line:no mtest in mtest list";
                return false;
            }

            std::vector<std::string> mtest_int;
            std::set_intersection(_blender_conf->m_g_artc_daren_insert_ab_mtest_set.begin(), _blender_conf->m_g_artc_daren_insert_ab_mtest_set.end(),
                _analysisData->m_mtest_set.begin(), _analysisData->m_mtest_set.end(),
            std::inserter(mtest_int, mtest_int.begin()));
            if ( mtest_int.empty() )
            {
                BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcDarenInsertValid not in mtest list");
                _analysisData->m_artc_daren_insert_info = "line:not in mtest";
                return false;
            }

            std::vector<long> artc_ab_wl;
            BlenderQPState::getExtraIdsBy(_analysisData->query()->mutable__qp_result(), "article_insert_ab", artc_ab_wl);
            if ( artc_ab_wl.empty() )
            {
                BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcDarenInsertValid not in qp article_insert_ab");
                _analysisData->m_artc_daren_insert_info = "line:not in qp article_insert_ab";
                return false;
            }

            for(size_t idx = 0;  idx < artc_ab_wl.size(); idx++)
            {
                if( 2 == artc_ab_wl[idx] )
                {
                    in_qp_whitelist = true;
                    break;
                } 
            }
        }

        if( !in_qp_whitelist )
        {
            BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ArtcDarenInsertValid qp:key not white list ");
            _analysisData->m_artc_daren_insert_info = "qp:key not white list ";
            return false;
        }
    }

    return true;
}


int ArticleRequest::reqArtcInsertDaren()
{
    BlenderAnalysisData *_analysisData = master()->analysisData();

    if ( ArtcDarenInsertValid(_analysisData) )
    {
        std::string req_url;
        std::string urlenc_key;
        utils::urlEncode(_analysisData->query()->_original_key(), urlenc_key);
        req_url.append("key=").append(urlenc_key);

        if(_analysisData->m_enc_url_gbk)
        {
            req_url.append("&enc_url_gbk=yes");
        }
        //req_url.append("&page=").append(boost::lexical_cast<std::string>(_analysisData->query()->_page_index()));
        req_url.append("&page=1");
        // req_url.append("&pagesize=").append(boost::lexical_cast<std::string>(_blender_conf->m_g_artc_daren_insert_size));
        string version = _analysisData->blenderConf()->getVersion(_analysisData->m_app_version);
        _analysisData->m_app_version_config = version;
        std::map<std::string,int>::iterator sizeit = _analysisData->blenderConf()->m_g_appv2artc_insert_size.find(version);
        if(sizeit != _analysisData->blenderConf()->m_g_appv2artc_insert_size.end() )
        {
             req_url.append("&pagesize=").append(boost::lexical_cast<std::string>(sizeit->second) );
        }
        else
        {
            req_url.append("&pagesize=").append(boost::lexical_cast<std::string>(_blender_conf->m_g_artc_daren_insert_size));
        }
        req_url.append("&client=1524898159045");
        req_url.append("&sort_type=").append(_blender_conf->m_g_artc_daren_insert_sort_type);
        req_url.append("&doc_max_len=4096");
        // req_url.append("&filt_type=").append(_blender_conf->m_g_artc_daren_insert_filt_type);
        std::map<std::string,std::string>::iterator filtit = _analysisData->blenderConf()->m_g_appv2artc_filt_type.find(version);
        if(filtit != _analysisData->blenderConf()->m_g_appv2artc_filt_type.end() )
        {
             req_url.append("&filt_type=").append(filtit->second );
        }
        else
        {
            req_url.append("&filt_type=").append(_blender_conf->m_g_artc_daren_insert_filt_type);
        }
#if 1
        req_url.append(";cid3,");
        jd::search::request::QPResult* qpResult = _analysisData->query()->mutable__qp_result();
        for ( int i = 0; i < qpResult->_hc_cid3s_size(); i++ )
        {
            int cid = qpResult->_hc_cid3s(i);
            if ( i > 0 )
            {
                req_url.append("||");
            }
            req_url.append("L").append(boost::lexical_cast<std::string>(cid));
            req_url.append("M").append(boost::lexical_cast<std::string>(cid));
            break; //靠靠靠靠靠
        }
#endif
        if ( !_blender_conf->m_g_need_personalize_degrade && !_analysisData->m_cache_persional_down )
        {
            if ( !_analysisData->query()->_user_pin().empty() )
            {
                req_url.append("&user_pin=").append(_analysisData->query()->_user_pin());
            }
            if ( !_analysisData->m_uuid.empty() )
            {
                req_url.append("&uuid=").append(_analysisData->m_uuid);
            }
            if ( !_analysisData->query()->_mtest().empty() )
            {
                req_url.append("&mtest=").append(_analysisData->query()->_mtest());
            }
        }
        _analysisData->m_artc_daren_req_url = req_url;
        return request(req_url, _analysisData->m_artc_daren_insert_info);
    }

    //不需要发送
    return 9;
}

int ArticleRequest::handelResponse(int err_no)
{
    BlenderAnalysisData* _analysisData = master()->analysisData();
    if ( REQUEST_NAME_ArtcInsertTop == name() )
    {
        if ( (0 == err_no) && (_response.error.error_code == vertical_search::ResultCode::OK) )
        {
            _analysisData->m_artc_insert_result_json = _response.json_result_data;
            master()->logData()->ext_add("artcinserttop", "ok");
        }
        else
        {
            if ( _response.error.error_code != vertical_search::ResultCode::OK ) {
                err_no = 200 + _response.error.error_code;
            }
            Trace_cnt(BLD_STAT_ARTC_ERROR, 1);
            _analysisData->m_artc_insert_info.append("remote: error_name:").append(_response.error.error_name).append(" explain:").append(_response.error.explain);
            BLD_ERROR(_analysisData->logStream(), "attc_insert_top response: err:"<<_response.error.error_code<<" error_name:"<<_response.error.error_name << " explain:"<<_response.error.explain);
        }
        _analysisData->m_artc_insert_req_err_no = err_no;
    }
    else if ( REQUEST_NAME_ArtcInsertDaren == name() )
    {
        if ( (0 == err_no) && (_response.error.error_code == vertical_search::ResultCode::OK) )
        {
            _analysisData->m_artc_daren_insert_result_json = _response.json_result_data;
            master()->logData()->ext_add("artcinsertdaren", "ok");
        }
        else
        {
            if ( _response.error.error_code != vertical_search::ResultCode::OK ) {
                err_no = 200 + _response.error.error_code;
            }
            _analysisData->m_artc_daren_insert_info.append("remote: error_name:").append(_response.error.error_name).append(" explain:").append(_response.error.explain);
            BLD_ERROR(_analysisData->logStream(), "artc_daren_insert response: err:"<<_response.error.error_code<<" error_name:"<<_response.error.error_name << " explain:"<<_response.error.explain);
            Trace_cnt(BLD_STAT_ARTC_ERROR, 1); 
        }
        _analysisData->m_artc_daren_insert_req_err_no = err_no;
    }
    else if(REQUEST_NAME_ArtcTab == name() )
    {
        if ( (0 == err_no) && (_response.error.error_code == vertical_search::ResultCode::OK) )
        {
            _analysisData->m_artc_tab_result_json = _response.json_result_data;
            Json::Value tab_json;
            Json::Reader jreader;
            if ( !jreader.parse(_response.json_result_data, tab_json) )
            {
                BLD_ERROR(_analysisData->logStream(), "BLENDER_MSG_ARTC_TAB parse error:"<<_response.json_result_data);
                _analysisData->m_artc_tab_info = "bld:parse json_result_data failed";
            }
            else
            {
                if ( tab_json.isMember("Head") && tab_json["Head"].isObject() 
                        && tab_json["Head"].isMember("Summary") && tab_json["Head"]["Summary"].isObject() 
                        && tab_json["Head"]["Summary"].isMember("ResultCount") && tab_json["Head"]["Summary"]["ResultCount"].isString() )
                {
                    _analysisData->m_artc_tab_ret_size = boost::lexical_cast<int>(tab_json["Head"]["Summary"]["ResultCount"].asString());
                    if ( 0 == _analysisData->m_artc_tab_ret_size )
                    {
                        _analysisData->m_artc_tab_info = "remote: retun size == 0";
                    }
                    else
                    {
                        master()->logData()->ext_add("artctab_size", cast2string(_analysisData->m_artc_tab_ret_size));
                    }
                }
                else
                {
                    _analysisData->m_artc_tab_info = "remote: retun error no Head->Summary->ResultCount";
                }
            }
        }
        else
        {
            if ( _response.error.error_code != vertical_search::ResultCode::OK ) {
                err_no = 200 + _response.error.error_code;
            }
            _analysisData->m_artc_tab_info.append("remote: error_name:").append(_response.error.error_name).append(" explain:").append(_response.error.explain);
            BLD_ERROR(_analysisData->logStream(), "artc_tab response: err:"<<_response.error.error_code<<" error_name:"<<_response.error.error_name << " explain:"<<_response.error.explain);
            Trace_cnt(BLD_STAT_ARTC_ERROR, 1);
        }

        _analysisData->m_artc_tab_req_err_no = err_no;
    }
    else
    {
        BLD_ERROR(_analysisData->logStream(), "SearchRequest:: Unkown name:"<<name());
        err_no = 301;
    }

    return err_no;
}
