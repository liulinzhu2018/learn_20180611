
#include "scene_request.h"
#include "blender_config.h"
#include "jdsz_logtrace_manager.h"
#include "global.h"
#include "bld_global.h"
#include "bld_global.h"
#include "qp_state.h"

using namespace blender;

inline bool SceneRequest::sceneInsertValid(BlenderAnalysisData* _analysisData)
{
    //parse scene id
    BlenderQPState::getExtraIdsBy(_analysisData->query()->mutable__qp_result(), "scene_id2", _analysisData->m_scene2_insert_ids);     
    if( _analysisData->m_scene2_insert_ids.size() > 0 )
    {
        m_scene_keys.reserve( _analysisData->m_scene2_insert_ids.size() );
        for(size_t i = 0; i < _analysisData->m_scene2_insert_ids.size(); i++ )
        {
            try{
                string scene2_id_str = boost::lexical_cast<string>(_analysisData->m_scene2_insert_ids[i]);

                if ( !_analysisData->query()->_normalized_key().empty() )
                {
                    m_scene_keys.push_back( scene2_id_str + "_" + _analysisData->query()->_normalized_key() );
                }
                else
                {
                    m_scene_keys.push_back( scene2_id_str + "_" + _analysisData->query()->_original_key() );
                }
            }
            catch(...)
            {
                continue;
            }
        }
    }

    if ( m_scene_keys.empty() )
    {
        _analysisData->m_scene2_insert_info = "qp : no scene2_id";
        return false;
    }

    for ( size_t i = 0; i < _analysisData->m_url_filt_info.size(); ++i )
    {
        std::pair<std::string, std::string> &kv = _analysisData->m_url_filt_info[i];
        int ret = checkFiltTypeInWhitelist(kv, _blender_conf->m_g_scene_insert_filttype_whitelist);
        if ( ret < 0 )
        {
            //key not in whitelist
            _analysisData->m_scene2_insert_info = "filt_type not in whitelist key:" + kv.first;
            return false;
        }
    }

    return true;
}


int SceneRequest::asyncReqScene()
{
	BlenderAnalysisData *_analysisData = master()->analysisData();
    if ( sceneInsertValid(_analysisData) )
    {
        int ret = asyncGet(m_scene_keys);
        if( 0 != ret )
        {
            BLD_ERROR(master()->logStream(), master()->getStrSeqno()<<"get scene failed:"<<ret<<" size:"<<m_scene_keys.size());
        }
        return ret;
    }

    return -9;
}



int SceneRequest::handelResponse(int err_no)
{
	const std::vector<std::string> _values = values();
	if ( (0 == err_no) && !_values.empty() )
	{
        int _in_size = 0;
		const std::vector<std::string> _keys = keys();
		for ( size_t i = 0; i < _values.size(); i++ )
		{
			if ( !_values[i].empty() && (i < _keys.size()) )
			{
				master()->analysisData()->m_scene2_insert_json.insert(
					std::make_pair<std::string, std::string>(_keys[i], _values[i])
					);
                _in_size++;
			}
		}
        master()->logData()->ext_add("sceneinsert_size", cast2string(_in_size));
        master()->analysisData()->m_scene2_insert_info = "get scene ok";
        return 0;
	}
	else
	{
		master()->analysisData()->m_scene2_insert_info = "scene_jimdb : can not get scene of scene2_id ";
	}
    return -1;
}

