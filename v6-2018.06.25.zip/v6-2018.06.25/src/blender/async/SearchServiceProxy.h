#ifndef __ARTC_SEARCH_SERVICE_PROXY_H__
#define __ARTC_SEARCH_SERVICE_PROXY_H__ 

#include "VerticalSearchService.h"
#include "thrift_proxy.h"

using namespace std;
using namespace apache::thrift;
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;

using namespace boost;
using namespace ThriftZookeeper;

namespace vertical_search
{

class VerticalSearchServiceProxy : public VerticalSearchServiceIf 
{
	DECLARE_THRIFT_PROXY(VerticalSearchService);
public:
	void search(VerticalSearchResult& _return, const VerticalSearchRequest& request)
    {
		INVOKE_AND_RETURN_WITHIN_3_ATTEMPTS_NEW(VerticalSearchService, search, _return, request);
	};

    PingResult::type ping()
    {
        return PingResult::PING_OK;
    }
};

}
#endif
