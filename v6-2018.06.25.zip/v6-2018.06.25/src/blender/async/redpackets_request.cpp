

#include "redpackets_request.h"
#include "blender_config.h"
#include "jdsz_logtrace_manager.h"
#include "redpacket_key_data.h"
#include "global.h"

using namespace blender;


int RedPacketsRequest::asyncReqRedPackets()
{
    if ( _blender_conf->m_g_redpackets_valid && master()->analysisData()->redpackets_url_valid )
    {
        int ret = 0;

        MsTimer timer;
        timer.Start();

        std::string m_normal_key; 
        if ( !clsGlobal::promotion_normalize(master()->analysisData()->query()->_original_key(), m_normal_key) )
        {
            BLD_ERROR(master()->logStream(), master()->getStrSeqno() << " promotion_normalize failed:" << master()->analysisData()->query()->_original_key());
            m_normal_key = master()->analysisData()->query()->_original_key();
        }
        
        bool is_redpackets_key = false;
        if ( _blender_conf->m_g_redpackets_use_local_file )
        {
            is_redpackets_key = RedPacketkeyData::getInstance()->is_red_packets_key(m_normal_key);
        }
        else
        {
            is_redpackets_key = master()->analysisData()->redpackets_is_key;
        }

        if ( is_redpackets_key )
        {
            return asyncGet(m_normal_key);
        }
        else
        {
            Trace_ratio(BLD_STAT_REDPKG_REQ_HIT_RATIO, false, master()->analysisData()->m_ump2_tag);
            BLD_DEBUG(master()->logStream(), master()->getStrSeqno() << " not red_packets key:" << m_normal_key);
            master()->logData()->_redenvelope_info = "invalid_nokey";
        }
        return -1;
    }
    else
    {
        master()->logData()->_redenvelope_info = "invalid_cfg-url";
    }
    return -2;
}



int RedPacketsRequest::handelResponse(int err_no)
{
    Trace_ratio(BLD_STAT_REDPKG_JIMDB_OK, 0 == err_no, master()->analysisData()->m_ump2_tag); 
    ump_report::report_tp(BLD_STAT_REDPKG_CALL, costUs(), 0 == err_no);

    const std::vector<std::string> _values = values();
    if ( (0 == err_no) && !_values.empty() )
    {
        master()->analysisData()->redpackets_result = _values[0];
        if ( master()->analysisData()->query()->_laoke_redpackage() )
        {
            master()->analysisData()->query()->set__laoke_redpackage(false);
        }
        Trace_ratio(BLD_STAT_REDPKG_REQ_HIT_RATIO, true, master()->analysisData()->m_ump2_tag);
        report_bussiness("red_envelope", true, master()->analysisData()->m_ump2_tag);
        master()->logData()->_redenvelope_info = "ok";
        return 0;
    }
    else
    {
        Trace_ratio(BLD_STAT_REDPKG_REQ_HIT_RATIO, false, master()->analysisData()->m_ump2_tag);
        report_bussiness("red_envelope", false, master()->analysisData()->m_ump2_tag);
        BLD_WARN(master()->logStream(), master()->getStrSeqno() << " no redpackage info :" << m_normal_key);
        master()->logData()->_redenvelope_info = "failed";
    }

    return err_no;
}
