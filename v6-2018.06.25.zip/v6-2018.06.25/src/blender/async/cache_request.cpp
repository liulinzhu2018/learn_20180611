
#include "cache_request.h"
#include "blender_config.h"

using namespace blender;

CacheRequest::CacheRequest(const std::string &name, BlenderMaster_ptr master, int msg_type, BlenderRequest::ASYNCType rt)
    : JimDBRequest(name, master, msg_type, rt)
{
    setTimoutMs(_blender_conf->m_g_query_cache_set_timeout);
}


DoudiRequest::DoudiRequest(const std::string &name, BlenderMaster_ptr master, int msg_type, BlenderRequest::ASYNCType rt)
    : JimDBRequest(name, master, msg_type, rt)
{
}
