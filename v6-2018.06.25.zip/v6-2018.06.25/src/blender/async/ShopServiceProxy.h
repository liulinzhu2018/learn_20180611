#ifndef __SHOP_SEARCH_SERVICE_PROXY_H__
#define __SHOP_SEARCH_SERVICE_PROXY_H__ 

#include "ShopSearchService.h"
#include "thrift_proxy.h"

using namespace std;
using namespace apache::thrift;
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;
using namespace si_search;

using namespace boost;

using namespace ThriftZookeeper;

class ShopSearchServiceProxy:public ShopSearchServiceIf 
{
	DECLARE_THRIFT_PROXY(ShopSearchService);
public:
	void ShopSearch(ShopSearchResult& _return, const ShopSearchRequest& request)
    {
		INVOKE_AND_RETURN_WITHIN_3_ATTEMPTS_NEW(ShopSearchService, ShopSearch, _return, request);
	};

    void ShopSearchJson(ShopSearchResult& _return, const ShopSearchRequest& request)
    {
    }

};

#endif
