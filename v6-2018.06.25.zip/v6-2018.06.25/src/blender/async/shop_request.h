#ifndef __JDS_SHOP_SERVICE_CLIENT_H__
#define __JDS_SHOP_SERVICE_CLIENT_H__
#include "ShopServiceProxy.h"
#include "pooled_client.h"
#include "thrift_requestbase.h"
#include "blender_logger.h"
#include <signal.h>
#include <pthread.h>
#include <list>
namespace blender
{
class BlenderAnalysisData;
class ShopRequest : public blender::ThriftRequestBase
{
    DEF_THRIFT_REQ_BASE(ShopSearchService, sp, ShopSearch)
    DEF_THRIFT_REQ_CACHE(sp)
public:
	static const char* REQUEST_NAME_ShopInsert;
	static const char* REQUEST_NAME_ShopEntry;
	static const char* REQUEST_NAME_ShopTab;
    ShopRequest(const std::string &name, BlenderMaster_ptr master, int blender_msg_type) 
        : ThriftRequestBase(name, master, blender_msg_type)
    {}

    virtual int handelResponse(int err_no);

    int reqShopInsert();
    int reqShopEntry();
    int reqShopTab();

private:
	void makeParam(BlenderAnalysisData* analysisDat, unsigned int shop_id = 0);
    void makeParam(BlenderAnalysisData* analysisDat, std::list<int> cids);

private:
    ShopSearchResult _response;
    ShopSearchRequest _request;
};
}

#endif

