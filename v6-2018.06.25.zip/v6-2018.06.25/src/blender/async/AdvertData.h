#ifndef __ADVERT_DATA_H__
#define __ADVERT_DATA_H__
#include "SimpleThirdPartyData.h"
#include <vector>
#include <string>
namespace blender
{
typedef SimpleThirdPartyData AdvertDetail;
struct AdvertResult
{
    int type;
    std::string error;
    std::vector<AdvertDetail> info;
    std::string cid3;
    std::string cid2;
    std::string cid1;
    std::string addkey;
    std::string blacklist;
    AdvertResult()
    {
    }
};
}
#endif

