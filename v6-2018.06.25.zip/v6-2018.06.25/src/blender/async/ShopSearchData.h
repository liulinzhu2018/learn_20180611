#ifndef __SHOP_SEARCH_DATA_H__
#define __SHOP_SEARCH_DATA_H__

#include <vector>
#include <string>
#include <map>
#include "stdint.h"

namespace blender
{
    enum SHOP_ERR { RESULT_EMPTY = 1, INTERSECTION_EMPTY = 2, UNKNOWN = 3, ALL_RIGHT = 4 };
    enum REQUEST_TYPE { REQUEST_SHOP_INTERSECTION = 1, REQUEST_SHOP_LIST = 2, REQUEST_SHOP_SINGLE = 3, DO_NOTHING = 4 };

    struct ShopInfoDetail
    {
        int32_t shop_id;
        int32_t vender_id;
        int32_t vender_type;
        int32_t shop_type;
        int32_t vender_total_score;
        int32_t vender_ware_score;
        int32_t vender_service_score;
        int32_t vender_effective_score;
        int32_t shop_icon;
        std::string shop_name;
        std::string shop_logo;
        std::string business_category;
        std::string main_brand;
        std::string pic_url;
        std::string summary;
        std::string shop_brief;

        ShopInfoDetail(int sid, int vid, int vtype, int stype, int vtscore, int vwscore, int vsscore,
                int vescore, int sico, std::string sname, std::string slogo, std::string bcate, std::string mbrand, std::string purl, std::string smry, std::string sbrief):
            shop_id(sid),
            vender_id(vid),
            vender_type(vtype),
            shop_type(stype),
            vender_total_score(vtscore),
            vender_ware_score(vwscore),
            vender_service_score(vsscore),
            vender_effective_score(vescore),
            shop_icon(sico),
            shop_name(sname),
            shop_logo(slogo),
            business_category(bcate),
            main_brand(mbrand),
            pic_url(purl),
            summary(smry),
            shop_brief(sbrief)
        {}
    };

    /* all the param data setted in this */
    struct ShopSearchContext
    {
        bool intersection_valid;
        /* 求与店铺汇总交集为空 */
        bool intersection_empty;
        REQUEST_TYPE request_type;
        /* black shop list */
        std::string blacklist;
        /* cid1 used to filt shop */
        std::string filt_cid1;
        /* cid2 in filter */
        std::string cid2_in_filter;
        /* cid3 in filter */
        std::string cid3_in_filter;
        /* final url send to shop search server */
        std::string service_request_url;
        std::string expression_key;
        std::string debug_str;
        int32_t shop_type;
        int32_t vender_type;
        int32_t hit_shop_id;
        int32_t intersect_strategy;
        int32_t intersect_valid_pagesize;
        /* shopid and shopidx pair in result */
        std::map<int32_t, int32_t> shop_list_idx;
        ShopSearchContext():
            intersection_valid(false),
            intersection_empty(true),
            request_type(DO_NOTHING),
            shop_type(-1),
            vender_type(-1),
            hit_shop_id(-1),
            intersect_strategy(-1),
            intersect_valid_pagesize(0)
        {}
    };

    struct ShopSearchRemoteData
    {
        SHOP_ERR result_status;
        std::vector<ShopInfoDetail> shop_list;

        ShopSearchRemoteData():
            result_status(ALL_RIGHT)
        {}
    };

    /* data type in analyse data */
    struct ShopSearchInfo
    {
        ShopSearchInfo()
        {}

        ShopSearchContext context;
        ShopSearchRemoteData result;
    };
}

#endif
