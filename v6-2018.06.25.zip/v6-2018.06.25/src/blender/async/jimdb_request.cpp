#include "jimdb_request.h"

using namespace blender;


int JimDBRequest::asyncSend()
{
	if ( checkParamValid() )
	{
		return AsyncRequestBase::asyncSend();
	}
    return -2;
}


bool JimDBRequest::checkParamValid()
{
	if ( m_keys.empty() || ((JIMDB_SET == reqType()) && (m_keys.size() != m_values.size())) )
	{
		BLD_ERROR(master()->logStream(), master()->getStrSeqno()<<"Jimdb checkParamValid key or value is not valid");
		return false;
	}
	return true;
}


void JimDBRequest::setTimoutMs(unsigned int set_timeout)
{
    m_set_timeout = set_timeout;
}


int JimDBRequest::syncGet(const std::string &key, std::string &value)
{
	m_reqType = JIMDB_GET;
	m_keys.clear();
	m_values.clear();
	m_keys.push_back(key);
	int ret = syncSendRecv();
	if ( (ret == 0) && !m_values.empty() )
	{
		value = m_values[0];
	}
    return ret;
}


int JimDBRequest::asyncGet(const std::string &key)
{
	m_reqType = JIMDB_GET;
	m_keys.clear();
	m_values.clear();
	m_keys.push_back(key);
	return asyncSend();
}


int JimDBRequest::syncGet(const std::vector<std::string> &keys, std::vector<std::string> &values)
{
	m_reqType = JIMDB_GET;
	m_keys = keys;
	m_values.clear();
	int ret = syncSendRecv();
    values = m_values;
	return ret;
}


int JimDBRequest::asyncGet(const std::vector<std::string> &keys)
{
	m_reqType = JIMDB_GET;
	m_keys = keys;
	m_values.clear();
	return asyncSend();
}


int JimDBRequest::syncSet(const std::string &key, const std::string &value, unsigned int expire_time)
{
	m_reqType = JIMDB_SET;
	m_keys.clear();
	m_values.clear();
	m_expire_times.clear();
	m_keys.push_back(key);
	m_values.push_back(value);
    m_expire_times.push_back(expire_time);
	return syncSendRecv();
}


int JimDBRequest::asyncSet(const std::string &key, const std::string &value, unsigned int expire_time)
{
	m_reqType = JIMDB_SET;
	m_keys.clear();
	m_values.clear();
	m_expire_times.clear();
	m_keys.push_back(key);
	m_values.push_back(value);
    m_expire_times.push_back(expire_time);
	return asyncSend();
}


int JimDBRequest::syncSet(const std::vector<std::string> &keys, const std::vector<std::string> &values, const std::vector<unsigned int> &expire_times)
{
	m_reqType = JIMDB_SET;
	m_keys = keys;
	m_values = values;
	m_expire_times = expire_times;
	return syncSendRecv();
}


int JimDBRequest::asyncSet(const std::vector<std::string> &keys, const std::vector<std::string> &values, const std::vector<unsigned int> &expire_times)
{
	m_reqType = JIMDB_SET;
	m_keys = keys;
	m_values = values;
	m_expire_times = expire_times;
	return asyncSend();
}


JimDBClient* JimDBRequest::jimdbClient(BlenderMaster_ptr master, const std::string &type, 
    const std::string &jimdb_configid, const std::string &jimdb_token)
{
    bool has_inited = false;
    JimDBClient *client = (JimDBClient *)SyncServiceMng::instance()->get(type, has_inited);
    if ( NULL == client )
    {
        if( has_inited )
        {
            BLD_ERROR(master->logStream(), master->getStrSeqno()<<"jimdb_client has init failed :"<<type);
            return NULL;
        }

        g_service_lock.lock();
        client = (JimDBClient *)SyncServiceMng::instance()->get(type, has_inited);
        if ( (NULL !=client) || has_inited )
        {
            g_service_lock.unlock();
            return client;
        }
        BLD_INFO(master->logStream(), master->getStrSeqno()<<"init jimdb_client for:"<<type);
        client = new JimDBClient();
        if (client == NULL || (0 != client->Init(jimdb_configid, jimdb_token)))
        {
            BLD_ERROR(master->logStream(), master->getStrSeqno()<<"init jimdb_client failed:"<<type);
            if ( NULL != client ) {
                delete client;
                client = NULL;
            }
        }
        SyncServiceMng::instance()->set(type, client);
        g_service_lock.unlock();
    }
    return client;
}
