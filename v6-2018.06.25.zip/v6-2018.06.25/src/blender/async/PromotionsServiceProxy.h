#ifndef _JD_PROMOTIONS_SERVICE_PROXY_H_
#define _JD_PROMOTIONS_SERVICE_PROXY_H_

#include "SearchService.h"
#include "thrift_proxy.h"

using namespace apache::thrift;
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;
using namespace ThriftZookeeper;
using namespace si_search;

class SearchServiceProxy : public si_search::SearchServiceIf
{
	DECLARE_THRIFT_PROXY(SearchService);

public:
    void activity_search(ActivitySearchResult& _return, const SearchRequest& request)
    {
		INVOKE_AND_RETURN_WITHIN_3_ATTEMPTS_NEW(SearchService, activity_search, _return, request);
    }

    void search(SearchResult& _return, const SearchRequest& request)
    {
    }

    PingResult::type ping()
    {
        return PingResult::PING_OK;
    }
};

#endif
