#include "advert_request.h"
#include "encode_convert.h"
#include "concurrence.h"
#include "def.h"
#include "blender_analysis_data.h"
#include "blender_header.h"
#include "blender_config.h"
#include "PromotionsRank.h"
#include <sstream>
#include <boost/lexical_cast.hpp>
#include "json/json.h"
#include "jdsz_logtrace_manager.h"
#include "category_tree_data.h"

using namespace blender;
const char* AdvertRequest::REQUEST_NAME_Advert = "advert";
const int AD_TYPE_PRODUCT_ADVERT = 7;
const int AD_TYPE_PROMOTION_ADVERT = 4;
const int SPREAD_TYPE_INSTATION = 1;
const int MOBILE_TYPE_PC = 0;
const int AD_ID_MYSELF = 1204;
void AdvertRequest::makeRequestParam(BlenderAnalysisData* analysisDat, const std::string &key_utf8, const std::string &user_pin_utf8, const std::string &ad_jda)
{
    _request.ad_type = AD_TYPE_PROMOTION_ADVERT;
    _request.__isset.ad_type = true; 
    _request.spread_type = SPREAD_TYPE_INSTATION;
    _request.__isset.spread_type = true; 
    _request.mobile_type = MOBILE_TYPE_PC;
    _request.__isset.mobile_type = true; 
    _request.ad_id = AD_ID_MYSELF;
    _request.__isset.ad_id = true; 
    BLD_DEBUG(analysisDat->logStream(), "AdvertServiceClient::SetRequest analysisDat->promotions.type:"<<analysisDat->promotions.type);
    if(analysisDat->promotions.type >=0 && analysisDat->promotions.type <=3)
    {
        _request.ad_num = _blender_conf->m_g_ad_display_page * (PromotionsRank::strategy[analysisDat->promotions.type].size)/2;
    }
    else
    {
        _request.ad_num = _blender_conf->m_g_ad_display_page;
    }
    _request.__isset.ad_num = true; 
    advert::Filter filt;
    if(!analysisDat->advert.addkey.empty())
    {
        filt.ev = "exbrand_" + analysisDat->advert.addkey;
        filt.__isset.ev =true;
    }
    if(!analysisDat->advert.cid1.empty())
    {
        filt.urlcid1 = analysisDat->advert.cid1;
        filt.__isset.urlcid1 = true;
    }
    if(!analysisDat->advert.cid2.empty())
    {
        filt.urlcid2 = analysisDat->advert.cid2;
        filt.__isset.urlcid2 = true;
    }
    if(!analysisDat->advert.cid3.empty())
    {
        filt.urlcid3 = analysisDat->advert.cid3;
        filt.__isset.urlcid3 = true;
    }
    _request.filter = filt;
    _request.__isset.filter = true;
    _request.keyword = key_utf8;
    _request.__isset.keyword = true; 
	_request.pin = user_pin_utf8;
    _request.__isset.pin = true; 
    if(!analysisDat->m_area_ids.empty())
    {
        string areaid = boost::lexical_cast<string>(analysisDat->m_area_ids[0]);
        for(size_t vectorNum=1; vectorNum<analysisDat->m_area_ids.size(); vectorNum++)
        {
            areaid = areaid+"-"+boost::lexical_cast<string>(analysisDat->m_area_ids[vectorNum]);
        }
	    _request.location_info = areaid;
        _request.__isset.location_info = true;
    }
    _request.__isset.pin = true; 
    advert::CookieInfo cookieInfo;
    cookieInfo.__jda = ad_jda;
    cookieInfo.__isset.__jda = true; 
    _request.cookieInfo = cookieInfo;
    _request.__isset.cookieInfo = true;

    BLD_DEBUG(analysisDat->logStream(), "AdvertServiceClient::SetRequest :"
        <<" ad_type:"<< _request.ad_type 
        <<" spread_type:"<< _request.spread_type
		<<" mobile_type:"<< _request.mobile_type
		<<" ad_id:"<<_request.ad_id
		<<" ad_num:"<<_request.ad_num
		<<" keyword:"<<analysisDat->query()->_key()
		<<" pin:"<<_request.pin
		<<" ad_jda:"<<_request.cookieInfo.__jda
        <<" location_info:"<<_request.location_info
        <<" filt.ev:"<<_request.filter.ev
        <<" filt.urlcid1:"<<_request.filter.urlcid1
        <<" filt.urlcid2:"<<_request.filter.urlcid2
        <<" filt.urlcid3:"<<_request.filter.urlcid3);
}


inline bool AdvertValid(BlenderAnalysisData *analysisDat)
{
    analysisDat->advert_online_valid = true /*TODO::(AdvertService::_advert_online_valid == 1)*/;

    if (analysisDat->blenderConf()->m_g_ad_valid == false)
        analysisDat->advert.error.assign("conf");
    else if (analysisDat->advert_url_valid == false)
        analysisDat->advert.error.assign("url");
    else if (analysisDat->advert_online_valid == false)
        analysisDat->advert.error.assign("online");
    else if (analysisDat->advert_qp_valid == false)
        analysisDat->advert.error.assign("qp");

    bool flag = (analysisDat->blenderConf()->m_g_ad_valid  &&
            analysisDat->advert_url_valid        &&
            analysisDat->advert_online_valid     &&
            analysisDat->advert_qp_valid);

    analysisDat->advert_flag = flag;

    return flag;


    return flag;
}


inline bool ShouldGetAdvertData(BlenderAnalysisData* analysisDat, const jd::search::request::JdSearchQuery* pbQuery)
{
    bool flag = true;
    if ((pbQuery->_sort_type().compare(search_frame::DEFAULT_SORTER_VALUE)!=0))
    {
        analysisDat->advert.error.assign("sort");
        flag = false;
    }

    if (flag && (pbQuery->_expression_key().empty() == false))
    {
        vector<string> tmp;
        vector<string> keys = blender::GetStrings(pbQuery->_expression_key(), search_frame::FQUERY_SPLITER);
        size_t key_size = keys.size();
        std::string out;
        for (size_t i = 0; i < key_size; ++i)
        {
            tmp = blender::GetStrings(keys[i], search_frame::FQUERY_PARA_SPLITER);
            if ((tmp.size() == 2) && (tmp[0].compare("brand") == 0))
            {
                Normalize(tmp[1], out);
                string exbrand_utf8 = "";
                utils::gbk_to_utf8(out,exbrand_utf8);
                analysisDat->advert.addkey.append(exbrand_utf8);
            }
            else
            {
                flag = false;
                analysisDat->advert.error.assign("expression_key");
                break;
            }
        }
    }

    if (flag)
    {
        size_t filt_info_size = analysisDat->m_url_filt_info.size();
        for (size_t i = 0; i < filt_info_size; ++i)
        {
            const std::string& filter_name = analysisDat->m_url_filt_info[i].first;
            if (filter_name.compare("cid2") == 0)
            {
                analysisDat->advert.cid2 = analysisDat->m_url_filt_info[i].second;
            }
            else if (filter_name.compare("catid") == 0)
            {
                analysisDat->advert.cid3 = analysisDat->m_url_filt_info[i].second;
            }
            else
            {
                flag = false;
                analysisDat->advert.error.assign("filt_type");
                break;
            }
        }
    }

    analysisDat->advert_flag = flag;
    return flag;
}


void ProcessAdvertRequest(BlenderAnalysisData* analysisDat)
{
    jd_search_merger::CategoryTree &cate_tree = *(CategoryTreeData::getInstance()->_cat_tree);
    bool cate_flag = false;

    if (analysisDat->advert.cid2.empty() == false)
    {
        std::string cid2_str_param = analysisDat->advert.cid2;
        boost::to_lower(cid2_str_param);

        const char* p = cid2_str_param.c_str();
        const char* pl = strchr(p, 'l');
        const char* pm = strchr(p, 'm');

        if (pl && pm)
        {
            std::string& cid2_str = analysisDat->advert.cid2;
            cid2_str = cid2_str_param.substr(pl-p+1, pm-pl-1);

            try
            {
                int cid2 = boost::lexical_cast<int>(cid2_str);
                int cid1 = cate_tree.ParentCatID(cid2);
                analysisDat->advert.cid1 = boost::lexical_cast<std::string>(cid1);
                analysisDat->advert.cid2 = cid2_str;
                cate_flag = true;
            }
            catch (...)
            {
            }
        }
    }
    else if (analysisDat->advert.cid3.empty() == false)
    {
        std::string cid3_str_param = analysisDat->advert.cid3;
        boost::to_lower(cid3_str_param);

        const char* p = cid3_str_param.c_str();
        const char* pl = strchr(p, 'l');
        const char* pm = strchr(p, 'm');

        if (pl && pm)
        {
            std::string cid3_str = cid3_str_param.substr(pl-p+1, pm-pl-1);

            try
            {
                int cid3 = boost::lexical_cast<int>(cid3_str);
                int cid2 = cate_tree.ParentCatID(cid3);
                int cid1 = cate_tree.ParentCatID(cid2);
                analysisDat->advert.cid2 = boost::lexical_cast<std::string>(cid2);
                analysisDat->advert.cid1 = boost::lexical_cast<std::string>(cid1);
                analysisDat->advert.cid3 = cid3_str;
                cate_flag = true;
            }
            catch (...)
            {
            }
        }
    }
}


int AdvertRequest::reqAdvert()
{
    BlenderAnalysisData *_analysisData = master()->analysisData();
    
    //判断是否需要发送:
    if ( AdvertValid(_analysisData) && ShouldGetAdvertData(_analysisData, _analysisData->query()) )
    {
        string key_utf8 = "";
        if ( !utils::gbk_to_utf8(_analysisData->query()->_key(), key_utf8) )
        {
            Trace_cnt(BLD_STAT_AD_ERROR, 1, _analysisData->m_ump2_tag);
            BLD_ERROR(master()->logStream(), master()->getStrSeqno() <<  "sendReqAdvert query_key fail to utils::gbk_to_utf8:" << _analysisData->query()->_key()); 
            return -1;
        }

        string user_pin_utf8 = "";
        if ( !utils::gbk_to_utf8(_analysisData->query()->_user_pin(), user_pin_utf8) )
        {
            Trace_cnt(BLD_STAT_AD_ERROR, 1, _analysisData->m_ump2_tag);
            BLD_ERROR(master()->logStream(), master()->getStrSeqno() <<  "sendReqAdvert _user_pin fail to utils::gbk_to_utf8:" << _analysisData->query()->_user_pin()); 
        }
        
        ProcessAdvertRequest(_analysisData);

        makeRequestParam(_analysisData, key_utf8, user_pin_utf8, _analysisData->ad_jda);
        if ( 0 != asyncSend() )
        {
            Trace_cnt(BLD_STAT_AD_ERROR, 1, _analysisData->m_ump2_tag);
            BLD_ERROR(master()->logStream(), master()->getStrSeqno() <<  "sendRequestAsync(advert) faild"); 
            return -2;
        }

        _analysisData->advert_getting = true;
        return 0;
    }
    return -3;
}


int AdvertRequest::handelResponse(int err_no)
{
    BlenderAnalysisData* _analysisData = master()->analysisData();
    if ( 0 == err_no )
    {
        std::vector< ::advert::AdSearchResult>& ret_vec = _response;
        
        size_t sz = ret_vec.size();
        if (sz == 0)
        {
            _analysisData->advert.error.assign("empty");
            return 0;
        }
        //analysisDat->promotions.type = 0;
        std::vector<AdvertDetail>& info = _analysisData->advert.info;
        info.resize(sz);

        for (size_t i = 0; i < sz; ++i)
        {
            AdvertDetail& info_item = info[i];
            ::advert::AdSearchResult& ret_vec_item = ret_vec[i];
            info_item.from.assign("advert");
            if(ret_vec_item.__isset.material_id)
            {
                info_item.id = ret_vec_item.material_id;
            }
            if(ret_vec_item.__isset.promo_title)
            {
                utils::utf8_to_gbk(ret_vec_item.promo_title,info_item.show_name);
                //info_item.show_name = ret_vec_item.promo_title;
            }
            if(ret_vec_item.__isset.click_url)
            {
                info_item.url = ret_vec_item.click_url;
            }
            if(ret_vec_item.__isset.image_url)
            {
                info_item.banner_url = ret_vec_item.image_url;
            }
            if(ret_vec_item.__isset.exposal_url)
            {
                info_item.exposal_url = ret_vec_item.exposal_url;
            }
            if(ret_vec_item.__isset.promo_desc)
            {
                utils::utf8_to_gbk(ret_vec_item.promo_desc,info_item.desc);
            }
        }
    }

    _analysisData->advert_req_err_no = err_no;
    _analysisData->advert_flag = !(_analysisData->advert.info.empty());
    if ( 0 != err_no )
    {
        Trace_cnt(BLD_STAT_AD_ERROR, 1, _analysisData->m_ump2_tag); 
    }
    return 0;
}
