#ifndef __THRIFT_REQUEST_BASE_H__
#define __THRIFT_REQUEST_BASE_H__
#include <thrift/transport/TBufferTransports.h>
#include <thrift/protocol/TBinaryProtocol.h>
#include "async_requestbase.h"
#include "pooled_client.h"
#include "watcher_action.h"
#include "conn_pool_factory.h"
#include "thread_lock.h"
#include "cache_request.h"

using namespace time_util;
using namespace ThriftZookeeper;
namespace blender{

class ThriftRequestBase : public AsyncRequestBase
{
public:
    ThriftRequestBase(const std::string &name, BlenderMaster_ptr master, int blender_msg_type)
        : AsyncRequestBase(name, master, blender_msg_type)
    {
    }

    virtual ~ThriftRequestBase() {}

    virtual bool cacheValid() { return false; }

    std::string cacheKey() { return m_cacheKey; }

protected:
    virtual int tryGetCache() { return -1; }
    virtual int trySetCache() { return -1; }

    virtual void setCacheUrl(const std::string &url);

private:
    std::string m_cacheUrl;
    std::string m_cacheKey;
};

}//end namesapce


#define DEF_THRIFT_REQ_BASE(Service, type, func) \
protected:\
std::string serviceName() { return #type; }\
PooledClient(Service)* getPooledClient() \
{\
    bool has_inited = false;\
    PooledClient(Service) *client = (PooledClient(Service) *)SyncServiceMng::instance()->get(#Service, has_inited);\
    if ( NULL == client )\
    {\
        if ( has_inited )\
        {\
            BLD_ERROR(master()->logStream(), master()->getStrSeqno()<<"thriftservice has init failed :"<<#type);\
            return NULL;\
        }\
        g_service_lock.lock();\
        client = (PooledClient(Service) *)SyncServiceMng::instance()->get(#Service, has_inited);\
        if ( (NULL != client) || has_inited )\
        {\
            g_service_lock.unlock();\
            return client;\
        }\
        ZookeeperClient *zk_client = new ZookeeperClient();\
        zk_client->set_host(_blender_conf->m_g_##type##_zk_cluster);\
        zk_client->set_recv_timeout(ZK_RECV_TIMEOUT);\
        ServiceWatcherAction* _watcher = new ServiceWatcherAction();\
        _watcher->set_owner(zk_client);\
        zk_client->set_watcher(_watcher);\
        client = PooledClient(Service)::instance(zk_client,\
                _blender_conf->m_g_##type##_zk_path,\
                _blender_conf->m_g_##type##_replica_count,\
                _blender_conf->m_g_##type##_conn_timeout,\
                _blender_conf->m_g_##type##_send_timeout,\
                _blender_conf->m_g_##type##_recv_timeout);\
        SyncServiceMng::instance()->set(#Service, client);\
        if ( NULL == client ) {\
    		printf("PooledClient(%s) error:%s\n", #Service, #type);\
    		delete zk_client;\
        }\
        else {\
            int ret = zk_client->open(); \
            if ( 0 != ret )\
            {\
                printf("_##type##_zk_client->open() failed:%d!!!!!!!!!!!!!!!!!!!!!\n", ret);\
            }\
        }\
        g_service_lock.unlock();\
    }\
    return client;\
}\
int syncSendRecv()\
{\
    int err_no = 0;\
    BLD_DEBUG(master()->logStream(), "syncSendRecv BEGIN ");\
    Trace_qps(BLD_STAT_THRIFT_REQ, 1, "serv_name="#type",req_name=" + name());\
    if ( 0 == tryGetCache() )\
    {\
        BLD_DEBUG(master()->logStream(), master()->getStrSeqno()<<" syncSendRecv hit cache :"<<name());\
        err_no = 0;\
        err_no = handelResponse(err_no);\
        setErrNo(err_no);\
        report_bussiness(name(), 0 == err_no, master()->analysisData()->m_ump2_tag);\
        return 0;\
    }\
    int clockms = m_timer.ClockMs();\
    PooledClient(Service) *client = getPooledClient();\
    if ( NULL == client ) {\
        BLD_DEBUG(master()->logStream(), "syncSendRecv client is NULL");\
        err_no = 11;\
        m_timer.End();\
        handelResponse(err_no);\
        setErrNo(err_no);\
        return err_no;\
    }\
    try {\
        client->acquire()->func(_response, _request);\
    } \
    catch (TZException & tx) {\
        err_no = 100 + tx.tze_insight_no(); \
        BLD_ERROR(master()->logStream(), master()->getStrSeqno()<<"syncSendRecv catch exception 1 key:"<<master()->analysisData()->query()->_key()<<tx.tze_what());\
    } \
    catch (...) {\
        err_no = 1;\
        BLD_ERROR(master()->logStream(), master()->getStrSeqno()<<"syncSendRecv catch exception 2 key:"<<master()->analysisData()->query()->_key());\
    }\
    m_timer.End();\
    uint64_t _cost_ms = m_timer.CostMs() - clockms;\
    Trace_ratio(BLD_STAT_THRIFT_REQ, err_no == 0, "serv_name="#type",req_name=" + name(), true);\
    Trace_latency(BLD_STAT_THRIFT_REQ, _cost_ms,  "serv_name="#type",req_name=" + name(), true);\
    report_bussiness(name(), 0 == err_no, master()->analysisData()->m_ump2_tag);\
    ump_report::report_tp(BLD_STAT_THRIFT_CALL +"_"#type, _cost_ms, err_no == 0 );\
    master()->logData()->ext_add(name() + "_status", cast2string(err_no));\
    BLD_DEBUG(master()->logStream(), master()->getStrSeqno()<<" thrift syncSendRecv END err_no:" << err_no << " cost_ms:" << _cost_ms << " name:"<<name());\
    err_no = handelResponse(err_no);\
    setErrNo(err_no);\
    if ( 0 == err_no )\
    {\
        trySetCache();\
    }\
    return err_no;\
}

#define DEF_THRIFT_REQ_CACHE(type) \
bool cacheValid()\
{\
    return _blender_conf->m_g_##type##_cache_valid;\
}\
int tryGetCache()\
{\
    if ( !cacheValid() || !master()->analysisData()->query()->_use_cache() )\
    {\
        return -1;\
    }\
    std::string _cache_data;\
    CacheRequest cacheReq("get_" + name(), master(), msgType());\
    int ret = cacheReq.syncGet(cacheKey(), _cache_data);\
    if ( (0 == ret) && !_cache_data.empty() )\
    {\
        boost::shared_ptr<apache::thrift::transport::TMemoryBuffer> _trasport(new apache::thrift::transport::TMemoryBuffer((uint8_t*)_cache_data.c_str(), _cache_data.length()));\
        apache::thrift::protocol::TBinaryProtocol _prot(_trasport);\
        _response.read(&_prot);\
        ret = 0;\
    }\
    else\
    {\
        ret = -2;\
    }\
    return ret;\
}\
int trySetCache()\
{\
    if ( !cacheValid() )\
    {\
        return -1;\
    }\
    boost::shared_ptr<apache::thrift::transport::TMemoryBuffer> _trasport(new apache::thrift::transport::TMemoryBuffer());\
    apache::thrift::protocol::TBinaryProtocol _prot(_trasport);\
    _response.write(&_prot);\
    CacheRequest *cacheReq = new CacheRequest("set_" + name(), master(), msgType(), BlenderRequest::REQUEST_SYNC_SERVICE_NO_RESP);\
    int ret = cacheReq->asyncSet(cacheKey(), _trasport->getBufferAsString(), _blender_conf->m_g_##type##_cache_expire_time);\
    if ( 0 == ret )\
    {\
        BLD_DEBUG(master()->logStream(), master()->getStrSeqno()<<" trySetCache "<<name() <<" set cache ...");\
    }\
    else\
    {\
        delete cacheReq;\
        BLD_ERROR(master()->logStream(), master()->getStrSeqno()<<" trySetCache "<<name() <<" set cache failed:" << ret);\
    }\
    return ret;\
}

#endif
