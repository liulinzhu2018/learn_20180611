#ifndef __BLEDNER_REDPACKETS_STATE_H__
#define __BLEDNER_REDPACKETS_STATE_H__

#include <string>
#include "jimdb_request.h"

namespace blender{
class RedPacketsRequest : public JimDBRequest
{
	DEF_JIMDB_REQ_BASE(redpackets)
public:
    RedPacketsRequest(const std::string &name, BlenderMaster_ptr master, int msg_type)
      : JimDBRequest(name, master, msg_type, BlenderRequest::REQUEST_SYNC_SERVICE) 
     {}

    int asyncReqRedPackets();

protected:
    virtual int handelResponse(int err_no);

private:
    std::string m_normal_key;
};

}
#endif
