#ifndef __BLEDNER_SCENE_REQUEST_H__
#define __BLEDNER_SCENE_REQUEST_H__

#include <string>
#include "jimdb_request.h"

namespace blender{

class SceneRequest : public JimDBRequest
{
	DEF_JIMDB_REQ_BASE(scene)
public:
    SceneRequest(const std::string &name, BlenderMaster_ptr master, int msg_type)
      : JimDBRequest(name, master, msg_type, BlenderRequest::REQUEST_SYNC_SERVICE) 
     {}

    int asyncReqScene();

protected:
    virtual int handelResponse(int err_no);
    inline bool sceneInsertValid(BlenderAnalysisData* _analysisData);

private:
    std::vector<std::string> m_scene_keys;
};

}
#endif
