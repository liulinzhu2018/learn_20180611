#ifndef __JDS_PROMOTIONS_SERVICE_CLIENT_H__
#define __JDS_PROMOTIONS_SERVICE_CLIENT_H__

#include "PromotionsServiceProxy.h"
#include "pooled_client.h"
#include "thrift_requestbase.h"
#include <signal.h>
#include <pthread.h>

namespace blender
{

class BlenderAnalysisData;
class PromotionRequest : public blender::ThriftRequestBase
{
    DEF_THRIFT_REQ_BASE(SearchService, pm, activity_search);
    DEF_THRIFT_REQ_CACHE(pm)
public:
	static const char* REQUEST_NAME_Promotion; 
    PromotionRequest(const std::string &name, BlenderMaster_ptr master, int blender_msg_type) 
    	: ThriftRequestBase(name, master, blender_msg_type)
    {}
    ~PromotionRequest(){}

    virtual int handelResponse(int err_no);

    int reqPromotion();
private:
	void makeParam(BlenderAnalysisData* analysisDat, bool has_promotion_id);
private:
    si_search::SearchRequest         _request;
    si_search::ActivitySearchResult  _response;
};
}

#endif
