#include "async_requestbase.h"
#include "async_service.h"

using namespace blender;

util::Mutex AsyncRequestBase::g_service_lock;

int AsyncRequestBase::asyncSend()
{
    if ( !AsyncService::instance()->sendRequestAsync(this) )
    {
        //Trace_cnt(BLD_STAT_AD_ERROR_COUNT, 1, _analysisData->m_ump2_tag);
        BLD_ERROR(master()->logStream(), master()->getStrSeqno() <<  "asyncSend() faild:"<<name()); 
        return -1;
    }
    return 0;
}


SyncServiceMng* SyncServiceMng::instance()
{
    static SyncServiceMng* mng = NULL;
    if ( NULL == mng )
    {
        mng = new SyncServiceMng();
    }
    return mng;
}


void* SyncServiceMng::get(const std::string& name, bool &exist) const
{
	exist = true;
    if ( name.empty() )
    {
        return NULL;
    }
    std::map<std::string, void*>::const_iterator it = m_clientMap.find(name);
    if ( it != m_clientMap.end() )
    {
        return it->second;
    }
    exist = false;
    return NULL;
}

void SyncServiceMng::set(const std::string& name, void *client)
{
    m_clientMap.insert(std::make_pair<std::string, void*>(std::string(name), client));
}
