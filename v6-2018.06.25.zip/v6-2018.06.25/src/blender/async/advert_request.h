#ifndef __JDS_ADVERT_SERVICE_CLIENT_H__
#define __JDS_ADVERT_SERVICE_CLIENT_H__
#include "thrift_requestbase.h"
#include "AdvertServiceProxy.h"
#include <signal.h>
#include <string>
#include <pthread.h>

namespace blender
{

class AdvertRequest : public ThriftRequestBase
{
    DEF_THRIFT_REQ_BASE(advert::AdSearchService, ad, search);
public:
	static const char* REQUEST_NAME_Advert;
    AdvertRequest(const std::string &name, BlenderMaster_ptr master, int blender_msg_type) 
    	: ThriftRequestBase(name, master, blender_msg_type)
    {}
 
    virtual int handelResponse(int err_no);

    int reqAdvert();

private:
    void makeRequestParam(BlenderAnalysisData* analysisDat, const std::string &key_utf8, const std::string &user_pin_utf8, const std::string &ad_jda);

private:
    ::advert::AdSearchParam                _request;
    std::vector< ::advert::AdSearchResult> _response;
};

}
#endif

