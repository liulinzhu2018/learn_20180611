#ifndef _JD_ADVERT_SERVICE_PROXY_H_
#define _JD_ADVERT_SERVICE_PROXY_H_
#include "AdSearchService.h"
#include "thrift_proxy.h"
using namespace apache::thrift;
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;
using namespace ThriftZookeeper;
namespace advert {
class AdSearchServiceProxy : public AdSearchServiceIf
{
	DECLARE_THRIFT_PROXY(AdSearchService);
public:
    void search(std::vector<AdSearchResult>& _return, const AdSearchParam& _param)
    {
		INVOKE_AND_RETURN_WITHIN_3_ATTEMPTS_NEW(AdSearchService, search, _return, _param);
    }
};
}
#endif

