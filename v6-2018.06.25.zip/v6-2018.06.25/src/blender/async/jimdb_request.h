#ifndef __BLD_JIMDB_REQUEST_BASE_H__
#define __BLD_JIMDB_REQUEST_BASE_H__

#include "async_requestbase.h"
#include "jimdb_client.h"
#include <vector>

using namespace time_util;
namespace blender{

class JimDBRequest : public AsyncRequestBase
{
public:
	enum ReqJimdbType{
		JIMDB_UNKOWN = 0,
		JIMDB_GET = 1,
		JIMDB_SET,
	};
    JimDBRequest(const std::string &name, BlenderMaster_ptr master, int msg_type, BlenderRequest::ASYNCType rt = BlenderRequest::REQUEST_SYNC_SERVICE)
        : AsyncRequestBase(name, master, msg_type, rt)
        , m_set_timeout(20)
        , m_reqType(JIMDB_UNKOWN)
    {
    }

    void setTimoutMs(unsigned int set_timeout);

    int syncGet(const std::string &key, std::string &value);
    int syncGet(const std::vector<std::string> &keys, std::vector<std::string> &values);

    int asyncGet(const std::string &key);
    int asyncGet(const std::vector<std::string> &keys);
    const std::vector<std::string> values() const { return m_values; }

    int syncSet(const std::string &key, const std::string &value, unsigned int expire_time);
    int asyncSet(const std::string &key, const std::string &value, unsigned int expire_time);

    int syncSet(const std::vector<std::string> &keys, const std::vector<std::string> &values, const std::vector<unsigned int> &expire_time);
    int asyncSet(const std::vector<std::string> &keys, const std::vector<std::string> &values, const std::vector<unsigned int> &expire_time);

    ReqJimdbType reqType() const { return m_reqType; }

    static JimDBClient* jimdbClient(BlenderMaster_ptr master, const std::string &type, 
        const std::string &jimdb_configid, const std::string &jimdb_token);

    const std::vector<std::string> keys() const { return m_keys; }
protected:
	virtual int asyncSend();
	virtual int handelResponse(int err_no) { return err_no; }
	bool checkParamValid();

protected:
    std::vector<std::string> m_keys;
    std::vector<std::string> m_values;
    unsigned int             m_set_timeout;
    std::vector<unsigned int> m_expire_times;

private:
	ReqJimdbType             m_reqType;
};

}//end namespace


//static sync func
#define GLB_JimDB_GetJimDBClient(master,type) JimDBRequest::jimdbClient(master,#type,_blender_conf->m_g_##type##_jimdb_configid,_blender_conf->m_g_##type##_jimdb_token)


#define DEF_JIMDB_REQ_BASE(type) \
protected:\
std::string serviceName() { return #type; }\
JimDBClient* getJimdbClient() \
{\
    return GLB_JimDB_GetJimDBClient(master(), type);\
}\
int syncSendRecv()\
{\
	BLD_DEBUG(master()->logStream(), master()->getStrSeqno()<<"Jimdb syncSendRecv BEGIN :"<<name()<<" type(1-get,2-set):"<<reqType());\
    int err_no = 0;\
    if ( !checkParamValid() )\
    {\
    	BLD_ERROR(master()->logStream(), master()->getStrSeqno()<<"Jimdb syncSendRecv key is empty()");\
    	err_no = 11;\
    	err_no = handelResponse(err_no);\
    	setErrNo(err_no);\
    	return err_no;\
    }\
    JimDBClient *client = getJimdbClient();\
    if ( NULL == client ) {\
        BLD_ERROR(master()->logStream(), master()->getStrSeqno()<<"Jimdb client is NULL:"<<name()<<" jimdb:"<<#type);\
        err_no = 11;\
        m_timer.End();\
        handelResponse(err_no);\
        setErrNo(err_no);\
        return err_no;\
    }\
    int clockus = m_timer.ClockUs();\
    if ( reqType() == JimDBRequest::JIMDB_GET )\
    {\
        if ( 1 == m_keys.size() )\
        {\
            std::string _tvalue;\
            err_no = client->get(m_keys[0], _tvalue, _blender_conf->m_g_##type##_get_timeout);\
            if ( (0 == err_no) && !_tvalue.empty() )\
            {\
                m_values.push_back(_tvalue);\
            }\
        }\
        else\
        {\
            err_no = client->mget(m_keys, m_values, _blender_conf->m_g_##type##_get_timeout);\
        }\
        Trace_ratio(BLD_STAT_JIMDB_REQ_HIT, (0 == err_no) && !m_values.empty(), "serv_name="#type",req_name=" + name(), true);\
        BLD_DEBUG(master()->logStream(), master()->getStrSeqno()<< "Jimdb syncSendRecv :"<<name() << " mget keys:"<<m_keys[0] << "..."<<m_keys.size()<<" hit:"<<!m_values.empty());\
    }\
    else if ( reqType() == JimDBRequest::JIMDB_SET)\
    {\
        int _err = 0;\
        if ( 1 == m_keys.size() )\
        {\
            BLD_DEBUG(master()->logStream(), master()->getStrSeqno()<< "Jimdb syncSendRecv :"<<name() << " set key:"<<m_keys[0]<<" exp_t:"<<m_expire_times[0]);\
            _err += client->setex(m_keys[0], m_values[0], m_expire_times[0], m_set_timeout);\
        }\
        else\
        {\
            _err += client->msetex(m_keys, m_values, m_expire_times, m_set_timeout);\
            for ( size_t i = 0; false && (i < m_keys.size()); i++ )\
            {\
                BLD_DEBUG(master()->logStream(), master()->getStrSeqno()<< "Jimdb syncSendRecv :"<<name() << " mset key:"<<m_keys[i]<<" exp_t:"<<m_expire_times[i]);\
            }\
        }\
        err_no = _err;\
    }\
    m_timer.End();\
    uint64_t _cost_us = m_timer.CostUs() - clockus;\
    Trace_ratio(BLD_STAT_JIMDB_REQ, err_no == 0, "serv_name="#type",req_name=" + name(), true);\
    Trace_qps(BLD_STAT_JIMDB_REQ, 1, "serv_name="#type",req_name=" + name());\
    Trace_latency(BLD_STAT_JIMDB_REQ, _cost_us, "serv_name="#type",req_name=" + name(), true);\
    ump_report::report_tp(BLD_STAT_JIMDB_CALL +"_"#type, _cost_us, err_no == 0 );\
    BLD_DEBUG(master()->logStream(), master()->getStrSeqno()<<" Jimdb syncSendRecv END err_no:" << err_no << " cost_us:" << _cost_us << " name:"<<name());\
    err_no = handelResponse(err_no);\
    setErrNo(err_no);\
    return err_no;\
}

#endif
