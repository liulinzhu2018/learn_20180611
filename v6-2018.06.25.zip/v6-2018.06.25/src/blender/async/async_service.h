#ifndef __BLD_SYNC_SERVICE_H__
#define __BLD_SYNC_SERVICE_H__
#include "blender_header.h"
#include "framework/server.h"
#include <vector>

namespace blender
{
class AsyncRequestBase;
class AsyncService
{
public: 
    static AsyncService* instance() 
    {
        static AsyncService *s_instance = NULL;
        if ( NULL == s_instance )
        {
            s_instance = new AsyncService();
        }
        return s_instance;
    }
    AsyncService();
    ~AsyncService();

    bool sendRequestAsync(AsyncRequestBase* request);

    int queue_size() const { return _task_queue->size(); }

public:
    //����ʹ��blender_confȫ�ֱ��������ڻ�ȡ�����ļ�֮������������
    virtual int init(int thread_num);
    virtual int32_t start();
    virtual void stop();
    virtual void wait();
    
protected:
    static void* thread_worker(void* para);

    bool handleGetRemoteData(AsyncRequestBase* request);
    
private:
    int                             _thread_num;
    bool _exit;
    framework::server_status_t _status;
    BlenderTaskQueue *_task_queue;

    std::vector<pthread_t> _work_threads;
};
}
#endif
