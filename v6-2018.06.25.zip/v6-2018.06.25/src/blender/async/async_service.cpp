#include "async_service.h"
#include "blender_config.h"
#include "async_requestbase.h"
#include "concurrence.h"
#include "blender_header.h"
#include "blender_request.h"
#include "framework/request.h"

using namespace blender;

AsyncService::AsyncService():_exit(false),_status(framework::srv_unknown),_task_queue(NULL)
{
}

AsyncService::~AsyncService()
{
}


//����ʹ��blender_confȫ�ֱ��������ڻ�ȡ�����ļ�֮������������
int AsyncService::init(int thread_num)
{
    _thread_num = (int)thread_num * _blender_conf->m_g_syncservice_thread_times;
    printf("AsyncService(%d)  _thread_num=%d\n", thread_num, _thread_num);

    _task_queue = new (std::nothrow) BlenderTaskQueue(_blender_conf->m_g_syncservice_max_task_size);
	if (unlikely(_task_queue == NULL)) {
		fprintf(stderr, "out of memory at %s:%d.", __FILE__, __LINE__);
		return -2;
	}

    _status = framework::srv_inited;
    return 0;
}


struct SyncWorkerContext
{
	SyncWorkerContext(AsyncService *s, int i) : server(s), id(i) {}
	AsyncService *server;
	int id;
};

void* AsyncService::thread_worker(void* para)
{
    SyncWorkerContext *ctx = (SyncWorkerContext *) para;
	AsyncService *server= (AsyncService *) ctx->server;
	BlenderTaskQueue *queue = server->_task_queue;
    int id = ctx->id;
    delete ctx;

    printf("AsyncService thread_worker(%d) has been startted!\n", id);

    int queue_wait_us = 0;
    
	char *package = NULL;
	while (!server->_exit) {
		if (unlikely(queue->dequeue(package) != 0 || package == NULL)) {
			continue;
		}

        blender::AsyncRequestBase* request = (blender::AsyncRequestBase*)package;
		if (server->_exit) {
			delete request;
			break;
		}

        queue_wait_us = request->clockUs();
        Trace_latency(BLD_STAT_SYNC_QUEUE_WAIT_LATENCY, queue_wait_us);

        //BLD_DEBUG("AsyncService:"<< id << " handle request:" << request->type());
        server->handleGetRemoteData(request);
	}
    printf("AsyncService(%d) finished\n", id);

	return NULL;
}


bool AsyncService::sendRequestAsync(AsyncRequestBase* request)
{
    if (_status != framework::srv_startted) { return false; }

    if (unlikely(_task_queue->enqueue((char *)request) == 0)) 
    {
        Trace_value(BLD_STAT_SYNC_QUEUE_SIZE, _task_queue->size());
        return true;
    }
    Trace_value(BLD_STAT_SYNC_QUEUE_SIZE, _task_queue->size());
    BLD_ERROR(NULL, "_task_queue->enqueue failed type:"<<request->name());
    return false;
}


bool AsyncService::handleGetRemoteData(AsyncRequestBase* request)
{
    MsTimer timer;
    timer.Start();
    int ret = request->syncSendRecv();
    if ( request->asyncType() == BlenderRequest::REQUEST_SYNC_SERVICE_NO_RESP )
    {
        delete request;
    }
    else
    {
        request->receive();
    }
    return true;
}


int32_t AsyncService::start()
{
	if (_status != framework::srv_inited) return -1;

    printf("SyncServicestart _thread_num=%d\n", _thread_num);
	for (int i = 0; i < _thread_num; i++) {
        SyncWorkerContext *ctx = new SyncWorkerContext(this, i);
		pthread_t id;
		if (pthread_create(&id, NULL, thread_worker, ctx)) {
			return -2;
		}
        printf("start AsyncService [%d] [%lu]\n", i, id);

        _work_threads.push_back(id);
	}

    printf("AsyncService(%p) has been startted!\n", this);
	fflush(stdout);
	_status = framework::srv_startted;
    return 0;

}


void AsyncService::stop()
{
	if (_status != framework::srv_startted) return;
	_status = framework::srv_stopping;
    printf("AsyncService(%p) is stopping.\n", this);
    _exit = true;
	_task_queue->stop();
}


void AsyncService::wait()
{
    void* retval = NULL;
    for (size_t i = 0; i < _work_threads.size(); i++)
    {
        pthread_join(_work_threads[i], &retval);
    }

    printf("AsyncService(%p) is stopped.\n", this);
	_status = framework::srv_stopped;

}

