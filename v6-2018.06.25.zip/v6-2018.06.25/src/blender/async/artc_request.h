#ifndef __JDS_ARTICLE_REQUEST_H__
#define __JDS_ARTICLE_REQUEST_H__
#include "SearchServiceProxy.h"
#include "pooled_client.h"
#include "thrift_requestbase.h"
#include "blender_logger.h"
#include <signal.h>
#include <pthread.h>
#include <list>
#include <string>
namespace blender 
{
class BlenderAnalysisData;
class ArticleRequest : public blender::ThriftRequestBase
{
    DEF_THRIFT_REQ_BASE(vertical_search::VerticalSearchService, artc, search)
    DEF_THRIFT_REQ_CACHE(artc)
public:
	static const char* REQUEST_NAME_ArtcInsertTop;
	static const char* REQUEST_NAME_ArtcTab;
	static const char* REQUEST_NAME_ArtcInsertDaren;
    ArticleRequest(const std::string &name, BlenderMaster_ptr master, int blender_msg_type) 
        : ThriftRequestBase(name, master, blender_msg_type)
    {}
    ~ArticleRequest(){}

    
    int handelResponse(int err_no);

    int reqArtcInsertTop();
    int reqArtcTab();
    int reqArtcInsertDaren();
private:
	int request(const std::string &req_url, std::string &req_info);

private:
    vertical_search::VerticalSearchResult  _response;
    vertical_search::VerticalSearchRequest _request;
};
}

#endif

