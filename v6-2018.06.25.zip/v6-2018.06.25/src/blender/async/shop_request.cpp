#include "shop_request.h"
#include "concurrence.h"
#include "encode_convert.h"
#include "url_code.h"
#include "def.h"
#include "blender_analysis_data.h"
#include "blender_master.h"
#include "blender_header.h"
#include "blender_config.h"
#include "blender_logdata.h"
#include "category_tree_data.h"

#include <sstream>
#include <boost/lexical_cast.hpp>
using namespace blender;
const char* ShopRequest::REQUEST_NAME_ShopInsert = "shopinsert";
const char* ShopRequest::REQUEST_NAME_ShopEntry  = "shopentry";
const char* ShopRequest::REQUEST_NAME_ShopTab    =  "shoptab";
void ShopRequest::makeParam(BlenderAnalysisData*_analysisData, unsigned int shop_id)
{
    std::string& request_url = _request.request_url;
    request_url.clear();
    if (shop_id > 0)
    {
        request_url = "product_list=" + boost::lexical_cast<string>(shop_id);
    }
    else 
    {
        std::string search_key_encode = util::urlEncodeGBK(_analysisData->query()->_key());

        request_url.append(search_frame::KEY_PARA).append("=").append(search_key_encode);
        request_url.append("&").append(search_frame::PAGE_SIZE_PARA).append("=").append(boost::lexical_cast<string>(_blender_conf->m_g_sp_limit));
        const ShopSearchInfo& shop_search_info = _analysisData->m_shop_search_result;

        /* all kind of filter, pic_url not empty is basic need */
        std::string filt_condition;
        if (shop_search_info.context.request_type == blender::REQUEST_SHOP_INTERSECTION)
        {
            filt_condition.append(";has_pic,1");
        }
        
        if (shop_search_info.context.shop_type > 0)
        {
            filt_condition.append(";shop_type,").append(boost::lexical_cast<string>(shop_search_info.context.shop_type));
        }
        
        if (shop_search_info.context.hit_shop_id > 0)
        {
            filt_condition.append(";shop_id,").append(boost::lexical_cast<string>(shop_search_info.context.hit_shop_id));
        }
        
        if (shop_search_info.context.vender_type > 0)
        {
            filt_condition.append(";vender_type,").append(boost::lexical_cast<string>(shop_search_info.context.vender_type));
        }

        if (!filt_condition.empty())
        {
            request_url.append("&filt_type=").append(filt_condition);
        }
        
        if (!shop_search_info.context.filt_cid1.empty())
        {
            request_url.append("&cid1=").append(shop_search_info.context.filt_cid1);
        }
        
        if (!shop_search_info.context.blacklist.empty())
        {
            request_url.append("&pm_blist=").append(shop_search_info.context.blacklist);
        }
        request_url.append("&sort_type=sort_pc_shop_desc&enc_url_gbk=yes");

        _analysisData->m_shop_search_result.context.debug_str.append("shop url: " + request_url +", ");
    } 
    setCacheUrl(request_url);
    BLD_DEBUG(_analysisData->logStream(), "SetRequest: ShopSearchRequest.request_url:" << request_url);
}


void ShopRequest::makeParam(BlenderAnalysisData*_analysisData, std::list<int> cids)
{
    std::string& request_url = _request.request_url;
    request_url.clear();
    if ( cids.size() > 0 )
    {
        std::string search_key_encode = util::urlEncodeGBK(_analysisData->query()->_original_key());

        request_url.append(search_frame::KEY_PARA).append("=").append(search_key_encode);
        request_url.append("&filt_type=;has_pic,1");
        request_url.append("&cid1=");
        for ( std::list<int>::const_iterator cit = cids.begin(); cit !=cids.end(); cit++ )
        {
            request_url.append(boost::lexical_cast<string>(*cit)).append(",");
        }
        request_url.append("&enc_url_gbk=yes");
        setCacheUrl(request_url);
    }
    BLD_DEBUG(_analysisData->logStream(), "SetRequest(shoptab):ShopSearchRequest.request_url:" << request_url);
}


inline bool ShopSearchValid(BlenderAnalysisData*_analysisData)
{
    _analysisData->m_shop_search_online_valid = true; //TODO::(ShopSearch::_shop_search_online_valid == 1);

    if (_analysisData->blenderConf()->m_g_sp_valid == false)
    {
        _analysisData->m_shop_search_result.context.debug_str.append("invalid by config, ");
    }
    else if (_analysisData->m_shop_search_online_valid == false)
    {
        _analysisData->m_shop_search_result.context.debug_str.append("invalid by online, ");
    }
    else if (_analysisData->query()->_shop_search_url_valid() == false)
    {
        _analysisData->m_shop_search_result.context.debug_str.append("invalid by url, ");
    }
    else if (_analysisData->query()->_shop_search_qp_valid() == false)
    {
        _analysisData->m_shop_search_result.context.debug_str.append("invalid by qp, ");
    }

    bool flag = (_analysisData->blenderConf()->m_g_sp_valid && 
            _analysisData->m_shop_search_online_valid    &&
            _analysisData->query()->_shop_search_url_valid() &&
            _analysisData->query()->_shop_search_qp_valid());
    return flag;
}


inline bool ShouldGetShopSearchData(BlenderAnalysisData*_analysisData, const jd::search::request::JdSearchQuery* pbQuery)
{
    bool b_shop_search = true;
    ShopSearchContext& shop_search_context = (_analysisData->m_shop_search_result).context;
    if (shop_search_context.request_type == REQUEST_SHOP_INTERSECTION)
    {
        /* expression key must be brand or publisher */
        if (pbQuery->_expression_key().empty() == false)
        {
            vector<string> tmp;
            vector<string> keys = blender::GetStrings(pbQuery->_expression_key(), search_frame::FQUERY_SPLITER);
            size_t key_size = keys.size();
            std::string out;
            for (size_t i = 0; i < key_size; ++i)
            {
                tmp = blender::GetStrings(keys[i], search_frame::FQUERY_PARA_SPLITER);
                if ((tmp.size() == 2) &&
                        (tmp[0].compare("brand") == 0 || tmp[0].compare("publishers") == 0))
                {
                    Normalize(tmp[1], out);
                    shop_search_context.expression_key.append(" ").append(out);
                }
                else
                {
                    b_shop_search = false;
                    break;
                }
            }
        }

        /* filter type must be catid or cid2 */
        if (b_shop_search)
        {
            size_t filt_info_size = _analysisData->m_url_filt_info.size();
            for (size_t i = 0; i < filt_info_size; ++i)
            {
                const std::string& filter_name = _analysisData->m_url_filt_info[i].first;
                if (filter_name.compare("cid2") == 0)
                {
                    shop_search_context.cid2_in_filter = _analysisData->m_url_filt_info[i].second;
                }
                else if (filter_name.compare("catid") == 0)
                {
                    shop_search_context.cid3_in_filter = _analysisData->m_url_filt_info[i].second;
                }
                else if (filter_name.compare("otc") == 0)
                {
                    continue;
                }
                else
                {
                    b_shop_search = false;
                    break;
                }
            }
        }

        if (b_shop_search)
        {
            if (shop_search_context.request_type == REQUEST_SHOP_INTERSECTION)
            {
                b_shop_search = (pbQuery->_sort_type().compare(search_frame::DEFAULT_SORTER_VALUE)==0);
            }
        }
    }
    else if (shop_search_context.request_type == REQUEST_SHOP_LIST)
    {
        b_shop_search = true;
    }
    return b_shop_search;
}


void ShopSearchRelatedCategory(BlenderAnalysisData*_analysisData)
{
    jd_search_merger::CategoryTree &cate_tree = *(CategoryTreeData::getInstance()->_cat_tree);
    ShopSearchContext& shop_search_info = _analysisData->m_shop_search_result.context;
    bool cate_flag = false;
    /* catid or cid2 in filter */
    if (!shop_search_info.cid2_in_filter.empty())
    {
        std::string& filt_cid2_param = shop_search_info.cid2_in_filter;
        boost::to_lower(filt_cid2_param);

        const char* p = filt_cid2_param.c_str();
        const char* pl = strchr(p, 'l');
        const char* pm = strchr(p, 'm');

        if (pl && pm)
        {
            std::string& cid2_str = shop_search_info.cid2_in_filter;
            cid2_str = cid2_str.substr(pl-p+1, pm-pl-1);
            try
            {
                int cid2 = boost::lexical_cast<int>(cid2_str);
                int cid1 = cate_tree.ParentCatID(cid2);
                if (cid1>0)
                {
                    shop_search_info.filt_cid1 = boost::lexical_cast<string>(cid1);
                    cate_flag = true;
                }
            }
            catch (...)
            {

            }
        }
    }
    else if (!shop_search_info.cid3_in_filter.empty())
    {
        std::string& filt_cid3_param = shop_search_info.cid3_in_filter;
        boost::to_lower(filt_cid3_param);

        const char* p = filt_cid3_param.c_str();
        const char* pl = strchr(p, 'l');
        const char* pm = strchr(p, 'm');

        if (pl && pm)
        {
            std::string& cid3_str = shop_search_info.cid3_in_filter;
            cid3_str = filt_cid3_param.substr(pl-p+1, pm-pl-1);
            int cid3 = -1;
            try
            {
                cid3 = boost::lexical_cast<int>(cid3_str);
            }
            catch ( ... )
            {
            }
            if (cid3>0)
            {
                int cid2 = cate_tree.ParentCatID(cid3);
                if (cid2>0)
                {
                    int cid1 = cate_tree.ParentCatID(cid2);
                    if (cid1>0)
                    {
                        shop_search_info.filt_cid1 = boost::lexical_cast<string>(cid1);
                        cate_flag = true;
                    }
                }
            }
        }
    }

    if (!cate_flag && (_analysisData->query()->_qp_result()._hc_cid3s_size() > 0))
    {
        shop_search_info.filt_cid1.clear();
        const jd::search::request::QPResult &qpresult = _analysisData->query()->_qp_result();
        for (int i = 0; i < qpresult._hc_cid3s_size(); ++i)
        {
            int cid2 = cate_tree.ParentCatID(qpresult._hc_cid3s(i));
            if (cid2>0)
            {
                int cid1 = cate_tree.ParentCatID(cid2);
                if (cid1>0)
                {
                    try
                    {
                        shop_search_info.filt_cid1.append(boost::lexical_cast<std::string>(cid1)).append(",");
                    }
                    catch (...)
                    {
                        break;
                    }
                }
            }

        }
    }
    return;
}


int ShopRequest::reqShopInsert()
{
    BlenderAnalysisData *_analysisData = master()->analysisData();
    
    if ( ShopSearchValid(_analysisData) && ShouldGetShopSearchData(_analysisData, _analysisData->query()) )
    {
        ShopSearchRelatedCategory(_analysisData);

        makeParam(_analysisData);
        if ( 0 != asyncSend() )
        {
            Trace_cnt(BLD_STAT_SP_ERROR, 1, _analysisData->m_ump2_tag);
            BLD_ERROR(master()->logStream(), master()->getStrSeqno() <<  "sendRequestAsync(shop1) faild"); 
            return -1;
        }

        _analysisData->shop_getting = true;
        return 0;
    }

    //不需要发送
    return 9;
}


int ShopRequest::reqShopEntry()
{
    BlenderAnalysisData *_analysisData = master()->analysisData();

    //根据qp返回的店铺id获取店铺信息
    if ( (_analysisData->blenderConf()->m_g_topshop_valid )
         && (_analysisData->query()->has__shop_id()) 
         && (_analysisData->blenderConf()->m_g_topshop_blacklist_set.find(_analysisData->query()->_shop_id()) == _analysisData->blenderConf()->m_g_topshop_blacklist_set.end())
       )
    {
        int vender_id   = _analysisData->qpQuery()->qp_result()._hit_shop_vender_id();
        int vender_type = _analysisData->qpQuery()->qp_result()._hit_shop_vender_type();
        
        makeParam(_analysisData, _analysisData->query()->_shop_id());
        if ( 0 != asyncSend() )
        {
            Trace_cnt(BLD_STAT_SP_ERROR, 1, _analysisData->m_ump2_tag);
            BLD_ERROR(master()->logStream(), master()->getStrSeqno() <<  "sendRequestAsync(shop2) faild"); 
            return -1;
        }

        return 0;
    }

    //不需要发送
    return 9;
}

inline bool ShopTabValid(BlenderAnalysisData*_analysisData, std::list<int>& cid1s)
{
    if ( !_analysisData->blenderConf()->m_g_shoptab_valid )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ShopTabValid state invalid");
        _analysisData->m_shoptab_info = "cfg:shoptab_valid invalid";
        return false;
    }
    if ( !_analysisData->m_shoptab_url_valid )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ShopTabValid state invalid");
        _analysisData->m_shoptab_info = "url:shoptab_valid invalid";
        return false;
    }

    jd::search::request::QPResult* qpResult = _analysisData->query()->mutable__qp_result();
    if ( qpResult->_hc_cid3s_size() == 0 )
    {
        BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ShopTabValid no cid3s");
        _analysisData->m_shoptab_info = "qp:no high cat3";
        return false;
    }

    jd_search_merger::CategoryTree &cate_tree = *(CategoryTreeData::getInstance()->_cat_tree);
    int cid3first = qpResult->_hc_cid3s(0);
    std::list<int> cid1_set;
    do{
        int cid2 = cate_tree.ParentCatID(cid3first);
        if ( cid2 > 0 )
        {
            int cid1 = cate_tree.ParentCatID(cid2);
            if ( cid1 <= 0 )
            {
                break;
            }
            if ( _analysisData->blenderConf()->m_g_shoptab_cat3list.find(cid3first) != _analysisData->blenderConf()->m_g_shoptab_cat3list.end())
            {
                cid1s.push_back(cid1);
            }
            else if ( _analysisData->blenderConf()->m_g_shoptab_cat2list.find(cid2) != _analysisData->blenderConf()->m_g_shoptab_cat2list.end())
            {
                cid1s.push_back(cid1);
            }
            else if ( _analysisData->blenderConf()->m_g_shoptab_cat1list.find(cid1) != _analysisData->blenderConf()->m_g_shoptab_cat1list.end())
            {
                cid1s.push_back(cid1);
            }
        }
    }while(0);

    //mtest check
    if ( !_blender_conf->m_g_shoptab_ab_mtest.empty() && !_analysisData->m_mtest_set.empty() )
    {
        std::vector<std::string> mtest_int;
        std::set_intersection(_blender_conf->m_g_shoptab_ab_mtest.begin(), _blender_conf->m_g_shoptab_ab_mtest.end(),
            _analysisData->m_mtest_set.begin(), _analysisData->m_mtest_set.end(),
            std::inserter(mtest_int, mtest_int.begin()));
        if ( !mtest_int.empty() )
        {
            int cid2 = cate_tree.ParentCatID(cid3first);
            if ( cid2 > 0 )
            {
                int cid1 = cate_tree.ParentCatID(cid2);
                if ( cid1 > 0 )
                {
                    if ( (_analysisData->blenderConf()->m_g_shoptab_ab_cat3list.find(cid3first) != _analysisData->blenderConf()->m_g_shoptab_ab_cat3list.end())
                         || (_analysisData->blenderConf()->m_g_shoptab_ab_cat2list.find(cid2) != _analysisData->blenderConf()->m_g_shoptab_ab_cat2list.end())
                         || (_analysisData->blenderConf()->m_g_shoptab_ab_cat1list.find(cid1) != _analysisData->blenderConf()->m_g_shoptab_ab_cat1list.end())
                         )
                    {
                        cid1s.push_back(cid1);
                    }
                }
            }
        }
    }
    
    BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno() <<  "ShopTabValid cid1s.size="<<cid1s.size());
    if ( cid1s.size() == 0 )
    {
        _analysisData->m_shoptab_info = "qp&cfg: no match high cat or not in mtest";
        return false;
    }
    return true;
}

int ShopRequest::reqShopTab()
{
    BlenderAnalysisData *_analysisData = master()->analysisData();

    std::list<int> cid1s;
    if ( ShopTabValid(_analysisData, cid1s) && !cid1s.empty() )
    {
        makeParam(_analysisData, cid1s);
        if ( 0 != asyncSend() )
        {
            Trace_cnt(BLD_STAT_SP_ERROR, 1);
            BLD_ERROR(master()->logStream(), master()->getStrSeqno() <<  "sendRequestAsync(shoptab) faild"); 
            _analysisData->m_shoptab_info = "blender: send req failed";
            return -1;
        }

        return 0;
    }

    //不需要发送
    return 9;
}


int ShopRequest::handelResponse(int err_no)
{
    BlenderAnalysisData* _analysisData = master()->analysisData();
    blender::ShopSearchInfo &shop_search_info = _analysisData->m_shop_search_result;
    
    const ShopResultData &shop_search_result = _response.result_data;
    const std::vector<ShopDocData>& shop_ret = shop_search_result.doc_data;
    BLD_DEBUG(_analysisData->logStream(), "ShopRequest::handelResponse("<<name()<<") ret_size:"<<shop_ret.size());
    if ( REQUEST_NAME_ShopTab == name() )
    {
        if ( 0 == err_no )
        {
            _analysisData->m_shoptab_shopsize = shop_ret.size();
            if ( _analysisData->m_shoptab_shopsize > 0 )
            {
                master()->logData()->ext_add("shoptab_size", cast2string(shop_ret.size()));
            }
        }
        _analysisData->m_shoptab_req_err_no = err_no;
        if ( 0 != err_no )
        {
            Trace_cnt(BLD_STAT_SP_ERROR, 1); 
        }
    }
    else if ( REQUEST_NAME_ShopEntry == name() )
    {
        if ( 0 == err_no )
        {
            for (int i=0; i<(int)shop_ret.size(); ++i)
            {
                unsigned int shop_id = shop_ret[i].shop_id;
                if ( shop_id == (unsigned int)(_analysisData->query()->_shop_id()) )
                {
                    _analysisData->shop_top_shop_id     = shop_id;
                    _analysisData->shop_top_vender_id   = shop_ret[i].vender_id;
                    _analysisData->shop_top_vender_type = shop_ret[i].vender_type;
                    master()->logData()->ext_add("shopentry_shopid", cast2string(shop_id));
                }

                BLD_DEBUG(_analysisData->logStream(), "SHOP2 result: shop_id:"<<shop_id 
                        <<" vender_id:"<<shop_ret[i].vender_id
                        <<" vender_type:"<<shop_ret[i].vender_type
                        <<" shop_type:"<<shop_ret[i].shop_type);
            }
        }
        _analysisData->m_shop_search_req2_err_no = err_no;
        if ( 0 != err_no )
        {
            Trace_cnt(BLD_STAT_SP_ERROR, 1, _analysisData->m_ump2_tag); 
        }
        master()->logData()->ext_add("topshop_shopId", cast2string(_analysisData->shop_top_shop_id));
    }
    else if ( REQUEST_NAME_ShopInsert == name() )
    {
        if ( 0 == err_no )
        {
            //店铺穿插
            std::vector<ShopInfoDetail>& shop_detail_list = shop_search_info.result.shop_list;
            std::map<int32_t, int32_t>& shop_idx_map = shop_search_info.context.shop_list_idx;
            for (int i=0; i<(int)shop_ret.size(); ++i)
            {
                int32_t shop_id = shop_ret[i].shop_id;
                if (shop_id <= 0)
                {
                    //ERROR_MESSAGE("shop id wrong! " + boost::lexical_cast<string>(shop_id));
                    continue;
                }
                /* save shopid and idx in result */
                shop_idx_map.insert(std::make_pair<int32_t, int32_t>(shop_id, i));
                ShopInfoDetail shop_detail(shop_id,
                        shop_ret[i].vender_id,
                        shop_ret[i].vender_type,
                        shop_ret[i].shop_type,
                        shop_ret[i].vender_total_score,
                        shop_ret[i].vender_ware_score,
                        shop_ret[i].vender_service_score,
                        shop_ret[i].vender_effective_score,
                        shop_ret[i].icon,
                        shop_ret[i].shop_name,
                        shop_ret[i].shop_logo,
                        shop_ret[i].business_category,
                        shop_ret[i].main_brand,
                        shop_ret[i].pic_url,
                        shop_ret[i].summary,
                        shop_ret[i].shop_brief);
                shop_detail_list.push_back(shop_detail);
            }
            if ( shop_ret.size() > 0 )
            {
                master()->logData()->ext_add("shopinsert_size", cast2string(shop_ret.size()));
            }
            else
            {
                shop_search_info.context.debug_str.append("shop result empty! ");
            }
        }
        _analysisData->m_shop_search_req_err_no = err_no;
        _analysisData->m_shop_search_flag = !(_analysisData->m_shop_search_result.result.shop_list.empty());
        if ( 0 != err_no )
        {
            _analysisData->m_shop_search_result.context.debug_str.append("get shop result faild! ");
            Trace_cnt(BLD_STAT_SP_ERROR, 1, _analysisData->m_ump2_tag); 
        }
    }
    else
    {
        BLD_ERROR(_analysisData->logStream(), "unkown type:"<<name());
    }
    return err_no;
}
