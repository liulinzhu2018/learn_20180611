#ifndef __BLD_CACHE_REQUEST_H__
#define __BLD_CACHE_REQUEST_H__

#include "jimdb_request.h"

namespace blender{

class CacheRequest : public JimDBRequest
{
    DEF_JIMDB_REQ_BASE(query_cache)
public:
    CacheRequest(const std::string &name, BlenderMaster_ptr master, int msg_type, BlenderRequest::ASYNCType rt = BlenderRequest::REQUEST_SYNC_SERVICE);
};


class DoudiRequest : public JimDBRequest
{
    DEF_JIMDB_REQ_BASE(doudi)
public:
    DoudiRequest(const std::string &name, BlenderMaster_ptr master, int msg_type, BlenderRequest::ASYNCType rt = BlenderRequest::REQUEST_SYNC_SERVICE);
};

}//end namespace

#endif
