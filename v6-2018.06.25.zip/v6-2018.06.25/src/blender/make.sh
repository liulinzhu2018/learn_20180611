#/bin/sh

bld_path=${PWD}
build_path=${PWD}/../release
build_path_bld=${build_path}/blender
#THIRD_PARTY=../../jd_search_common_3rdparty/3rdparty

cmd=$1
if [ "${cmd}x" == "allx" ]; then
    mkdir ../release; cd ../release
    cmake -DCMAKE_BUILD_TYPE=Release ..
    cd blender;
    make -j4
    cd ../clustermap
    make -j4
elif [ "${cmd}x" == "x" ]; then
    cd ${build_path_bld}; make -j4
elif [ "${cmd}x" == "bin" ]; then
    cd ${build_path_bld}; make -j4
fi
