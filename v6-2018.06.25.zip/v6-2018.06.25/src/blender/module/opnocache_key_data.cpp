#include "hotdata_manager.h"
#include "opnocache_key_data.h"

#include "str_util.h"
#include "blender_config.h"
using namespace std;
using namespace blender;


OpNoCacheData::OpNoCacheData():_opnocache_keys(NULL), _old_opnocache_keys(NULL)
{

}

OpNoCacheData::~OpNoCacheData()
{
	if(NULL != _old_opnocache_keys)
	{
		delete _old_opnocache_keys;
		_old_opnocache_keys = NULL;
	}
}

OpNoCacheData *OpNoCacheData::getInstance()
{
    static OpNoCacheData* _instance = NULL; 
    if( NULL == _instance )
    {
        _instance = new OpNoCacheData();
    }

    return _instance;
}

HOTDATA_REGDATA(OpNoCacheData, "reload_opnocache_key");

int OpNoCacheData::init()
{
	string html;
	int ret = update(html);
	return 0;
}	

int OpNoCacheData::info(std::string &html)
{
    if( NULL == _opnocache_keys )
    {
        html.append("\n _opnocache_keys is NULL!!! \n\n");
        return -1;
    }
    std::set<string>::iterator it = _opnocache_keys->begin();
    
    html += "_opnocache_keys in blender :";
    html += "\n";
    for( ; it != _opnocache_keys->end(); it++)
    {
        html += "\n";
        html += *it;
    }
    
    html.append("\n" + HotDataBase::getUpdateTimeStr() );
	return 0;
}

int OpNoCacheData::update(std::string &html)
{
    std::set<std::string> *tmp_opnocache_keys = new std::set<std::string>();

    std::ifstream fin;
    fin.open(_blender_conf->m_g_opdisablecache_file.c_str());
    
    if ( !fin )
    {
        html.append("\n !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!open _opnocache_keys_file failed:");
        html.append(_blender_conf->m_g_opdisablecache_file);
        delete tmp_opnocache_keys;
        return -1;
    }
    
    int line_cnt = 0;
    int ok_cnt  = 0;
    int cmm_cnt  = 0;
    string line;
    string gbk_key;
    while( !fin.eof() )   
    {
        std::getline(fin, line);
        line_cnt++; 
        if ( !line.empty() )
        {
            if('#' == line[0])
            {
                cmm_cnt++;
                continue;
            }

            //op给文件已经是gbk文件,不必转码
            // if(! StrUtil::utf82gbk(line, gbk_key) )
            // {
            //     err_cnt++;
            //     html.append("\n!!!!!!!!convert to gbk fail line:");
            //     html.append(line);
            //     continue;
            // }

            std::vector<std::string> tmp_str_vec = StrUtil::split(line, "\t");
            if(tmp_str_vec.size() > 0)
            {
                tmp_opnocache_keys->insert(tmp_str_vec[0]);
            }
            else
            {
                cmm_cnt++;
                continue;
            }
            ok_cnt++;
        }
    }
    fin.close();

    if( NULL != _old_opnocache_keys )
    {
        delete _old_opnocache_keys;
        _old_opnocache_keys = NULL;
    }

    _old_opnocache_keys = _opnocache_keys;
    _opnocache_keys = tmp_opnocache_keys;
    html.append(" \n>>>>>load _opnocache_keys OK, valid size:");
    html.append(boost::lexical_cast<std::string>(tmp_opnocache_keys->size()));
    html.append(" line_cnt:" + boost::lexical_cast<std::string>(line_cnt));
    html.append(" cmm_cnt:" + boost::lexical_cast<std::string>(cmm_cnt));
    html.append("\n");

    HotDataBase::update(html);
    return 0;
}	

bool OpNoCacheData::is_in_opnocache_keys(const std::string &key )
{
    if ( (NULL == _opnocache_keys) || key.empty() )
    {
        return false;
    }
    
    if ( _opnocache_keys->find(key) != _opnocache_keys->end() )
    {
        return true;
    }

    return false;   
}