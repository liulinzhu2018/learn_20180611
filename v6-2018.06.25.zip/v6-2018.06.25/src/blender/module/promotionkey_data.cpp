#include "hotdata_manager.h"
#include "promotionkey_data.h"

#include "str_util.h"
#include "blender_config.h"
#include "hotdata_manager.h"
using namespace blender;
using namespace std;

PromotionkeyData::PromotionkeyData():_promotionkey_list(NULL), _old_promotionkey_list(NULL)
{

}

PromotionkeyData::~PromotionkeyData()
{
	if(NULL == _old_promotionkey_list )
	{
		delete _old_promotionkey_list;
		_old_promotionkey_list = NULL;
	}
}

PromotionkeyData *PromotionkeyData::getInstance()
{
    static PromotionkeyData *_instance = NULL;
    if( NULL == _instance )
    {
        _instance = new PromotionkeyData();
    }

    return _instance;
}

HOTDATA_REGDATA(PromotionkeyData, "reload_promotionkey");

int PromotionkeyData::init()
{
    string html;
    int ret = update(html);
	return ret;
}	

int PromotionkeyData::info(std::string &html)
{
    if( NULL == _promotionkey_list )
    {
        html.append("\n promotionkey_list is NULL!!! \n\n");
        return -1;
    }

    std::set<string>::iterator it = _promotionkey_list->begin();
    
    html += "promotionkey_list in blender :";
    html += "\n";
    for( ; it != _promotionkey_list->end(); it++)
    {
        html += "\n";
        html += *it;
    }

    html.append("\n" + HotDataBase::getUpdateTimeStr() );
	return 0;
}


int PromotionkeyData::update(std::string &html)
{
    std::set<std::string> *tmp_promotionkey_list = new std::set<std::string>();

    std::ifstream fin;
    fin.open(_blender_conf->m_g_promotionkey_file.c_str());
    
    if ( !fin )
    {
        html.append("\n !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!open url_key_whitelist_file failed:");
        html.append(_blender_conf->m_g_promotionkey_file);
        delete tmp_promotionkey_list;
        return -1;
    }
    
    int line_cnt = 0;
    int err_cnt  = 0;
    int ok_cnt  = 0;
    int cmm_cnt  = 0;
    string line;
    string gbk_key;
    while( !fin.eof() )   
    {
        std::getline(fin, line);
        line_cnt++; 
        if ( !line.empty() )
        {
            if('#' == line[0])
            {
                cmm_cnt++;
                continue;
            }

            if(! StrUtil::utf82gbk(line, gbk_key) )
            {
                err_cnt++;
                html.append("\n!!!!!!!!convert to gbk fail line:");
                html.append(line);
                continue;
            }
            tmp_promotionkey_list->insert(gbk_key);
            ok_cnt++;
        }
    }

    fin.close();

    if( NULL != _old_promotionkey_list )
    {
        delete _old_promotionkey_list;
        _old_promotionkey_list = NULL;
    }

    _old_promotionkey_list = _promotionkey_list;
    _promotionkey_list = tmp_promotionkey_list;
    html.append(" \n>>>>>load promotion_key OK, valid size:");
    html.append(boost::lexical_cast<std::string>(tmp_promotionkey_list->size()));
    html.append(" line_cnt:" + boost::lexical_cast<std::string>(line_cnt));
    html.append(" err_cnt:" + boost::lexical_cast<std::string>(err_cnt));
    html.append(" cmm_cnt:" + boost::lexical_cast<std::string>(cmm_cnt));
    html.append("\n");

    HotDataBase::update(html);
    return 0;

}

bool PromotionkeyData::isPromotionKey(const std::string &url_key)
{
	if ( (NULL == _promotionkey_list) || url_key.empty() )
    {
        return false;
    }
    
    if ( _promotionkey_list->find(url_key) != _promotionkey_list->end() )
    {
        return true;
    }

    return false;  
}
