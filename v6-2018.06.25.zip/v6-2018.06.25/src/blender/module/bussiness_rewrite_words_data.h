#ifndef __BUSINESS_REWRITE_WORDS_DATA_H__
#define __BUSINESS_REWRITE_WORDS_DATA_H__
#include "hotdata_base.h"

#include <set>
#include <string>

namespace blender
{

class BusinessRewriteWordsData :public HotDataBase
{
public:
	~BusinessRewriteWordsData();
	int init();
	int info(std::string &html);
	int update(std::string &html);
	bool is_in_bussiness_rewrite_words(const std::string &key );

	static BusinessRewriteWordsData *getInstance();
private:
	BusinessRewriteWordsData();
	std::set<std::string> *_bussiness_rewrite_words;
    std::set<std::string> *_old_bussiness_rewrite_words;

};

}
#endif