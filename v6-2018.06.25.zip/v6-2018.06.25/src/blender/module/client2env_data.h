#ifndef __BLENDER_CLIENT2ENV_DATA_H__
#define __BLENDER_CLIENT2ENV_DATA_H__
#include "hotdata_base.h"
#include <string>
#include <map>
#include "tinyxml.h"
#include "blender_config.h"

namespace blender
{

class Client2EnvData: public HotDataBase 
{
public:
	~Client2EnvData();

	int init();
	int info(std::string &html);
	int update(std::string &html);
	static Client2EnvData *getInstance();
	int loadClientXml(const std::string &conf,
		std::map<std::string, int>* site_client_map, 
		std::map<std::string, std::string>* env_client_map, 
		std::map<std::string, std::string>* ump_key_caller_map,
		std::string &html);

	int site(const std::string &client) const;
	std::string caller_key(const std::string &client) const;
	bool key_configed(const std::string &client) const;
	std::string caller_env(const std::string &client) const;
	    //站点定义
    enum BldSiteType {
        SITE_BEGIN  = 0,
        // 商城主站
        SITE_MAIN   = 1,
        SITE_GLOBAL = 2,
        SITE_YHD    = 4,

        SITE_END,
    };
private:
	Client2EnvData();

    std::map<std::string, int>* _site_client_map;
    std::map<std::string, int>* _old_site_client_map;
    std::map<std::string, std::string>* _env_client_map;
    std::map<std::string, std::string>* _old_env_client_map;
	std::map<std::string, std::string>* _ump_key_caller_map;
	std::map<std::string, std::string>* _old_ump_key_caller_map;
};

}
#endif