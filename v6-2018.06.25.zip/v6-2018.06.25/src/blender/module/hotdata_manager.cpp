#include "hotdata_manager.h"

#include <iostream>
#include <fstream> 
#include "blender_config.h"
#include "bld_global.h"
#include "blender_logger.h"
#include "blender_config_data.h"
using namespace std;
using namespace blender;


HotDataManager::HotDataManager()
{
    _start_time = time(NULL);
}

HotDataManager::~HotDataManager()
{
    map<string,HotDataBase*>::iterator mit;

    for( mit = _cmd2hotdata.begin(); mit != _cmd2hotdata.end(); mit++ )
    {
        if(mit->second != NULL)
        {
            delete mit->second;
            mit->second = NULL;
        }
    }
}
HotDataManager* HotDataManager::getInstance()
{
    static HotDataManager* _instance = NULL;
    if( NULL == _instance )
    {
        _instance = new HotDataManager();
    }

    return _instance;
}

int HotDataManager::init()
{
    map<string,HotDataBase*>::iterator mit;

    for( mit = _cmd2hotdata.begin(); mit != _cmd2hotdata.end(); mit++ )
    {
        if(mit->second != NULL)
        {
            mit->second->init();
        }
    }   
	return 0;
}


int HotDataManager::handleInfo(const string info_cmd, string &html)
{
    map<string,HotDataBase*>::iterator mit;
    string cmd = "reload_" + info_cmd;
    mit = _cmd2hotdata.find( cmd );

    if( mit != _cmd2hotdata.end() )
    {
        if(mit->second != NULL)
            mit->second->info(html);
    }else{
        html.append("the cmd you input is wrong! please check it and input again!");
    }
	return 0;
}


int HotDataManager::handleConfig(const string cmd_url, string &html)
{
	string opinfo;
    map<string, string> cmd_key2value = parse_cmd(cmd_url);
    map<string, string>::iterator cit;
    
    map<string,HotDataBase*>::iterator mit;
    for ( cit = cmd_key2value.begin(); cit != cmd_key2value.end(); cit++ )
    {
        mit = _cmd2hotdata.find(cit->first);
        if( mit != _cmd2hotdata.end() )
        {
            if(mit->second != NULL && cit->second == "yes")
            {
                time_t now = time(NULL);
                if ( (now - mit->second->getUpdateTime() ) < 10 )
                {
                    html.append(" update frequently, please wait 10 seconds!\n");
                    return 0;
                }
                mit->second->update(html);
            }
            
            continue;
        }

        if ( cit->first == "netlog_level" )
        {
            if ( NULL !=BlenderLogger::instance()->netLog() )
            {
                int level = 0;
                try
                {
                    level = boost::lexical_cast<int>(cit->second);
                }
                catch(...)
                {
                    html.append("\n set blender_netlog_level=").append(cit->second).append(" transfer to int failed");
                    continue;
                }

                BLD_INFO(NULL, "[INFO] set netlog_level="<<level);
                opinfo.append("netlog_level:").append(cit->second).append("\n");
                switch(level)
                {
                    case 0: BlenderLogger::instance()->netLog()->setLogLevel(log4cplus::DEBUG_LOG_LEVEL); break;
                    case 1: BlenderLogger::instance()->netLog()->setLogLevel(log4cplus::INFO_LOG_LEVEL); break;
                    case 2: BlenderLogger::instance()->netLog()->setLogLevel(log4cplus::WARN_LOG_LEVEL); break;
                    case 3: BlenderLogger::instance()->netLog()->setLogLevel(log4cplus::ERROR_LOG_LEVEL); break;
                    case 4: BlenderLogger::instance()->netLog()->setLogLevel(log4cplus::OFF_LOG_LEVEL); break;
                    default: opinfo.append("netlog_level:").append(cit->second).append(" failed\n");break;
                }
            }
        }
        else if ( cit->first == "filelog_level" )
        {
            if ( NULL != BlenderLogger::instance()->fileLog() )
            {
                int level = 0;
                try
                {
                    level = boost::lexical_cast<int>(cit->second);
                }
                catch(...)
                {
                    html.append("\n set blender_filelog_level=").append(cit->second).append(" transfer to int failed");
                    continue;
                }

                BLD_INFO(NULL, "[INFO] set filelog_level="<<level);
                opinfo.append("filelog_level:").append(cit->second).append("\n");
                switch(level)
                {
                    case 0: BlenderLogger::instance()->fileLog()->setLogLevel(log4cplus::DEBUG_LOG_LEVEL); break;
                    case 1: BlenderLogger::instance()->fileLog()->setLogLevel(log4cplus::INFO_LOG_LEVEL); break;
                    case 2: BlenderLogger::instance()->fileLog()->setLogLevel(log4cplus::WARN_LOG_LEVEL); break;
                    case 3: BlenderLogger::instance()->fileLog()->setLogLevel(log4cplus::ERROR_LOG_LEVEL); break;
                    case 4: BlenderLogger::instance()->fileLog()->setLogLevel(log4cplus::OFF_LOG_LEVEL); break;
                    default: opinfo.append("filelog_level=").append(cit->second).append(" failed\n");break;
                }
            }
        }
        else
        {
            if( cit->first != "env" && cmd_key2value.find("env") != cmd_key2value.end())
            {
                BlenderConfig *bld_config = BlenderConfigData::getInstance(cmd_key2value["env"], false);
                if( bld_config )
                {
                    bld_config->set(cit->first, cit->second);
                }else
                {
                    html.append("the env input is wrong! \n");
                }
                break;
            }

            BlenderConfigData::getInstance()->setAllBlenderConfig(cit->first, cit->second);
            BlenderConfigData::getInstance()->setOthersConfig(cit->first, cit->second);
        }
    }

    if( cmd_key2value.find("env") != cmd_key2value.end() )
    {
        html.append(cmd_key2value["env"] + "  BlenderConfig  -----------------------  \n");
        html.append( BlenderConfigData::getInstance( cmd_key2value["env"], true)->DebugString() );
    }else{
        html.append("default  BlenderConfig  -----------------------  \n");
        html.append( _blender_conf->DebugString() );
    }

    return 0;
}

int HotDataManager::regType(const string cmd, HotDataBase* hotData)
{
	pair<map<string, HotDataBase*>::iterator, bool> ret;

	ret  = _cmd2hotdata.insert(make_pair(cmd, hotData) );

	if(!ret.second)
	{
        cout<<"hotdat_manager.cpp::regType() fail!,update_cmd is "<<cmd<<std::endl;
	}
	return 0;
	
}

map<string, string> HotDataManager::parse_cmd(const string &url_param)
{
    map<string, string> cmd_key2value;

    vector<string> params = GetStrings(url_param, "&");

    for ( size_t i = 0; i < params.size(); i++ )
    {
        vector<string> key2value = GetStrings(params[i], "=");

        if ( key2value.size() == 2 )
        {
            cmd_key2value[key2value[0]] = key2value[1];
        }
    }

    return cmd_key2value;
}

std::string HotDataManager::SystemInfo() const
{
    std::stringstream ss;
    ss << "\n=============== time:\n";
    ss << "service.role=blender" << std::endl;
#ifdef BLD_COMPILE_TIME
    ss << "service.compile_time=" << BLD_COMPILE_TIME << std::endl;
#else
    ss << "service.compile_time=" << "Unknown" << std::endl;
#endif
    char tm_str[100] = {0};
    struct tm *_tm = localtime(&_start_time);
    strftime(tm_str, 100, "%Y-%m-%d %H:%M:%S", _tm);
    ss << "service.start_time=" << tm_str << std::endl;

    map<string,HotDataBase*>::const_iterator mit;

    for( mit = _cmd2hotdata.begin(); mit != _cmd2hotdata.end(); mit++ )
    {
        if(mit->second != NULL)
        {
            time_t loat_time = mit->second->getUpdateTime();
            _tm = localtime( &loat_time);

            strftime(tm_str, 100, "%Y-%m-%d %H:%M:%S", _tm);
            if(mit->first.length() > 7)
            {
                string name = mit->first.substr(7);
                if (0  == loat_time )
                {
                    ss << name << ":can not fine this file" << std::endl;
                    continue;
                }
                ss << name <<"_update_time=" << tm_str << std::endl;
            }else{
                if (0  == loat_time )
                {
                    ss << mit->first << ":can not fine this file" << std::endl;
                    continue;
                }
                ss << mit->first <<"_update_time=" << tm_str << std::endl;
            }
        }
    }   
    return ss.str();
}
