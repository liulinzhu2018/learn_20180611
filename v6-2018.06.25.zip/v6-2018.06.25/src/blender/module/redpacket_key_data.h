#ifndef __REDPACKET_KEY_DATA_H__
#define __REDPACKET_KEY_DATA_H__
#include "hotdata_base.h"

#include <set>
#include <string>
namespace blender
{
class RedPacketkeyData :public HotDataBase
{
public:
	~RedPacketkeyData();

	int init();
	int info(std::string &html);
	int update(std::string &html);
	bool is_red_packets_key(const std::string &url_key);

	static RedPacketkeyData *getInstance();
private:
	RedPacketkeyData();
	std::set<std::string> *_redpkg_keys;
	std::set<std::string> *_old_redpkg_keys;


};
}
#endif