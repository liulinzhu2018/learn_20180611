#ifndef __HOTDATA_MANAGER_H__
#define __HOTDATA_MANAGER_H__

#include "hotdata_base.h"
#include <map>
#include "str_util.h"

namespace blender
{

class HotDataManager
{
public:
	HotDataManager();
	~HotDataManager();
	static HotDataManager* getInstance();

	int init();
	int handleInfo(const std::string info_cmd, std::string &html);
	int handleConfig(const std::string cmd_url, std::string &html);
	int regType(const std::string cmd,  HotDataBase* hotData);

	std::string SystemInfo() const;
private:
	std::map<std::string, std::string> parse_cmd(const std::string &url_param);
	std::map<std::string, HotDataBase*> _cmd2hotdata;

	time_t _start_time;
};


#define HOTDATA_REGDATA(HotDataClass, cmd) \
struct HotDataRegInfo_##HotDataClass \
{\
	HotDataRegInfo_##HotDataClass()\
	{\
		HotDataManager::getInstance()->regType(cmd, HotDataClass::getInstance());\
	}\
}HotDataRegInfo_instance_##HotDataClass;

}
#endif