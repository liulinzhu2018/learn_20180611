#ifndef __PROMOTIONKEY_DATA_H__
#define __PROMOTIONKEY_DATA_H__
#include "hotdata_base.h"

#include <set>
#include <string>
namespace blender
{

class PromotionkeyData :public HotDataBase
{
public:
	~PromotionkeyData();

	int init();
	int info(std::string &html);
	int update(std::string &html);
	bool isPromotionKey(const std::string &url_key);

	static PromotionkeyData *getInstance();
private:
	PromotionkeyData();
	std::set<std::string> *_promotionkey_list;
	std::set<std::string> *_old_promotionkey_list;

};
}
#endif