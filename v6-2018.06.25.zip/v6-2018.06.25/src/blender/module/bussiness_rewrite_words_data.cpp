#include "hotdata_manager.h"
#include "bussiness_rewrite_words_data.h"

#include "str_util.h"
#include "blender_config.h"
using namespace std;
using namespace blender;


BusinessRewriteWordsData::BusinessRewriteWordsData():_bussiness_rewrite_words(NULL), _old_bussiness_rewrite_words(NULL)
{

}

BusinessRewriteWordsData::~BusinessRewriteWordsData()
{
	if(NULL != _old_bussiness_rewrite_words)
	{
		delete _old_bussiness_rewrite_words;
		_old_bussiness_rewrite_words = NULL;
	}
}

BusinessRewriteWordsData *BusinessRewriteWordsData::getInstance()
{
    static BusinessRewriteWordsData* _instance = NULL; 
    if( NULL == _instance )
    {
        _instance = new BusinessRewriteWordsData();
    }

    return _instance;
}

HOTDATA_REGDATA(BusinessRewriteWordsData, "reload_bussiness_rewrite_words");

int BusinessRewriteWordsData::init()
{
	string html;
	int ret = update(html);
	return 0;
}	

int BusinessRewriteWordsData::info(std::string &html)
{
    if( NULL == _bussiness_rewrite_words )
    {
        html.append("\n _bussiness_rewrite_words is NULL!!! \n\n");
        return -1;
    }
    std::set<string>::iterator it = _bussiness_rewrite_words->begin();
    
    html += "_bussiness_rewrite_words in blender :";
    html += "\n";
    for( ; it != _bussiness_rewrite_words->end(); it++)
    {
        html += "\n";
        html += *it;
    }
    
    html.append("\n" + HotDataBase::getUpdateTimeStr() );
	return 0;
}

int BusinessRewriteWordsData::update(std::string &html)
{
    std::set<std::string> *tmp_bussiness_rewrite_words = new std::set<std::string>();

    std::ifstream fin;
    fin.open(_blender_conf->m_g_bussiness_rewrite_words_file.c_str());
    
    if ( !fin )
    {
        html.append("\n !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!open bussiness_rewrite_words_file failed:");
        html.append(_blender_conf->m_g_bussiness_rewrite_words_file);
        delete tmp_bussiness_rewrite_words;
        return -1;
    }
    
    int line_cnt = 0;
    int err_cnt  = 0;
    int ok_cnt  = 0;
    int cmm_cnt  = 0;
    string line;
    string gbk_key;
    while( !fin.eof() )   
    {
        std::getline(fin, line);
        line_cnt++; 
        if ( !line.empty() )
        {
            if('#' == line[0])
            {
                cmm_cnt++;
                continue;
            }

            if(! StrUtil::utf82gbk(line, gbk_key) )
            {
                err_cnt++;
                html.append("\n!!!!!!!!convert to gbk fail line:");
                html.append(line);
                continue;
            }
            tmp_bussiness_rewrite_words->insert(gbk_key);
            ok_cnt++;
        }
    }
    fin.close();

    if( NULL != _old_bussiness_rewrite_words )
    {
        delete _old_bussiness_rewrite_words;
        _old_bussiness_rewrite_words = NULL;
    }

    _old_bussiness_rewrite_words = _bussiness_rewrite_words;
    _bussiness_rewrite_words = tmp_bussiness_rewrite_words;
    html.append(" \n>>>>>load _bussiness_rewrite_words OK, valid size:");
    html.append(boost::lexical_cast<std::string>(tmp_bussiness_rewrite_words->size()));
    html.append(" line_cnt:" + boost::lexical_cast<std::string>(line_cnt));
    html.append(" err_cnt:" + boost::lexical_cast<std::string>(err_cnt));
    html.append(" cmm_cnt:" + boost::lexical_cast<std::string>(cmm_cnt));
    html.append("\n");

    HotDataBase::update(html);
    return 0;
}	

bool BusinessRewriteWordsData::is_in_bussiness_rewrite_words(const std::string &key )
{
    if ( (NULL == _bussiness_rewrite_words) || key.empty() )
    {
        return false;
    }
    
    if ( _bussiness_rewrite_words->find(key) != _bussiness_rewrite_words->end() )
    {
        return true;
    }

    return false;   
}