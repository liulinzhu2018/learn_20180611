#ifndef __OPNOCACHE_KEY_DATA_H__
#define __OPNOCACHE_KEY_DATA_H__
#include "hotdata_base.h"

#include <set>
#include <string>

namespace blender
{

class OpNoCacheData :public HotDataBase
{
public:
	~OpNoCacheData();
	int init();
	int info(std::string &html);
	int update(std::string &html);
	bool is_in_opnocache_keys(const std::string &key );

	static OpNoCacheData *getInstance();
private:
	OpNoCacheData();
	std::set<std::string> *_opnocache_keys;
    std::set<std::string> *_old_opnocache_keys;

};

}
#endif