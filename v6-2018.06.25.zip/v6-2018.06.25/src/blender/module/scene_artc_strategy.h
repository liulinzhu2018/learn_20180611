#ifndef SCENE_ARTC_STRATEGY_H_
#define SCENE_ARTC_STRATEGY_H_

#include "hotdata_base.h"
#include <map>
#include <vector>
#include <string>
#include "blender_analysis_data.h"
#include "json/value.h"

namespace blender
{

const int ARTICLEADD    = 100000;
const int ARTICLE_DAREN = 100001;
const std::string ARTICLESTR = "article";
const std::string SCENESTR = "scene";

struct sortInsertObject //排序用的结构体
{
	Json::Value insertObject;
	int weight;
};

class sceneArtcStrategy :public HotDataBase
{
public:
	~sceneArtcStrategy();

	int init();
	int info(std::string &html);
	int update(std::string &html);

	static sceneArtcStrategy *getInstance();

	int packInsert(Json::Value& insertObject, BlenderAnalysisData *_analysisData);
private:
	sceneArtcStrategy();

	int loadSortInfo(std::string &html, std::map<int, std::map<int,int> >*& tmp_map);

	int ParseArtcDarenJson(std::vector<sortInsertObject> &object_vector, BlenderAnalysisData *_analysisData, const std::string &json_str, const std::map<int,int>* weight_map);
	int ParseSceneInsertJson(std::vector<sortInsertObject> &object_vector, BlenderAnalysisData *_analysisData, const std::string &json_str, const std::map<int,int>* weight_map);
	int ParseScene2InsertJson(std::vector<sortInsertObject> &object_vector, BlenderAnalysisData *_analysisData, const std::map<std::string, std::string> &scene2_insert_json, const std::map<int,int>* weight_map);
	//map<cid3, map < type,weight>>
	std::map<int, std::map<int,int> >* _cid3_sort;
	std::map<int, std::map<int,int> >* _old_cid3_sort;
};

}
#endif