#include "hotdata_manager.h"
#include "blender_config_data.h"
#include "ump_report.h"
#include "jdsz_logtrace_manager.h"
#include "local_cache.h"

using namespace blender;
using namespace std;

//需要动态配置的渠道
const char* BlenderConfigData::m_g_env_config_arr[] = {"app","pc","wx","qq"};

map<string, BlenderConfig*>* BlenderConfigData::env_blender_config = new map<string, BlenderConfig*>();
map<string, BlenderConfig*>* BlenderConfigData::old_env_blender_config = new map<string, BlenderConfig*>();
BlenderConfigData::BlenderConfigData():
    _old_blender_conf(NULL)
{
    int array_size = sizeof(m_g_env_config_arr)/sizeof(long);
    for ( int fid = 0; fid < array_size; ++fid )
    {
        env_blender_config->insert( pair<string, BlenderConfig*>(string(m_g_env_config_arr[fid]), NULL) );
        old_env_blender_config->insert( pair<string, BlenderConfig*>(string(m_g_env_config_arr[fid]), NULL) );
    }
}

BlenderConfigData::~BlenderConfigData()
{
	if( NULL != _old_blender_conf )
	{
		delete _old_blender_conf;
		_old_blender_conf = NULL;
	}
}

BlenderConfigData *BlenderConfigData::getInstance()
{
    static BlenderConfigData *_instance = NULL;
    if( NULL == _instance )
    {
        _instance = new BlenderConfigData();
    }

    return _instance;
}
//注册动态文件类
HOTDATA_REGDATA(BlenderConfigData, "reload_config");
int BlenderConfigData::init()
{
    _old_blender_conf = new BlenderConfig();
    _old_blender_conf->loadConfig(_blender_conf->config_file());
    string html;
    HotDataBase::update(html);
    
    int array_size = sizeof(m_g_env_config_arr)/sizeof(long);
    for ( int fid = 0; fid < array_size; ++fid )
    {
        string _env(m_g_env_config_arr[fid]);
        map<string, BlenderConfig*>::iterator env_blender_conf_it = env_blender_config->find(_env);
        map<string, BlenderConfig*>::iterator old_env_blender_conf_it = old_env_blender_config->find(_env);

        if(env_blender_conf_it != env_blender_config->end() && old_env_blender_conf_it != old_env_blender_config->end() )
        {
            updateConfigEnv(html, env_blender_conf_it->second, old_env_blender_conf_it->second, _env);
        }
    }
    
    return 0;
}	

int BlenderConfigData::info(std::string &html)
{
    if( NULL == _blender_conf )
    {
        html.append("\n _blender_conf is NULL!!! \n\n");
        return -1;
    }

    html.append(_blender_conf->DebugString());

    html.append("\n" + HotDataBase::getUpdateTimeStr() );
	return 0;
}

int BlenderConfigData::update(std::string &html)
{
    BlenderConfig* tmp_blender_conf = new BlenderConfig();

    if( NULL == tmp_blender_conf )
    {
        html.append("\n no memory , updata config fail!! \n");
        return -1;
    }

    int ret = tmp_blender_conf->loadConfig(_blender_conf->config_file(), _blender_conf->m_g_env, _blender_conf->m_g_cluster); 

    if ( ret != 0 )
    {
        html.append("\nload Conf file failed:").append(_blender_conf->config_file() + ", ret:").append(boost::lexical_cast<string>(ret));
        delete tmp_blender_conf;
        return ret;
    }

    if ( _old_blender_conf != NULL )
    {
        delete _old_blender_conf;
    }

    _old_blender_conf = _blender_conf;
    _blender_conf = tmp_blender_conf;

    int array_size = sizeof(m_g_env_config_arr)/sizeof(long);
    for ( int fid = 0; fid < array_size; ++fid )
    {
        string _env(m_g_env_config_arr[fid]);
        map<string, BlenderConfig*>::iterator env_blender_conf_it = env_blender_config->find(_env);
        map<string, BlenderConfig*>::iterator old_env_blender_conf_it = old_env_blender_config->find(_env);

        if(env_blender_conf_it != env_blender_config->end() && old_env_blender_conf_it != old_env_blender_config->end() )
        {
            updateConfigEnv(html, env_blender_conf_it->second, old_env_blender_conf_it->second, _env);
        }
    }

    HotDataBase::update(html);
    return ret;
}

int BlenderConfigData::updateConfigEnv(std::string &html, BlenderConfig *&bld_config, BlenderConfig *&_old_bld_config, const std::string &env)
{
    BlenderConfig* tmp_blender_conf = new BlenderConfig();

    if( NULL == tmp_blender_conf )
    {
        html.append("\n no memory , updata config fail!! \n");
        return -1;
    }

    int ret = tmp_blender_conf->loadConfig(_blender_conf->config_file(),  env, _blender_conf->m_g_cluster); 

    if ( ret != 0 )
    {
        html.append("\nload Conf file failed:").append(_blender_conf->config_file() + ", ret:").append(boost::lexical_cast<string>(ret));
        delete tmp_blender_conf;
        return ret;
    }

    if ( _old_bld_config != NULL )
    {
        delete _old_bld_config;
    }

    _old_bld_config = bld_config;
    bld_config = tmp_blender_conf;

    return ret;
}

BlenderConfig *BlenderConfigData::getInstance(const std::string &env, const bool get_default)
{
    if( env_blender_config->find(env) != env_blender_config->end() )
    {
        return (*env_blender_config) [env];
    }
    else if(env == "info")
    {
        return _blender_conf;
    }
    else if(get_default)
    {
        return _blender_conf;        
    }
    return NULL;
}

int BlenderConfigData::setAllBlenderConfig(const std::string &key, const std::string &value)
{
    if( ! _blender_conf->set(key, value) )
    {
        return -1;
    }

    int array_size = sizeof(m_g_env_config_arr)/sizeof(long);
    for ( int fid = 0; fid < array_size; ++fid )
    {   
        string _env(m_g_env_config_arr[fid]);
        map<string, BlenderConfig*>::iterator env_blender_conf_it = env_blender_config->find(_env);
        map<string, BlenderConfig*>::iterator old_env_blender_conf_it = old_env_blender_config->find(_env);
        if(env_blender_conf_it != env_blender_config->end() && old_env_blender_conf_it != old_env_blender_config->end() )
        {
            
            env_blender_conf_it->second->set(key,value);
        }
    }

    return 0;
}


int BlenderConfigData::setOthersConfig(const std::string &key, const std::string &value)
{
    if ( key == "ump_report" )
    {
        if ( value == "on" )
        {
            ump_report::report_status( 1 );
        }
        else
        {
            ump_report::report_status( 0 );
        }
    }
    else if ( key == "ump2_report" )
    {
        if ( value == "on" )
        {
            JDSZ_SET_UMP2_REPORT_ON(true);
        }
        else
        {
            JDSZ_SET_UMP2_REPORT_ON(false);
        }
    }
    else if ( key == "promotionkey_cache_limit_size" )
    {
        LocalCache::instance()->resetCapacity(_blender_conf->m_g_promotionkey_cache_limit_size);
    }
    else {
        return false;
    }
    return true;
}


std::string BlenderConfigData::othersInfo()
{
    std::stringstream ss;
    ss << "localcache.capacity="<<LocalCache::instance()->capacity()<< std::endl;
    ss << "localcache.size="<<LocalCache::instance()->size()<< std::endl;
    if ( ump_report::report_status() == 1 )
    {
        ss << "ops_state.ump_report=on" << std::endl;
    }
    else
    {
        ss << "ops_state.ump_report=off" << std::endl;
    }
    if ( JDSZ_GET_UMP2_REPORT == true )
    {
        ss << "ops_state.ump2_report=on" << std::endl;
    }
    else
    {
        ss << "ops_state.ump2_report=off" << std::endl;
    }

    return ss.str();
}
