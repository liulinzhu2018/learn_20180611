#include "hotdata_manager.h"
#include "scene_artc_strategy.h"
#include "str_util.h"
using namespace blender;
using namespace std;



bool isScene(int type)
{
	return type < ARTICLEADD;
}

bool isArticle(int type)
{
	return type > ARTICLEADD;
}

bool ObjectCmp(const sortInsertObject& a, const sortInsertObject& b)//降序排序  
{  
    return a.weight > b.weight;  
} 

bool cmpByWeight(const pair<int, int>& a, const pair<int, int>& b)
{
	return a.second > b.second;
}

sceneArtcStrategy::sceneArtcStrategy():_cid3_sort(NULL),_old_cid3_sort(NULL)
{
	_cid3_sort = new std::map<int, std::map<int,int> >();
}

sceneArtcStrategy::~sceneArtcStrategy()
{
	if(NULL != _old_cid3_sort)
	{
		delete _old_cid3_sort;
	}
}

sceneArtcStrategy* sceneArtcStrategy::getInstance()
{
    static sceneArtcStrategy* _instance = NULL; 
    if( NULL == _instance )
    {
        _instance = new sceneArtcStrategy();
    }

    return _instance;
}

HOTDATA_REGDATA(sceneArtcStrategy, "reload_insert");

int sceneArtcStrategy::init()
{	
	std::map<int, std::map<int,int> >* tmp_map = NULL;
	
	string html;
	int ret = loadSortInfo(html, tmp_map);
	if(0 != ret)
	{
		return ret;
	}

	_old_cid3_sort = _cid3_sort;
	_cid3_sort = tmp_map;
    HotDataBase::update(html);
	return 0;
}

int sceneArtcStrategy::info(std::string &html)
{	
	std::map<int, std::map<int,int> >* tmp_cid3 = _cid3_sort;

	html.append("cid3 --- insert sort\n");
	
	std::map<int, std::map<int,int> >::iterator cid3_it = tmp_cid3->begin();
	
	for( ; cid3_it != tmp_cid3->end(); cid3_it++ )
	{	
		html.append( boost::lexical_cast<string>(cid3_it->first) + ":\t" );
		vector< pair<int, int> > sort_weights(cid3_it->second.begin(), cid3_it->second.end() );
		sort( sort_weights.begin(), sort_weights.end(), cmpByWeight);
		for(size_t i = 0; i < sort_weights.size(); i++)
		{
			if( isScene(sort_weights[i].first) )
			{
				html.append( "scene\t" + boost::lexical_cast<string>( sort_weights[i].first ) + "\t");
			}

			if( isArticle(sort_weights[i].first) )
			{
				html.append( "article\t" + boost::lexical_cast<string>( sort_weights[i].first-ARTICLEADD ) + "\t" );
			}
		}
		html.append("\n");
	}


	return 0;
}

int sceneArtcStrategy::update(std::string &html)
{
	std::map<int, std::map<int,int> >* tmp_map = NULL;
	int ret = loadSortInfo(html, tmp_map);

    if( 0 != ret )
    {
        return ret;
    }

	if( NULL != _old_cid3_sort )
	{
		delete _old_cid3_sort;
	}

	_old_cid3_sort = _cid3_sort;
	_cid3_sort = tmp_map;

    HotDataBase::update(html);
	return 0;
}

int sceneArtcStrategy::loadSortInfo(std::string &html, std::map<int, std::map<int,int> >*& tmp_map)
{   
	tmp_map = new std::map<int, std::map<int,int> >();

	if( NULL == tmp_map )
	{
		return -1;
	}

	std::ifstream fin;
    fin.open(_blender_conf->m_g_insert_sort_info_file.c_str());
	
	if ( !fin )
    {
        html.append("\n !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!open insert_sort_info_file failed: ");
        html.append(_blender_conf->m_g_insert_sort_info_file);
        html.append("\n");
        delete tmp_map;
        return -1;
    }
    
    string line;
    string gbk_key;
    while( !fin.eof() )   
    {
        std::getline(fin, line);
        if ( !line.empty() )
        {
            if('#' == line[0])
            {
                continue;
            }

            vector<string> sort_vec;
            StrUtil::split(line, "\t", sort_vec);

            int cid3 = 0;
            std::map<int,int> type2weight_map;
            if(sort_vec.size() >= 5)//前三列为高相关分类id,文件格式 cid1 cid2 cid3 scene 1 article 1 当cid为0时，代表默认排序
            {          	
            	try
        		{
            		cid3 = boost::lexical_cast<int>(sort_vec[2]);
        		}
        		catch(...){
        			continue;
        		}
            	
                if(cid3 <= 0)
                {
                    continue;
                }
        		//排在前面的类型，权值比较高，向左依次递减，用于穿插排序用
            	int now_weight = (sort_vec.size() - 3) / 2; 
            	for(size_t i = 3; i+1 < sort_vec.size(); i += 2)
            	{
            		int type = 0;

            		try
        			{
            			type = boost::lexical_cast<int>(sort_vec[i+1]);
        			}
        			catch(...){
        				html.append("illegal int" + sort_vec[i+1] + "\n");
        				continue;
        			}

            		if(sort_vec[i] == ARTICLESTR)
            		{
            			type += ARTICLEADD;
            			type2weight_map.insert(std::make_pair<int,int>(type, now_weight) );
            		}
            		else if(sort_vec[i] == SCENESTR)
            		{
            			type2weight_map.insert(std::make_pair<int,int>(type, now_weight) );
            		}
                    else
                    {
            			html.append("illegal type " + sort_vec[i] + "\n");
            		}
            		now_weight--;
            	}
            	tmp_map->insert(std::make_pair<int, std::map<int,int> >(cid3, type2weight_map) );
            }
            else
            {
            	html.append("illegal line " + line + "\n");
            	continue;
            }
        }
    }
    fin.close();
    html.append("insert_sort_info_file load success!!!!!!!!! \n");

	return 0;
}

int sceneArtcStrategy::packInsert(Json::Value& insertObject, BlenderAnalysisData *_analysisData)
{
	std::vector<sortInsertObject> objectVector;
	std::map<int, std::map<int,int> >* tmp_sort = _cid3_sort;

	std::map<int, std::map<int,int> >::iterator wgit = tmp_sort->end();

	if( _analysisData->query()->_qp_result()._hc_cid3s_size() > 0 )
	{
		int cid3 = _analysisData->query()->_qp_result()._hc_cid3s(0);
		wgit = tmp_sort->find(cid3);
		// if( wgit == tmp_sort->end() )
		// {
		// 	wgit = tmp_sort->find(0);//获取默认排序规则 
		// }
	}
	// else
	// {
	// 	wgit = tmp_sort->find(0);//获取默认排序规则 	
	// }

	std::map<int,int>* weight_map = NULL;
	if( wgit != tmp_sort->end() )
	{
		weight_map = &(wgit->second);
	}
    else
    {
        weight_map = &(_blender_conf->m_g_default_insert_weight);
    }


	if( 0 != _analysisData->m_scene2_insert_json.size() )
	{
		ParseScene2InsertJson(objectVector, _analysisData, _analysisData->m_scene2_insert_json , weight_map);
	}

	if( !_analysisData->m_artc_daren_insert_result_json.empty() )
	{
		ParseArtcDarenJson(objectVector, _analysisData, _analysisData->m_artc_daren_insert_result_json , weight_map);
	}

	std::stable_sort(objectVector.begin(), objectVector.end(), ObjectCmp);//根据权值排序

	for(size_t idx = 0; idx < objectVector.size(); idx++)//下发全部穿插
	{
		insertObject.append(objectVector[ idx ].insertObject);
	}

    return 0;
}
int sceneArtcStrategy::ParseArtcDarenJson(std::vector<sortInsertObject> &object_vector, BlenderAnalysisData *_analysisData, const std::string &json_str, const std::map<int,int>* weight_map)
{
    size_t total_count = 0;

    Json::Reader jreader;
    sortInsertObject sort_object;	
    Json::Value  result_json;
    if ( jreader.parse(json_str, result_json) )
    {
    	if ( result_json.isMember("Head") 
            && result_json["Head"].isMember("Summary")
            && result_json["Head"]["Summary"].isMember("ResultCount")
            && result_json["Head"]["Summary"]["ResultCount"].isString() )
        {
        	try
            {
                total_count = boost::lexical_cast<int>(result_json["Head"]["Summary"]["ResultCount"].asString());
            }catch(...)
            {
                total_count = 0;
                return 0;
            }
        }

        if ( result_json.isMember("Paragraph") && result_json["Paragraph"].size() >= 0 )
        {
        	size_t _result_size = result_json["Paragraph"].size();
            if ( _result_size < total_count )
            {
                total_count = _result_size;
            }
        

        	for ( size_t i = 0; i < total_count; i++ )
        	{
        		int type = ARTICLE_DAREN;

                if( _blender_conf->m_g_artc_limit_type.find(type) == _blender_conf->m_g_artc_limit_type.end() )
                {
                    _analysisData->m_artc_daren_insert_info = "cfg: already get artc_daren but not in config 's type_set";
                    continue;
                }

        		if(NULL != weight_map)
        		{
        			std::map<int,int>::const_iterator itw = weight_map->find(type);
        			if( itw != weight_map->end() )
        			{
        				sort_object.weight = itw->second;
        			}
        			else
        			{
        				sort_object.weight = 0;
        			}
        		}
        		else
        		{
        			sort_object.weight = 0;
        		}

        		sort_object.insertObject = result_json["Paragraph"][i];
        		object_vector.push_back(sort_object);   	
        	}
    	}

    }
    else
    {
        BLD_ERROR(_analysisData->logStream(), "parse artc_insert_result_json fialed:"<< json_str);
        return 0;
    }
    return total_count;
}

int sceneArtcStrategy::ParseScene2InsertJson(std::vector<sortInsertObject> &object_vector, BlenderAnalysisData *_analysisData, const std::map<std::string, std::string> &scene2_insert_json, const std::map<int,int>* weight_map)
{
    size_t total_count = 0;

    Json::Reader jreader;

    std::map<std::string, std::string>::const_iterator scene2_it = scene2_insert_json.begin();
    BlenderConfig *tmp_bld_conf = _blender_conf;
    for(; scene2_it != scene2_insert_json.end(); scene2_it++)
    {
    	sortInsertObject sort_object;
    	Json::Value  &result_json = sort_object.insertObject;
        if ( jreader.parse(scene2_it->second, result_json) && !result_json.isNull() && result_json.isObject()
            && result_json.isMember("type") && result_json["type"].isString() && (result_json["type"].asString() == "scene") )
        {
            bool normal_json = true;
            for ( size_t i = 0; i < tmp_bld_conf->m_g_scene2_insert_checkfield_vec.size(); i++ )
            {
                if ( !result_json.isMember(tmp_bld_conf->m_g_scene2_insert_checkfield_vec[i]) )
                {
                    BLD_ERROR(_analysisData->logStream(), "parse scene_insert_json no must field:"<< tmp_bld_conf->m_g_scene2_insert_checkfield_vec[i] << " json:"<<scene2_it->second);
                    normal_json = false;
                    break;
                }
            }

           	//拼接前后缀
            if( _analysisData->m_qp_is_centerproduct_query )
            {
            	if ( result_json.isMember("mainTitle") && result_json["mainTitle"].isString() 
                    && result_json.isMember("mainTitlePrefix") && result_json["mainTitlePrefix"].isString()
                    && result_json.isMember("mainTitleSuffix") && result_json["mainTitleSuffix"].isString() )
            	{
            		result_json["mainTitle"] = result_json["mainTitlePrefix"].asString() + _analysisData->m_qp_centerproduct_word + result_json["mainTitleSuffix"].asString();
            	}
            }

            //url encode
            if(_analysisData->m_enc_url_gbk)
            {
            	for ( size_t i = 0; i < tmp_bld_conf->m_g_scene2_encode_field_vec.size(); i++ )
            	{
            		if ( result_json.isMember(tmp_bld_conf->m_g_scene2_encode_field_vec[i]) )
            		{
            			string tmp;
            			utils::urlEncode(result_json[tmp_bld_conf->m_g_scene2_encode_field_vec[i]].asString(), tmp);
            			result_json[tmp_bld_conf->m_g_scene2_encode_field_vec[i]] = tmp;
            		}
            	}
            }

            if (normal_json)
            {
                int type = 0;
                if( result_json.isMember("sceneType") && result_json["sceneType"].isString() )
                {
                	try{
                		type = boost::lexical_cast<int> (result_json["sceneType"].asString() );
                	}
                	catch(...)
                	{
                		type = 0;
                	}
                }

                if( tmp_bld_conf->m_g_scene_limit_type.find(type) == tmp_bld_conf->m_g_scene_limit_type.end() )
                {
                    _analysisData->m_scene2_insert_info = "cfg: already get scene but not in config 's type_set";
                    continue;
                }

                if( NULL != weight_map )
        		{
        			std::map<int,int>::const_iterator itw = weight_map->find(type);
        			if( itw != weight_map->end() )
        			{
        				sort_object.weight = itw->second;
        			}
        			else
        			{
        				sort_object.weight = 0;
        			}
        		}
        		else
        		{
        			sort_object.weight = 0;
        		}
        		object_vector.push_back(sort_object);
                total_count++;
            }
        }
    }
    return total_count;
}
