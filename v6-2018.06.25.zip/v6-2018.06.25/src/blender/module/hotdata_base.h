#ifndef __HOTDATA_BASE_H__
#define __HOTDATA_BASE_H__

#include <fstream> 
#include <string>
//动态加载文件有可能初始化为NULL，使用前一定要检查NULL，特别在info和自定义函数中
#include "bld_global.h"
namespace blender
{

class HotDataBase
{
public:
	HotDataBase():_update_time(0){};
	virtual ~HotDataBase(){};
	virtual int init() = 0;
	virtual int info(std::string &html) = 0;
	virtual int update(std::string &html)
	{
		_update_time = time(NULL);
		return 0;
	}

	time_t getUpdateTime()
	{
		return _update_time;
	}
	
	string getUpdateTimeStr()
	{
		char tm_str[100] = {0};
    	struct tm *_tm = localtime(&_update_time);
    	strftime(tm_str, 100, "%Y-%m-%d %H:%M:%S", _tm);

    	string update_info;
    	update_info.append("update_time:   " + string(tm_str) );
    	return update_info;
	}

protected:
	time_t _update_time;
};
}
#endif