#include "hotdata_manager.h"
#include "client2env_data.h"
#include "blender_config.h"
using namespace blender;
using namespace std;

Client2EnvData::Client2EnvData():
    _site_client_map(NULL),_old_site_client_map(NULL),
    _env_client_map(NULL),_old_env_client_map(NULL),
    _ump_key_caller_map(NULL),_old_ump_key_caller_map(NULL)
{
}

Client2EnvData::~Client2EnvData()
{
    if( NULL != _old_site_client_map )
    {
        delete _old_site_client_map;
        _old_site_client_map = NULL;
    }
	 
    if( NULL != _old_env_client_map )
    {
        delete _old_env_client_map;
        _old_env_client_map = NULL;
    }

    if( NULL != _old_ump_key_caller_map )
    {
        delete _old_ump_key_caller_map;
        _old_ump_key_caller_map = NULL;
    }
}

int Client2EnvData::init()
{
	string html;
	int ret = update(html);
	return ret;
}

int Client2EnvData::info(std::string &html)
{

	html.append("client site:\n");
    
    html.append("conf.site_client=\n");
    std::map<std::string, int>::const_iterator scit = _site_client_map->begin();
    for ( ; scit != _site_client_map->end(); scit++ )
    {
        string i_site;
        try{
           i_site = boost::lexical_cast<string>(scit->second);
        }catch(...){

        }
        html.append(scit->first + " ----- " + i_site + "\n");
        // ss << scit->first << ":" << scit->second << ",";
    }

	html.append("\nclient env:\n");
    map<string, string>::const_iterator ecit = _env_client_map->begin();
    for ( ; ecit != _env_client_map->end(); ecit++ )
    {
        html.append(ecit->first + " ----- " + ecit->second + "\n");
    }

	html.append("\nclient ump_key:\n");
    
    map<string, string>::const_iterator ukit = _ump_key_caller_map->begin();
    for ( ; ukit != _ump_key_caller_map->end(); ukit++ )
    {
        html.append(ukit->first + " ----- " + ukit->second + "\n");
    }
	return 0;
}

int Client2EnvData::update(std::string &html)
{
    std::map<std::string, int>* tmp_site_client_map = new std::map<std::string, int>();
    std::map<std::string, std::string>* tmp_env_client_map = new std::map<std::string, std::string>();
	std::map<std::string, std::string>* tmp_ump_key_caller_map = new std::map<std::string, std::string>();

	int ret = loadClientXml(_blender_conf->m_g_client_xml, tmp_site_client_map, tmp_env_client_map, tmp_ump_key_caller_map, html);
	
	if( ret != 0 )
	{  
        if( NULL != _site_client_map && NULL != _env_client_map && NULL != _ump_key_caller_map)
        {
		  delete tmp_site_client_map;
		  delete tmp_env_client_map;
		  delete tmp_ump_key_caller_map;
		  return -1;
	    }
    }

    if( NULL != _old_site_client_map )
    {
        delete _old_site_client_map;
        _old_site_client_map = NULL;
    }
	 
    if( NULL != _old_env_client_map )
    {
        delete _old_env_client_map;
        _old_env_client_map = NULL;
    }

    if( NULL != _old_ump_key_caller_map )
    {
        delete _old_ump_key_caller_map;
        _old_ump_key_caller_map = NULL;
    }

	_old_site_client_map = _site_client_map;
    _site_client_map = tmp_site_client_map;

	_old_env_client_map = _env_client_map;
    _env_client_map = tmp_env_client_map;

   	_old_ump_key_caller_map = _ump_key_caller_map;
    _ump_key_caller_map = tmp_ump_key_caller_map;

    HotDataBase::update(html);
    return 0;
}

HOTDATA_REGDATA(Client2EnvData, "reload_client");
Client2EnvData *Client2EnvData::getInstance()
{
    static Client2EnvData* _instance = NULL; 
    if( NULL == _instance )
    {
        _instance = new Client2EnvData();
    }

    return _instance;
}

int Client2EnvData::site(const std::string &client) const
{
    std::map<std::string, int>* temp_site_client_map = _site_client_map;
    std::map<std::string, int>::iterator it = temp_site_client_map->find(client);
    if ( it != temp_site_client_map->end() )
    {
        return it->second;
    }
    return SITE_MAIN;
}

std::string Client2EnvData::caller_key(const std::string &client) const
{
    std::map<std::string, std::string>* temp_ump_key_caller_map = _ump_key_caller_map;
    std::map<std::string, std::string>::iterator it = temp_ump_key_caller_map->find(client);
    if ( it != temp_ump_key_caller_map->end() )
    {
        return it->second;
    }
    if ( !client.empty() )
    {
        std::string caller = "psearch.caller.";
        caller.append(client);
        return caller;
    }
    return "psearch.caller.unkown";
}

bool Client2EnvData::key_configed(const std::string &client) const
{
    std::map<std::string, std::string>* temp_ump_key_caller_map = _ump_key_caller_map;
    std::map<std::string, std::string>::iterator it = temp_ump_key_caller_map->find(client);
    if ( it != temp_ump_key_caller_map->end() )
    {
        return true;
    }
    return false;
}

std::string Client2EnvData::caller_env(const std::string &client) const
{
    std::map<std::string, std::string>* temp_env_client_map = _env_client_map;
    std::map<std::string, std::string>::iterator it = temp_env_client_map->find( client );
    if( it != temp_env_client_map->end() )
    {
        return it->second;
    }else{
        return "default";
    }
}
int Client2EnvData::loadClientXml(const std::string &conf, 
	std::map<std::string, int>* site_client_map, 
	std::map<std::string, std::string>* env_client_map, 
	std::map<std::string, std::string>* ump_key_caller_map,
	std::string &html)
{
    TiXmlDocument doc(conf);
    if (!doc.LoadFile())
    {
        html.append("can not open client_xml file \n");
        return -1;
    }


    const TiXmlElement *pRoot = doc.RootElement();
    if (NULL == pRoot)
    {
        html.append("the content of client.xml is wrong\n");
        return -2;
    }

    const TiXmlElement* client = pRoot->FirstChildElement();

    for(; NULL != client; client = client->NextSiblingElement())
    {
        if (0 == strcmp(client->Value(), "client"))
        {
            const TiXmlAttribute* client_id_attr = client->FirstAttribute();
            std::string client_id;
            if (0 == strcmp(client_id_attr->Name(), "id"))
            {
                client_id = client_id_attr->Value();
                
                if( client_id.length() == 0)
                {
                    continue;
                }
            }
            else{
                continue;
            }
                         
            const TiXmlElement* info = client->FirstChildElement();
            
            if (0 == strcmp(info->Value(), "info"))
            {
                const TiXmlAttribute* pAttr = info->FirstAttribute();

                while (NULL != pAttr)
                {
                    if (0 == strcmp(pAttr->Name(), "env"))
                    {
                        if( strlen(pAttr->Value() ) > 0  )
                        {
                            env_client_map->insert( std::make_pair<std::string, std::string>(client_id, string(pAttr->Value()) ) );
                        }
                    } 
                    else if (0 == strcmp(pAttr->Name(), "site"))
                    {
                        if( strlen(pAttr->Value() ) > 0  )
                        {
                            int siteid;
                            try{
                                siteid = boost::lexical_cast<int>(pAttr->Value());
                            }
                            catch(...){
                                siteid = 1;//读错了为什么site?
                            }

                            if ( SITE_BEGIN < siteid )
                            {
                                site_client_map->insert(std::make_pair<std::string,int>(client_id, siteid));
                            }
                        }
                    } 
                    else if(0 == strcmp(pAttr->Name(), "name"))
                    {
                        if( strlen(pAttr->Value() ) > 0 )
                        {
                            ump_key_caller_map->insert(std::make_pair<std::string, std::string>(client_id, string(pAttr->Value()) ) );
                        }
                    }
                    
                    pAttr = pAttr->Next();   
                }
            }

        }
    }
    html.append("\n reload client.xml success!!!! \n");
    return 0;
}