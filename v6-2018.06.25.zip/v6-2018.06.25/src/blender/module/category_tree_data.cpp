#include "hotdata_manager.h"
#include "category_tree_data.h"
#include "blender_config.h"
using namespace std;
using namespace blender;


CategoryTreeData::CategoryTreeData():_cat_tree(NULL),_old_cat_tree(NULL)
{

}

CategoryTreeData::~CategoryTreeData()
{
	if( NULL != _old_cat_tree )
	{
		delete _old_cat_tree;
		_old_cat_tree = NULL;
	}
}
	
CategoryTreeData *CategoryTreeData::getInstance()
{
    static CategoryTreeData* _instance = NULL; 
	if( NULL == _instance )
    {
        _instance = new CategoryTreeData();
    }

    return _instance;
}

HOTDATA_REGDATA(CategoryTreeData, "reload_category");
int CategoryTreeData::init()
{   
	string html;
	_cat_tree = new jd_search_merger::CategoryTree();
    int ret = load_category_tree(_cat_tree, html);
    if (ret != 0)
    {
        std::cout<<"init categoryTree failed!!!"<<std::endl;
    }else
    {
        HotDataBase::update(html);
	}
    return ret;
}	

int CategoryTreeData::info(std::string &html)
{
    if( NULL == _cat_tree )
    {
        html.append("\n _cat_tree is NULL!!! \n\n");
        return -1;
    }

    if( _cat_tree->PrintInfo(html) != 0 )
    {
        html.append("\n _cat_tree is NULL!!! \n\n");
        return -1;
    }    
    html.append("\n" + HotDataBase::getUpdateTimeStr() );
	return 0;
}	

int CategoryTreeData::update(std::string &html)
{
    jd_search_merger::CategoryTree* cat_tree = new jd_search_merger::CategoryTree();
    int ret = load_category_tree(cat_tree, html);
    if ( (ret != 0) || (cat_tree->Empty()))
    {
        html.append("\nload category failed:").append(boost::lexical_cast<string>(ret));
        delete cat_tree;
        return ret;
    }

    if (_old_cat_tree != NULL)
    {
        delete _old_cat_tree;
    }

    _old_cat_tree = _cat_tree;
    _cat_tree = cat_tree;
    
    HotDataBase::update(html);
    return ret;
}	

int CategoryTreeData::load_category_tree(jd_search_merger::CategoryTree* cat_tree, std::string &html)
{
    string catfile = BlenderConfig::getInstance()->m_g_category_file_update;
    if (catfile.empty())
    {
        html.append("\nload category file failed:").append(catfile);
        return -1;
    }

    if (cat_tree->LoadTxtFile(catfile) == false)
    {
        html.append("\nbuild cate tree failed:");
        return -2;
    }
    html.append("\nbuild cate tree success!\n");
    return 0;
}
