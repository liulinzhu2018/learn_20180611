#ifndef __CATEGORY_TREE_DATA_H__
#define __CATEGORY_TREE_DATA_H__

#include "hotdata_base.h"
#include "blender_config.h"
#include "category_tree.h"
namespace blender
{
	
class CategoryTreeData:public HotDataBase
{
public:
	~CategoryTreeData();
	int init();
	int info(std::string &html);
	int update(std::string &html);
	int load_category_tree(jd_search_merger::CategoryTree* cat_tree, std::string &html);
	jd_search_merger::CategoryTree* _cat_tree; 

	static CategoryTreeData *getInstance();
private:
	CategoryTreeData();
	jd_search_merger::CategoryTree* _old_cat_tree; 
};
}
#endif
