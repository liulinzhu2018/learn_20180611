#include "category_tree.h"
#include <stdio.h>
#include<boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <glog/logging.h>
char* skipWhitespace(char* p)
{
    while( (unsigned char)*p <= ' ' && (unsigned char)*p != '\0' )
        p++;
    return p;
}

namespace jd_search_merger
{
    CategoryTree::CategoryTree():m_is_build(false)
    {
    }

    CategoryTree::~CategoryTree()
    {
        if (m_is_build == true) {
            FreeCategoryTree();
            //cout << "cate free" << endl;
        }
    }

    bool CategoryTree::LoadTxtFile(const string &CategoryFile)
    {
        unordered_map<int,string> cid1Map;
        unordered_map<int,vector<pair<int, string> > > cids;
        FILE *fp = fopen(CategoryFile.c_str(), "r");
        if (fp == NULL){
            LOG(ERROR)<<"open file error: "<<CategoryFile<<"\n";
            return false;
        }

        char *line_read = NULL;
        size_t line_read_len = 0;
        ssize_t read_size = -1;

        while ((read_size = getline(&line_read, &line_read_len, fp)) != -1)
        {
            if (read_size == 0)
                continue;

            if (line_read[read_size-1] == '\n')
                line_read[--read_size] = '\0';

            char* p = skipWhitespace(line_read);
            if( *p == '\0' )
            {
                continue;
            }
            else if( *p == '!' || *p == '#' )   // 注释
            {
                continue;
            }        

            vector<string> tmp;
            boost::split(tmp, p, boost::is_any_of("\t"));
            if (tmp.size() != 3 && tmp.size() != 2)
            {
                LOG(WARNING)<<line_read<<" is not  suit for the category!";
                continue;
            }

            try
            {
                if(2==tmp.size())
                {//一级分类
                    int cateId = boost::lexical_cast<int>(tmp[0]);
                    cid1Map[cateId] = tmp[1];
                }
                else
                {//二级和三级分类
                    int fatherCateId = boost::lexical_cast<int>(tmp[2]);
                    int cateId = boost::lexical_cast<int>(tmp[0]);
                    string cateName = tmp[1];
                    if(cids.count(fatherCateId)>0)
                    {
                        cids[fatherCateId].push_back(make_pair(cateId, cateName));
                    }
                    else
                    {
                        vector<pair<int, string> > cidsVec;
                        cidsVec.push_back(make_pair(cateId, cateName));
                        cids[fatherCateId] = cidsVec;
                    }
                }
            }
            catch(...)
            {
                LOG(ERROR)<<"Error: invalid brandmodel line("<<line_read<<"!";
                continue;
            }
        }
        if (line_read!=NULL)
        {
            free(line_read);
            line_read = NULL;
        }
        fclose(fp);

        return BuildCategoryTree(cid1Map,cids);
    }

    bool CategoryTree::BuildCategoryTree(unordered_map<int,string>& cid1Map, unordered_map<int,vector<pair<int, string> > >& cids)
    {
        if (m_is_build == true)
        {
            return true;
        }

        if (cid1Map.empty())
            return false;

        if (BuildTreeRoot() == false)
        {
            return false;
        }

        if (BuildTree(cid1Map,cids) == false)
        {
            FreeCategoryTree();
            return false;
        }

        m_is_build = true;

        return true;
    }

    bool CategoryTree::BuildTree(unordered_map<int,string>& cid1Map, unordered_map<int,vector<pair<int, string> > >& cids)
    {
        CategoryTreeNode *pCid1node;

        for(unordered_map<int,string>::iterator cid1It=cid1Map.begin(); cid1It!=cid1Map.end(); cid1It++)
        {
            if(!BuildCid1Tree(cid1It->first,cid1It->second))
                return false;
            pCid1node = (*m_root.m_chld_map)[cid1It->first];

            vector<pair<int, string> > cid2Vec = cids[cid1It->first];
            CategoryTreeNode *pCid2node;
            for(vector<pair<int, string> >::iterator cid2It = cid2Vec.begin(); cid2It!= cid2Vec.end(); cid2It++)
            {
                if(!BuildCid2Tree(pCid1node, cid2It->first, cid2It->second))
                    return false;

                pCid2node = (*(pCid1node->m_chld_map))[cid2It->first];
                vector<pair<int, string> > cateidVec = cids[cid2It->first];
                for(vector<pair<int, string> >::iterator cateidIt = cateidVec.begin(); cateidIt!= cateidVec.end(); cateidIt++)
                {
                    BuildCateidTree(pCid2node, cateidIt->first, cateidIt->second);
                }
            }
        }

        return true;
    }
    bool CategoryTree::BuildCid1Tree(const int& cid1, string& cid1Name)
    {
        if (m_root.m_chld_map->find(cid1) == m_root.m_chld_map->end())
        {
            if (m_cateid_map.find(cid1) == m_cateid_map.end())
            {
                CategoryTreeNode *pnode = new CategoryTreeNode;
                if (pnode == NULL)
                    return false;
                pnode->m_cateid = cid1;
                pnode->m_catename = cid1Name;
                pnode->m_father_node = &m_root;
                pnode->m_chld_map = new CategoryTreeNode::Tmap;
                if (pnode->m_chld_map == NULL)
                {
                    delete pnode;
                    return false;
                }

                (*m_root.m_chld_map)[cid1] = pnode;
                m_cateid_map[cid1] = pnode;
                m_name_fieldId_map[cid1Name] = cid1;
            }
        }
        return true;
    }

    bool CategoryTree::BuildCid2Tree(CategoryTreeNode *pfnode, int& cid2, string& cid2Name)
    {
        if (pfnode->m_chld_map->find(cid2) == pfnode->m_chld_map->end())
        {
            if (m_cateid_map.find(cid2) == m_cateid_map.end())
            {
                CategoryTreeNode *pnode = new CategoryTreeNode;
                if (pnode == NULL)
                    return false;
                pnode->m_cateid = cid2;
                pnode->m_catename = cid2Name;
                pnode->m_father_node = pfnode;
                pnode->m_chld_map = new CategoryTreeNode::Tmap;
                if (pnode->m_chld_map == NULL)
                {
                    delete pnode;
                    return false;
                }

                (*(pfnode->m_chld_map))[cid2] = pnode;
                m_cateid_map[cid2] = pnode;
                m_name_fieldId_map[cid2Name] = cid2;
            }
        }
        return true;
    }

    bool CategoryTree::BuildCateidTree(CategoryTreeNode *pfnode, int& cateid, string& catename)
    {
        if (pfnode->m_chld_map->find(cateid) == pfnode->m_chld_map->end())
        {
            if (m_cateid_map.find(cateid) == m_cateid_map.end())
            {
                CategoryTreeNode *pnode = new CategoryTreeNode;
                if (pnode == NULL)
                    return false;
                pnode->m_cateid = cateid;
                pnode->m_catename = catename;
                pnode->m_father_node = pfnode;
                pnode->m_chld_map = NULL;

                (*(pfnode->m_chld_map))[cateid] = pnode;
                m_cateid_map[cateid] = pnode;
                m_name_fieldId_map[catename] = cateid;
            }
        }
        return true;
    }

    void CategoryTree::FreeCategoryTree()
    {
        CategoryTreeNode::Tmap **pnode = new CategoryTreeNode::Tmap *[m_cateid_map.size()];
        int i = 0;

        CategoryTreeNode::Tmap::iterator itor = m_cateid_map.begin();
        while (itor != m_cateid_map.end()) {
            pnode[i++] = itor->second->m_chld_map;
            delete itor->second;

            itor++;
        }

        m_cateid_map.clear();

        while (--i >= 0) {
            if (pnode[i] != NULL)
                delete pnode[i];
        }

        delete [] pnode;

        FreeTreeRoot();
    }

    void CategoryTree::FreeTreeRoot()
    {
        if (m_root.m_chld_map != NULL) {
            delete m_root.m_chld_map;
            m_root.m_chld_map = NULL;
        }
    }

    bool CategoryTree::BuildTreeRoot()
    {
        m_root.m_chld_map = new CategoryTreeNode::Tmap;
        if (m_root.m_chld_map == NULL)
        {
            return false;
        }
        m_root.m_father_node = NULL;
        m_root.m_cateid = -1;
        m_root.m_catename.clear();

        return true;
    }

    bool CategoryTree::IsBuild()
    {
        return (m_is_build && m_root.m_chld_map != NULL);
    }

    bool CategoryTree::BelongTo(int catid, int fcatid)
    {
        if (IsBuild())
        {
            if (m_cateid_map.find(catid) != m_cateid_map.end() &&
                    m_cateid_map.find(fcatid) != m_cateid_map.end())
            {
                CategoryTreeNode *pnode = m_cateid_map[catid];
                if (pnode && pnode->m_cateid == catid)
                {
                    while (pnode && IsValidNode(pnode))
                    {
                        if (pnode->m_cateid == fcatid)
                        {
                            return true;
                        }
                        else
                        {
                            pnode = pnode->m_father_node;
                        }
                    }
                }
            }

        }

        return false;
    }

    bool CategoryTree::GetSubSet(int catid, vector<int> &retset)
    {
        if (IsBuild())
        {
            if (m_cateid_map.find(catid) != m_cateid_map.end())
            {
                CategoryTreeNode *pnode = m_cateid_map[catid];
                if (pnode && pnode->m_cateid == catid && pnode->m_chld_map != NULL)
                {
                    CategoryTreeNode::Tmap::iterator itor = pnode->m_chld_map->begin();
                    while (itor != pnode->m_chld_map->end())
                    {
                        retset.push_back(itor->second->m_cateid);
                        itor++;
                    }

                    if (!retset.empty())
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    //get all the sub leaves from the categoryid setted
    void CategoryTree::GetAllLeaves(int categoryId, std::vector<int32_t>& subCategories)
    {
        if (IsBuild())
        {
            if (m_cateid_map.find(categoryId) != m_cateid_map.end())
            {
                CategoryTreeNode *pnode = m_cateid_map[categoryId];
                if (pnode && pnode->m_cateid == categoryId)
                {
                    if (pnode->m_chld_map != NULL)
                    {
                        CategoryTreeNode::Tmap::iterator itor = pnode->m_chld_map->begin();
                        while (itor != pnode->m_chld_map->end())
                        {
                            int32_t category_id = itor->first;
                            int32_t current_level = GetCateLevel(category_id); 
                            //here we check the level if it is not category three
                            if (current_level && current_level < 3)
                            {
                                GetAllLeaves(category_id, subCategories);
                            }
                            else if (current_level == 3)
                            {
                                subCategories.push_back(category_id);
                            }
                            itor++;
                        }
                    }
                    else
                    {
                        subCategories.push_back(pnode->m_cateid);
                    }
                }
                else
                {
                    LOG(ERROR)<<"catid is not equal! value is "<<boost::lexical_cast<std::string>(categoryId);
                }
            }
            else
            {
                LOG(ERROR)<<"node can not find in tree "<<boost::lexical_cast<string>(categoryId);
            }
        }
        else
        {
            LOG(ERROR)<<"category tree is not built yet!";
            return;
        }
        return;
    }

    bool CategoryTree::IsValidNode(CategoryTreeNode * pnode)
    {
        return (pnode && pnode != &m_root);
    }

    int CategoryTree::ParentCatID(int catid)
    {
        if (IsBuild())
        {
            if (m_cateid_map.find(catid) != m_cateid_map.end())
            {
                CategoryTreeNode *pnode = m_cateid_map[catid];
                if (pnode && pnode->m_cateid == catid)
                {
                    CategoryTreeNode *pfnode = pnode->m_father_node;
                    if (pfnode)
                    {
                        if (IsValidNode(pfnode))
                        {
                            return pfnode->m_cateid;
                        }
                        else
                        {
                            return 0;
                        }
                    }
                }
            }
        }

        return -1;
    }

    bool CategoryTree::Name(int catid, string &catname)
    {
        if (IsBuild())
        {
            if (m_cateid_map.find(catid) != m_cateid_map.end())
            {
                CategoryTreeNode *pnode = m_cateid_map[catid];
                if (pnode && pnode->m_cateid == catid)
                {
                    catname = pnode->m_catename;
                    return true;
                }
            }
        }

        catname = "";
        return false;
    }

    bool CategoryTree::GetFieldIdByName(string catname, int& catid)
    {
        if (IsBuild())
        {
            if (m_name_fieldId_map.find(catname) != m_name_fieldId_map.end())
            {
                catid = m_name_fieldId_map[catname];
                return true;
            }
        }

        catid = -1;
        return false;
    }

    bool CategoryTree::ParentName(int catid, string &catname)
    {
        if (IsBuild())
        {
            if (m_cateid_map.find(catid) != m_cateid_map.end())
            {
                CategoryTreeNode *pnode = m_cateid_map[catid];
                if (pnode && pnode->m_cateid == catid)
                {
                    CategoryTreeNode *pfnode = pnode->m_father_node;
                    if (pfnode)
                    {
                        if (IsValidNode(pfnode))
                        {
                            catname = pfnode->m_catename;
                        }
                        else
                        {
                            catname = "";
                        }

                        return true;
                    }
                }
            }
        }

        catname = "";
        return false;
    }

    int CategoryTree::TopCatID(int catid)
    {
        if (IsBuild())
        {
            if (m_cateid_map.find(catid) != m_cateid_map.end())
            {
                CategoryTreeNode *pnode = m_cateid_map[catid];
                if (pnode && pnode->m_cateid == catid)
                {
                    while (pnode && IsValidNode(pnode->m_father_node))
                    {
                        pnode = pnode->m_father_node;
                    }

                    if (pnode && !IsValidNode(pnode->m_father_node))
                    {
                        return pnode->m_cateid;
                    }
                }
            }
        }

        return -1;
    }

    bool CategoryTree::GetParent(int catid, int &pcatid, string &pcatename)
    {
        if (IsBuild())
        {
            if (m_cateid_map.find(catid) != m_cateid_map.end())
            {
                CategoryTreeNode *pnode = m_cateid_map[catid];
                if (pnode && pnode->m_cateid == catid)
                {
                    if (IsValidNode(pnode->m_father_node))
                    {
                        pcatid = pnode->m_father_node->m_cateid;
                        pcatename = pnode->m_father_node->m_catename;

                        return true;
                    }
                }
            }
        }

        return false;
    }

    int CategoryTree::GetCateLevel(int catid)
    {
        //int level = 1;
        int level = 0;

        if (!IsBuild()) {
            return 0; 
        }

        if (m_cateid_map.find(catid) == m_cateid_map.end()) {
            return 0; 
        }

        CategoryTreeNode *pnode = m_cateid_map[catid];

        while (IsValidNode(pnode) && level <= 3) {
            level++;     
            pnode = pnode->m_father_node;
        }

        return level;
    }

    //打印分类树信息   
    int CategoryTree::PrintInfo(string &html)
    {
        //1级
        if ( !IsBuild() )
            return -1;
        CategoryTreeNode::Tmap::iterator cid1_it ;
        for(cid1_it = m_root.m_chld_map->begin(); cid1_it != m_root.m_chld_map->end(); cid1_it++)
        {
            html.append(cid1_it->second->m_catename + " -> " +  boost::lexical_cast<string>(cid1_it->second->m_cateid) + ":\n");
            CategoryTreeNode::Tmap::iterator cid2_it ; 
            CategoryTreeNode::Tmap *cid2_map = cid1_it->second->m_chld_map;
            
            for(cid2_it = cid2_map->begin(); cid2_it != cid2_map->end(); cid2_it++)
            {
                html.append("\t" + cid2_it->second->m_catename + " -> " +  boost::lexical_cast<string>(cid2_it->second->m_cateid) + ":\n");
                CategoryTreeNode::Tmap::iterator cid3_it ; 
                CategoryTreeNode::Tmap *cid3_map = cid2_it->second->m_chld_map;

                for(cid3_it = cid3_map->begin(); cid3_it != cid3_map->end(); cid3_it++)
                {
                    html.append("\t\t" + cid3_it->second->m_catename + " -> " +  boost::lexical_cast<string>(cid3_it->second->m_cateid) + "\n");
                }
            }
        }

        return 0;
    }
}
