#ifndef __NOT_PERSONALKEY_DATA_H__
#define __NOT_PERSONALKEY_DATA_H__
#include "hotdata_base.h"

#include <set>
#include <string>
namespace blender
{

class NotPersonalkeyData :public HotDataBase
{
public:
	~NotPersonalkeyData();

	int init();
	int info(std::string &html);
	int update(std::string &html);
	bool not_personalkey(const std::string &url_key);

	static NotPersonalkeyData *getInstance();
private:
	NotPersonalkeyData();
	std::set<std::string> *_not_personalkey_list;
	std::set<std::string> *_old_not_personalkey_list;

};
}
#endif