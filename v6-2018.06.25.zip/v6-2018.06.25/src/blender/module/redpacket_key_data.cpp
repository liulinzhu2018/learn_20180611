#include "hotdata_manager.h"
#include "redpacket_key_data.h"

#include "global.h"
#include "str_util.h"
#include "blender_config.h"
using namespace std;
using namespace blender;


RedPacketkeyData::RedPacketkeyData():_redpkg_keys(NULL), _old_redpkg_keys(NULL)
{

}

RedPacketkeyData::~RedPacketkeyData()
{
    if(NULL != _old_redpkg_keys)
    {
        delete _old_redpkg_keys;
        _old_redpkg_keys = NULL;
    }
}

RedPacketkeyData *RedPacketkeyData::getInstance()
{
    static RedPacketkeyData *_instance = NULL;
    if( NULL == _instance )
    {
        _instance = new RedPacketkeyData();
    }

    return _instance;
}
HOTDATA_REGDATA(RedPacketkeyData, "reload_redenvelop");
int RedPacketkeyData::init()
{
    string html;
    int ret = update(html);
    return ret;
}   

int RedPacketkeyData::info(std::string &html)
{
    if( NULL == _redpkg_keys )
    {
        html.append("\n _redpkg_keys is NULL!!! \n\n");
        return -1;
    }
    
    std::set<string>::iterator it = _redpkg_keys->begin();
    
    html += "_redpkg_keys in blender :";
    html += "\n";
    for( ; it != _redpkg_keys->end(); it++)
    {
        html += "\n";
        html += *it;
    }

    html.append("\n" + HotDataBase::getUpdateTimeStr() );
    return 0;
}

int RedPacketkeyData::update(std::string &html)
{
   // load new category
    std::set<std::string> *redpkg_keys = new std::set<std::string>();

    bool is_read_ok = false;
    do{
        if ( _blender_conf->m_g_redpackets_keys_file.empty() )
        {
            break;
        }

        std::ifstream fin;
        fin.open(_blender_conf->m_g_redpackets_keys_file.c_str());
        if ( !fin )
        {
            html.append("\n open file failed:");
            html.append(_blender_conf->m_g_redpackets_keys_file);
            break;
        }
        
        string line;
        string key;
        while( !fin.eof() )   
        {         
            std::getline(fin, line);
            std::vector<std::string> vars;
            boost::split(vars, line, boost::is_any_of(" \t\n"));
            if ( vars.size() == 0 )
            {
                continue;
            }

            if ( !clsGlobal::promotion_normalize(vars[0], key) )
            {
                key = line;
            }

            if ( !key.empty() )
            {
                if ( key[0] == '#' )
                {
                    continue;
                }
                html.append(key);
                html.append("\n");
                //printf("%s:%d\n", key.c_str(), key.length());

                redpkg_keys->insert(key);
            }
        }
        fin.close();
        is_read_ok = true;
    }while(0);

    if ( !is_read_ok )
    {
        delete redpkg_keys;
        html.append(" update_red_packets_keys failed!");
        return -1;
    }

    if ( NULL != _old_redpkg_keys )
    {
        delete _old_redpkg_keys;
    }
    _old_redpkg_keys = _redpkg_keys;
    _redpkg_keys = redpkg_keys;

    html.append(" update_red_packets_keys OK:");
    html.append(boost::lexical_cast<std::string>(_redpkg_keys->size()));
    
    HotDataBase::update(html);

    return 0;
}   

bool RedPacketkeyData::is_red_packets_key(const std::string &key )
{
    if ( (NULL == _redpkg_keys) || key.empty() )
    {
        return false;
    }
    
    if ( _redpkg_keys->find(key) != _redpkg_keys->end() )
    {
        return true;
    }

    return false;
}