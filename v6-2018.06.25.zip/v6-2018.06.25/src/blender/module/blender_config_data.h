#ifndef __BLENDER_CONFIG_DATA_H__
#define __BLENDER_CONFIG_DATA_H__
#include "hotdata_base.h"
#include <string>
#include <map>
#include "blender_config.h"

namespace blender
{

class BlenderConfigData: public HotDataBase 
{
public:
	~BlenderConfigData();
	blender::BlenderConfig *_old_blender_conf;

	int init();
	int info(std::string &html);
	int update(std::string &html);
	static BlenderConfigData *getInstance();
	static BlenderConfig *getInstance(const std::string &env, const bool get_default);
	static int setAllBlenderConfig(const std::string &key, const std::string &value);

	static const char* m_g_env_config_arr[];

	static std::map<std::string, BlenderConfig*>* env_blender_config;
	static std::map<std::string, BlenderConfig*>* old_env_blender_config;

	std::string othersInfo();
	int setOthersConfig(const std::string &key, const std::string &value);
private:

	BlenderConfigData();
	int updateConfigEnv(std::string &html, BlenderConfig *&bld_config, BlenderConfig *&_old_bld_config, const std::string &env);
};

}
#endif