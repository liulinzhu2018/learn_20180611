#ifndef _CATEGORY_TREE
#define _CATEGORY_TREE

#include <string>
#include <vector>
#include <boost/unordered_map.hpp>

using boost::unordered_map;
using namespace std;

namespace jd_search_merger
{
    class CategoryTree
    {
        public:
            explicit CategoryTree();
            ~CategoryTree();

            bool LoadTxtFile(const string &CategoryFile);

            virtual bool BelongTo(int catid, int fcatid);
            virtual bool GetSubSet(int catid, vector<int> &retset);

            //get every leaf node which belongs to categoryId -- yanwenbo
            void GetAllLeaves(int categoryId, std::vector<int32_t>& subCategories);
            virtual int  ParentCatID(int catid);
            virtual bool ParentName(int catid, string &catname);
            virtual bool Name(int catid, string &catname);
            virtual bool GetFieldIdByName(string catname, int& catid);
            virtual int TopCatID(int catid);
            virtual int Size() {
                return m_cateid_map.size();
            }
            virtual bool Empty() {
                return m_cateid_map.empty();
            }
            virtual bool GetParent(int catid, int &pcatid, string &pcatename);

            /*
             * 根据catid判断分类所属级别 (1, 2, 3级)
             * 如果输入错误, 或查找失败, 返回0.
             */
            virtual int GetCateLevel(int catid);

            virtual int PrintInfo(string &html);
        private:
            struct CategoryTreeNode
            {
                typedef boost::unordered_map<int, CategoryTreeNode *> Tmap;

                CategoryTreeNode():m_cateid(-1), m_father_node(NULL), m_chld_map(NULL){}
                ~CategoryTreeNode()
                {
                    //cout << m_cateid << endl;
                }

                int m_cateid;
                string m_catename;
                CategoryTreeNode *m_father_node;
                Tmap *m_chld_map;
            };

        private:
            bool BuildCategoryTree(unordered_map<int,string>& cid1Map, unordered_map<int,vector<pair<int, string> > >& cids);
            bool BuildTreeRoot();
            void FreeTreeRoot();
            void FreeCategoryTree();
            bool BuildTree(unordered_map<int,string>& cid1Map, unordered_map<int,vector<pair<int, string> > >& cids);
            bool BuildCid1Tree(const int& cid1, string& cid1Name);
            bool BuildCid2Tree(CategoryTreeNode *pfnode, int& cid2, string& cid2Name);
            bool BuildCateidTree(CategoryTreeNode *pfnode, int& cateid, string& catename);
            bool IsBuild();
            bool IsValidNode(CategoryTreeNode * pnode);

        private:
            bool m_is_build;
            CategoryTreeNode m_root;
            boost::unordered_map<std::string, int> m_name_fieldId_map;
            boost::unordered_map<int, CategoryTreeNode *> m_cateid_map;
    };
}

#endif

