#include "hotdata_manager.h"
#include "not_personalkey_data.h"

#include "str_util.h"
#include "blender_config.h"
#include "hotdata_manager.h"
using namespace blender;
using namespace std;

NotPersonalkeyData::NotPersonalkeyData():_not_personalkey_list(NULL), _old_not_personalkey_list(NULL)
{

}

NotPersonalkeyData::~NotPersonalkeyData()
{
	if(NULL == _old_not_personalkey_list )
	{
		delete _old_not_personalkey_list;
		_old_not_personalkey_list = NULL;
	}
}

NotPersonalkeyData *NotPersonalkeyData::getInstance()
{
    static NotPersonalkeyData *_instance = NULL;
    if( NULL == _instance )
    {
        _instance = new NotPersonalkeyData();
    }

    return _instance;
}

HOTDATA_REGDATA(NotPersonalkeyData, "reload_key_whitelist");

int NotPersonalkeyData::init()
{
    string html;
    int ret = update(html);
	return ret;
}	

int NotPersonalkeyData::info(std::string &html)
{
    if( NULL == _not_personalkey_list )
    {
        html.append("\n not_personalkey_list is NULL!!! \n\n");
        return -1;
    }

    std::set<string>::iterator it = _not_personalkey_list->begin();
    
    html += "not_personalkey_list in blender :";
    html += "\n";
    for( ; it != _not_personalkey_list->end(); it++)
    {
        html += "\n";
        html += *it;
    }

    html.append("\n" + HotDataBase::getUpdateTimeStr() );
	return 0;
}

int NotPersonalkeyData::update(std::string &html)
{
    std::set<std::string> *tmp_notpersonal_list = new std::set<std::string>();

    std::ifstream fin;
    fin.open(_blender_conf->m_g_url_key_whitelist_file.c_str());
    
    if ( !fin )
    {
        html.append("\n !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!open url_key_whitelist_file failed:");
        html.append(_blender_conf->m_g_url_key_whitelist_file);
        delete tmp_notpersonal_list;
        return -1;
    }
    
    int line_cnt = 0;
    int err_cnt  = 0;
    int ok_cnt  = 0;
    int cmm_cnt  = 0;
    string line;
    string gbk_key;
    while( !fin.eof() )   
    {
        std::getline(fin, line);
        line_cnt++; 
        if ( !line.empty() )
        {
            if('#' == line[0])
            {
                cmm_cnt++;
                continue;
            }

            if(! StrUtil::utf82gbk(line, gbk_key) )
            {
                err_cnt++;
                html.append("\n!!!!!!!!convert to gbk fail line:");
                html.append(line);
                continue;
            }
            tmp_notpersonal_list->insert(gbk_key);
            ok_cnt++;
        }
    }

    fin.close();

    if( NULL != _old_not_personalkey_list )
    {
        delete _old_not_personalkey_list;
        _old_not_personalkey_list = NULL;
    }

    _old_not_personalkey_list = _not_personalkey_list;
    _not_personalkey_list = tmp_notpersonal_list;
    html.append(" \n>>>>>load url_key_whitelist OK, valid size:");
    html.append(boost::lexical_cast<std::string>(tmp_notpersonal_list->size()));
    html.append(" line_cnt:" + boost::lexical_cast<std::string>(line_cnt));
    html.append(" err_cnt:" + boost::lexical_cast<std::string>(err_cnt));
    html.append(" cmm_cnt:" + boost::lexical_cast<std::string>(cmm_cnt));
    html.append("\n");

    HotDataBase::update(html);
    return 0;

}

bool NotPersonalkeyData::not_personalkey(const std::string &url_key)
{
	if ( (NULL == _not_personalkey_list) || url_key.empty() )
    {
        return false;
    }
    
    if ( _not_personalkey_list->find(url_key) != _not_personalkey_list->end() )
    {
        return true;
    }

    return false;  
}
