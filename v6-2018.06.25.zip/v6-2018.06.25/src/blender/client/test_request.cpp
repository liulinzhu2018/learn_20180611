#include "test_request.h"

using namespace framework;

TestRequest::TestRequest(RequestContext *context, PacketHeader *header)
	: Request(context, header)
    , _flag(0)
{
}

TestRequest::~TestRequest()
{
}

int TestRequest::receive()
{
	vector<ResponseData *> results;
    if (getResults(results) != 0) {
		delete this;
        return -1;
    }
    for (size_t i = 0; i < results.size(); i++) {
        ResponseData *res = results[i];
        if (res == NULL || res->getData() == NULL || res->getSize() == 0) {
            continue;
        }
        if ( NULL != res->getData() || 0 != res->getSize() )
        {
		    printf("result data is not NULL\n");
            sleep(1);
            abort(); 
        }
		//string str(res->getData(), res->getSize());
		//printf("result[%ld]=%s\n", i, str.c_str());
    }
	delete this;  //request是new出来的，异步需要自己来释放
	return 0;
}
