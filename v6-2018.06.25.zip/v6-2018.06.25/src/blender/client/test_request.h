#ifndef _BLENDER_REQUEST_H_
#define _BLENDER_REQUEST_H_

#include "framework/server_common.h"
#include "framework/request.h"

using namespace framework;

class TestRequest : public framework::Request
{
	public:
		TestRequest(RequestContext *context, PacketHeader *header = NULL);
		~TestRequest();

		int receive();

        void set_flag( int flag )
        {
            _flag = flag;
        }

private:
    int _flag;
};

#endif 
