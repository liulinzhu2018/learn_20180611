#include "test_request.h"
#include "anet/anet.h"
#include "pthread.h"
#include "framework/client.h"
#include "framework/server_common.h"
#include "jd_search_request.pb.h"

using namespace framework;

int thread_num = 1;
int request_count = 0;
int request_interval_us = 1000;

void* thread_worker(void* para);

int main(int argc, char **argv)
{
	if (argc < 2) {
		fprintf(stderr, "Usage: %s conf [thread_num(1) [request_count(0) interval_ms(1)]]\n", argv[0]);
		return -1;
	}
    char *conf = argv[1];
    if ( argc >= 3 )
    {
        thread_num = atoi(argv[2]);
        if ( thread_num < 1 )
        {
            thread_num = 1;
        }
    }
    if ( argc >= 4 )
    {
        request_count = atoi(argv[3]);
    }

    if ( argc >= 5 )
    {
        request_interval_us = atoi(argv[4]) * 1000;
    }

	Client client;
	int ret = 0;
	if ((ret = client.init(conf)) != 0) {
		fprintf(stderr, "init client fail. err=%d\n", ret);
		return -1;
	}

    printf("thread_num:%d   request_count:%d    request_interval_us:%d\n", thread_num, request_count, request_interval_us);
	sleep(2);

    std::vector<pthread_t> tid_vec;
    for ( int i = 0; i < thread_num; i++ )
    {
        pthread_t id;
        if (pthread_create(&id, NULL, thread_worker, &client)) 
        {
            printf("pthread_create failed\n");
            return 0;
        }
        printf("pthread_create[%d] [%lu]\n", i, id);
        tid_vec.push_back(id);
    }

    for ( int i = 0; i < thread_num; i++ )
    {
        pthread_join(tid_vec[i], NULL);
    }

	sleep(2);  //异步调用，所以sleep等待返回
	client.stop();
	client.wait();
	return 0;
}

void* thread_worker(void* para)
{
    Client *client = (Client*)para;

    int ret = 0;
    jd::search::request::JdSearchQuery query;
    query.set__url("http://test.test.test/");
    query.set__key("test");
    for ( int i = 0; (0 >= request_count) || ((request_count > 0) && (i < request_count)); i++ )
    {
        std::string pbstr;
        query.SerializeToString(&pbstr);
		RequestContext ctx;
		ctx.querys.push_back(pbstr);
		ctx.cm_type = CM_MERGER_SEARCHER;

        TestRequest *request = new (std::nothrow) TestRequest(&ctx);
        //printf("thread_worker send seq_no:%d\n", i);
        request->set_flag(1);
        if ((ret = client->send(request)) != 0) {
		    fprintf(stderr, "send fail. err=%d\n", ret);
			delete request;
            continue;
        }
        request->set_flag(2);
        if (request_interval_us > 0)
        {
	        usleep(request_interval_us);
        }
    }
    return NULL;
}

