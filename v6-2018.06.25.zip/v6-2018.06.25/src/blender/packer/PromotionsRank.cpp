#include "PromotionsRank.h"
#include "boost/lexical_cast.hpp"
//#include "module_mgr.h"
#include "AdvertRank.h"
#include "blender_analysis_data.h"
#include "blender_header.h"
#include <algorithm>
#include <math.h>

namespace blender
{

    static unsigned char AdStrategy30[] = {4, 7, 18, 25};
    static unsigned char NormalStrategy30[] = {12, 25};

    static unsigned char AdStrategy60[] = {4, 7, 18, 25, 34, 37, 48, 55};
    static unsigned char NormalStrategy60[] = {12, 25, 42, 55};

    RankStrategy PromotionsRank::strategy[4] =
    {
        {4, AdStrategy30},
        {2, NormalStrategy30},

        {8, AdStrategy60},
        {4, NormalStrategy60},
    };

    bool PromotionsRank::getStrategy(BlenderAnalysisData* analysisDat, CountPageInfo& page_count_info)
    {
        AdvertRank(analysisDat);

        PromotionsResult& promotions = analysisDat->promotions;
        if (promotions.info.empty())
        {
            BLD_DEBUG(analysisDat->logStream(), "getStrategy promotions.info.empty()");
            return false;
        }

        if ( promotions.type >= (int)(sizeof(strategy)/sizeof(strategy[0])) )
        {
            BLD_WARN(analysisDat->logStream(), "promotions.type:" << promotions.type << " >= stragey_size:" << sizeof(strategy)/sizeof(strategy[0]));
            return false;
        }
        RankStrategy* which = &strategy[promotions.type];
        unsigned char* position = which->position;
        int page_intersection_size = which->size;

        int32_t valid_promotion_perpage = 0;
        for (int i=0; i<page_intersection_size; ++i)
        {
            if (position[i] > analysisDat->query()->_page_size())
            {
                break;
            }
            valid_promotion_perpage += 1;
        }
        if (valid_promotion_perpage == 0)
        {
            BLD_ERROR(analysisDat->logStream(), "getStrategy valid_promotion_perpage==0");
            return false;
        }
        promotions.intersect_valid_pagesize = valid_promotion_perpage;
        promotions.intersection_valid = true;

        page_count_info.page_size = valid_promotion_perpage;
        page_count_info.page_count = ceil((double)promotions.info.size() / page_count_info.page_size);
        page_count_info.data_count = (int)promotions.info.size();
        return true;
    }

#if 0
    int32_t PromotionsRank::PageRemain(int32_t page, CountPageInfo& page_count_info)
    {
        return ((page_count_info.page_size*page) - page_count_info.data_count);
    }
#endif
    void PromotionsRank::CountIntersection(BlenderAnalysisData* analysisDat, int32_t& intersection_num, std::vector<InterSectionData>& part_intersection)
    {
        PromotionsResult& promotions = analysisDat->promotions;
        if (!promotions.intersection_valid)
        {
            return;
        }
        int32_t valid_promotion_perpage = promotions.intersect_valid_pagesize;
        if (valid_promotion_perpage <= 0)
        {
            return;
        }

        /* 当前pagecache缓存的页面数起始位置 */
        int32_t promotions_count = (int)promotions.info.size();

        RankStrategy* which = &strategy[promotions.type];
        unsigned char* position = which->position;

        /* 已经穿插的活动数 */
        int32_t inserted_promotion_num = std::min(valid_promotion_perpage*(analysisDat->query()->_page_index() - 1), promotions_count);
        intersection_num += inserted_promotion_num;
        if (inserted_promotion_num < promotions_count)
        {
            int32_t current_page_begin = inserted_promotion_num;
            int32_t current_page_end = std::min(inserted_promotion_num+valid_promotion_perpage, promotions_count);
            
            /* 当前pagecache缓存的总可能活动数 */
            int32_t current_page_valid = current_page_end-current_page_begin;
            for (int i=0; i<current_page_valid; ++i)
            {
                InterSectionData id;
                id.data_type = PROMOTION;
                id.data_idx = current_page_begin + i;
                id.current_page_idx = (i / valid_promotion_perpage) * analysisDat->query()->_page_size() + position[i % valid_promotion_perpage];
                part_intersection.push_back(id);
            }
        }
    }
}
