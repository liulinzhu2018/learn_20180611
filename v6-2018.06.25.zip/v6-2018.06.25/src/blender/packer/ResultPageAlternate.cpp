#include "ResultPageAlternate.h"
#include "boost/lexical_cast.hpp"
//#include "module_mgr.h"
#include "blender_header.h"
#include "blender_analysis_data.h"

#include <algorithm>
#include <math.h>

namespace blender
{

    /* 计算穿插之后的结果数并返回
     * query_result_count:商品结果数量 page_size:每页结果数
     */
    int32_t ResultPageAlternate::TotalResultCount(int32_t query_result_count, int32_t page_size, BlenderAnalysisData* analysisDat)
    {
        if (page_size <= 0)
        {
            BLD_WARN(analysisDat->logStream(), "ResultPageAlternate::TotalResultCount page_size<=0 ");
            return query_result_count;
        }

        //计算每页可插入的非商品数目
        int32_t intersection_page_size = 0;
        std::vector<CountPageInfo> intersections_collection;

        CountPageInfo shop_page_info;
        if (ShopSearchRank::getStrategy(analysisDat, shop_page_info))
        {
            if (shop_page_info.page_size > 0)
            {
                intersection_page_size += shop_page_info.page_size;
                intersections_collection.push_back(shop_page_info);
            }
        }

        CountPageInfo promotion_page_info;
        if (PromotionsRank::getStrategy(analysisDat, promotion_page_info))
        {
            if (promotion_page_info.page_size > 0)
            {
                intersection_page_size += promotion_page_info.page_size;
                intersections_collection.push_back(promotion_page_info);
            }
        }

        if (intersection_page_size <= 0)
        {
            BLD_WARN(analysisDat->logStream(), "ResultPageAlternate::TotalResultCount intersection_page_size<=0 ");
            return query_result_count;
        }
        std::stable_sort(intersections_collection.begin(), intersections_collection.end(), CountPageInfo::greater_sort);
        BLD_DEBUG(analysisDat->logStream(), "ResultPageAlternate::TotalResultCount intersection_page_size=" << intersection_page_size 
           << " intersections_collection.size=" << intersections_collection.size());
        return adjustCount(query_result_count, page_size, intersections_collection);
    }


    void ResultPageAlternate::pageSplit(BlenderAnalysisData* analysisDat,
            std::vector<InterSectionData>& part_intersections)
    {
        int32_t valid_intersection_num = 0;
        if (analysisDat->m_shop_search_flag)
        {
            ShopSearchRank::CountIntersection(analysisDat, valid_intersection_num, part_intersections);
        }
        if (analysisDat->promotions_flag || analysisDat->advert_flag)
        {
            PromotionsRank::CountIntersection(analysisDat, valid_intersection_num, part_intersections);
        }

        std::stable_sort(part_intersections.begin(), part_intersections.end(), InterSectionData::greater_sort);
        return;
    }
    
#if 0
    void ResultPageAlternate::pageSplit(BlenderAnalysisData* analysisDat,
            const std::vector<QueryRsItem>& all_rs,
            std::vector<QueryRsItem>& part_rs,
            std::vector<InterSectionData>& part_intersections,
            int all_size,
            int page_index,
            int page_size)
    {
        int32_t valid_intersection_num = 0;
        if (analysisDat->m_shop_search_flag)
        {
            ShopSearchRank::CountIntersection(analysisDat, valid_intersection_num, part_intersections);
        }
        if (analysisDat->promotions_flag || analysisDat->advert_flag)
        {
            PromotionsRank::CountIntersection(analysisDat, valid_intersection_num, part_intersections);
        }

        std::stable_sort(part_intersections.begin(), part_intersections.end(), InterSectionData::greater_sort);

        //使用[curr_page_beg, curr_page_end)的开闭区间
        int curr_page_beg=0;
        int curr_page_end=0;
        int curr_query_rs_beg=0;
        int curr_page_size=0;
        //当走的不是pagecache的第一块，则需要计算偏移
        bool calcOffset=(((analysisDat->m_page_index-1)/_global_attr->_pagecached_pages_count)>0);
        if(calcOffset && analysisDat->m_query_rs_offset!=0)
        {//窗口整体左移offset,如果allsize不能满足一个块的容量,商品大小取最后一个商品位置(allsize)-curr_page_beg个商品
            int rs_offset = analysisDat->m_query_rs_offset;
            curr_page_beg = std::min((analysisDat->_cachedpages_start_pos * _global_attr->_pagecached_pages_count * page_size)-rs_offset, all_size);
            curr_query_rs_beg = curr_page_beg - valid_intersection_num;
            if(curr_query_rs_beg<0) {
                ERROR_MESSAGE("curr_query_rs_beg error!page_index:"<< page_index <<" curr_page_beg:" << curr_page_beg << " valid_intersection_num:"
                        <<valid_intersection_num<<" rs_offset:"<<rs_offset);
                curr_page_beg = std::min((analysisDat->_cachedpages_start_pos * _global_attr->_pagecached_pages_count * page_size), all_size);
                curr_query_rs_beg = curr_page_beg - valid_intersection_num;
                curr_page_end = std::min(((analysisDat->_cachedpages_start_pos + 1) * _global_attr->_pagecached_pages_count * page_size), all_size);
                curr_page_size = curr_page_end - curr_page_beg;
            }
            else
            {
                curr_page_end = std::min(((analysisDat->_cachedpages_start_pos + 1) * _global_attr->_pagecached_pages_count * page_size)-rs_offset, all_size);
                if(all_size<curr_page_beg)
                {//出现异常情况pageIndex非常大,当时结果树很小无法提供那么多结果
                    curr_page_size = 0;
                    ERROR_MESSAGE("all_size<curr_page_beg: all_size:"<<all_size<<" curr_page_beg:"<<curr_page_beg);
                }
                else
                {
                    analysisDat->m_cached_page_offset = rs_offset;
                    curr_page_size = min((curr_page_end - curr_page_beg + rs_offset),(all_size-curr_page_beg));
                    for(std::vector<InterSectionData>::iterator it=part_intersections.begin();it!=part_intersections.end();it++)
                    {
                        if(analysisDat->m_cached_page_index!=0&&it->current_page_idx>=analysisDat->m_cached_page_offset)
                            it->current_page_idx-=analysisDat->m_cached_page_offset;
                    }
                }
            }
        }
        else
        {
            curr_page_beg = std::min((analysisDat->_cachedpages_start_pos * _global_attr->_pagecached_pages_count * page_size), all_size);
            curr_page_end = std::min(((analysisDat->_cachedpages_start_pos + 1) * _global_attr->_pagecached_pages_count * page_size), all_size);
            curr_query_rs_beg = curr_page_beg - valid_intersection_num;
            curr_page_size = curr_page_end - curr_page_beg;
        }       
        int current_intersection_size = (int)part_intersections.size();
        int main_doc_count = curr_page_size-current_intersection_size;
        for (int i = 0; i < main_doc_count; ++i)
        {
            /* should not happen */
            if (curr_query_rs_beg+i > all_rs.size())
            {
                continue;
            }
            part_rs.push_back(all_rs[curr_query_rs_beg+i]);
        }

        return;
    }
#endif

    /* 根据商品、店铺、活动的结果数和每页展示数计算最终的结果数
     * 
     */
    int32_t ResultPageAlternate::adjustCount(int32_t rs_count, int32_t page_sz, std::vector<CountPageInfo>& intersections)
    {
        if (rs_count == 0)
        {
            BLD_ERROR(NULL, "ResultPageAlternate::adjustCount rs_count==0");
            return rs_count;
        }
        if (intersections.empty() || page_sz==0)
        {
            BLD_ERROR(NULL, "ResultPageAlternate::adjustCount intersections.empty() or page_sz=0 (page_sz=" << page_sz); 
            return rs_count;
        }
        //获取店铺、活动最大页数的下标
        int max_idx = (int)intersections.size() - 1;
        int rs_pg_count = ceil((double)rs_count/page_sz);

        if (rs_pg_count >= intersections[max_idx].page_count)  //如果商品页数超过所有穿插的最大页数，所有穿插均可加入到结果中
        {
            int intersection_sz = 0;
            for (int idx=0; idx<(int)intersections.size(); ++idx)
            {
                intersection_sz += intersections[idx].data_count;
            }
            BLD_DEBUG(NULL, "ResultPageAlternate::adjustCount intersection_sz:" << intersection_sz);
            return (rs_count + intersection_sz);
        }
        else
        {
            int page_min = std::min(rs_pg_count, intersections[0].page_count); //最少可穿插的页数
            int intersection_first_part=0;                                     //穿插的结果数
            std::vector<CountPageInfo> intersections_new;
            for (int idx=0; idx<(int)intersections.size(); ++idx)
            {
                if (intersections[idx].page_count <= page_min)
                {
                    intersection_first_part += intersections[idx].data_count;
                }
                else
                {
                    intersection_first_part += intersections[idx].page_size*page_min;

                    intersections[idx].data_count -= (intersections[idx].page_size*page_min);
                    intersections[idx].page_count -= page_min;
                    intersections_new.push_back(intersections[idx]);
                }
            }

            int first_part_rs = page_sz * page_min;                            //页面所有结果数
            int first_rs = first_part_rs - intersection_first_part;            //除去穿插之后的page_min页包换的商品数
            if ((rs_count - first_rs) > 0)
            {
                return first_part_rs + adjustCount(rs_count-first_rs, page_sz, intersections_new);
            }
            else
            {
                BLD_DEBUG(NULL, "ResultPageAlternate::adjustCount intersection_first_part:" << intersection_first_part);
                return rs_count + intersection_first_part;
            }
        }
    }


}
