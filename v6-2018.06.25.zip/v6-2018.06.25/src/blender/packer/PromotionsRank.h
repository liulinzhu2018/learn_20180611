#ifndef __PROMOTIONS_RANK_H__
#define __PROMOTIONS_RANK_H__

#include "PromotionsData.h"
#include "data_type.h"
#include "IntersectionData.h"

#include <vector>

namespace blender
{

struct RankStrategy
{
    int size;
    unsigned char *position;
};

struct PromotionsPage
{
    int rank_index;
    PromotionsDetail data;
};

class BlenderAnalysisData;
class PromotionsRank
{
    public:
        enum Type
        {
            NormalRank = 0,
            AdRank = 1,
            MAX = AdRank+1
        };

        explicit PromotionsRank(int type) {}
        ~PromotionsRank() {}

        //static int32_t PageRemain(int32_t page, CountPageInfo& page_count_info);

        static bool getStrategy(BlenderAnalysisData* analysisDat, CountPageInfo& page_count_info);

       static void CountIntersection(BlenderAnalysisData* analysisDat, int32_t& intersection_num, std::vector<InterSectionData>& part_intersection);

    //private:
        static RankStrategy strategy[4];
};

}

#endif
