#ifndef __SHOP_SEARCH_RANK_H__
#define __SHOP_SEARCH_RANK_H__

#include <vector>

#include "ShopSearchData.h"
#include "data_type.h"
#include "IntersectionData.h"

namespace blender
{
    struct ShopsRankStrategy
    {
        int size;
        unsigned char *position;
    };

    class BlenderAnalysisData;
    class ShopSearchRank
    {
        public:
            ShopSearchRank() {}
            ~ShopSearchRank() {}

            static bool getStrategy(BlenderAnalysisData* analysisDat, CountPageInfo& page_count_info);
#if 0
            static int32_t PageRemain(int32_t page, CountPageInfo& page_count_info);
#endif
            static void CountIntersection(BlenderAnalysisData* analysisDat, int32_t& intersection_num, std::vector<InterSectionData>& part_intersection);

        private:
            static ShopsRankStrategy strategy[2];
    };

}

#endif
