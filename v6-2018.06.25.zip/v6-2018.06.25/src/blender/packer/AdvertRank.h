#ifndef __ADVERT_RANK_H__
#define __ADVERT_RANK_H__


namespace blender
{
class BlenderAnalysisData;
void AdvertRank(BlenderAnalysisData* analysisDat);

}

#endif
