#ifndef BLENDER_PACK_RESULT_H_
#define BLENDER_PACK_RESULT_H_

#include "blender_header.h"
#include "jd_search_request.pb.h"
#include "jd_search_response.pb.h"
#include "jd_merge_response.pb.h"
#include "blender_analysis_data.h"
#include "json/value.h"
#include "IntersectionData.h"
#include "blender_logdata.h"

BLENDER_BEGIN;

class BlenderResultPacker
{
public:
    BlenderResultPacker(BlenderAnalysisData *analysisData, BlenderLogData* logData) 
        : _analysisData(analysisData)
        , _logData(logData)
    {
        _query = _analysisData->query();
        _result = _analysisData->mergerResult();
        _pos_arr_size = _result->_products_size() + 100;
        _pos_arr = new char[_pos_arr_size];
        memset(_pos_arr, 0, _pos_arr_size);
    }
    
    ~BlenderResultPacker() {delete []_pos_arr; }
    
    bool packJson(std::string &rs, std::string &rs_cache);
    
private:
    BlenderLogData* logData() const { return _logData; }
    inline std::string json_cast(bool b_value)
    {
        return b_value ? "true" : "false";
    }

    bool packJsonHead(Json::Value &rs, bool hasItems);
    bool packJsonHeadStatus(Json::Value &status);
    bool packQueryProcessorJson(Json::Value & json_query, const bool encUrl, bool isRequery = false);
    bool packJsonBlenderDebug(Json::Value &bld_debug);
    int packIntersectionData(Json::Value &head, int sku_size, Json::Value &json_Paragraph, std::string &json_str, bool useJsonOpm);
    void packNotSkuData(vector<blender::InterSectionData> & part_intersections,
            int doc_index, 
            const bool & encUrl,
            Json::Value & element);
    void packShopsDetail(blender::ShopInfoDetail& item, 
                     bool url_encode, 
                     Json::Value& element);
    void packPromotionsDetail(blender::PromotionsDetail& item, 
                          bool url_encode, 
                          Json::Value& element);
    void packJsonNumberSet(Json::Value& ret);
	std::string packJsonNumberSet();
	void packNotSkuData(
        vector<blender::InterSectionData> & part_intersections,
        int doc_index, 
        const bool & encUrl,
        std::string & element);
	void packShopsDetail(blender::ShopInfoDetail& item, 
                     bool url_encode, 
                     std::string& element);
	void packPromotionsDetail(blender::PromotionsDetail& item, 
                          bool url_encode, 
                          std::string& element);

private:
    BlenderAnalysisData *_analysisData;
    BlenderLogData      *_logData;
    jd::search::request::JdSearchQuery *_query;
    jd::merge::response::MergeResponse *_result;
    char *_pos_arr;
    unsigned int _pos_arr_size;
};


BLENDER_END;
#endif

