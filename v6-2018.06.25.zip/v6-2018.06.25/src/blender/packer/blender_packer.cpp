#include <boost/lexical_cast.hpp> 
#include <boost/algorithm/string/replace.hpp>
#include "string_algorithms.h"
#include <iostream>
#include <exception>
#include <set>
#include "blender_parser.h"
#include "blender_packer.h"
#include "encode_convert.h"
#include "json/json.h"
#include "def.h"
#include "zip.h"
#include "encode_convert.h"
#include "pb2json.h"
#include "ResultPageAlternate.h"
#include "ShopSearchRank.h"
#include "PromotionsRank.h"
#include "blender_config.h"
#include "category_tree_data.h"
#include "scene_artc_strategy.h"
BLENDER_BEGIN;
//using namespace search_frame;
using namespace std;

class JsonStringPacker
{
public:
    enum ObjectType{
    OBJECT = 1,
    ARRAY,
    };
    JsonStringPacker(ObjectType type = OBJECT, bool formated = false):format_(false),begin_(false),type_(type){}
    void begin()
    {
        begin_ = true;
        if(OBJECT == type_){
        ss_ << "{";
        }else if (ARRAY == type_){
        ss_ << "[";
        }else {
        begin_ = false;
        }
    }

    void end()
    {
        ended_ = true;
        if(OBJECT == type_){
        ss_ << "}";
        }else if (ARRAY == type_){
        ss_ << "]";
        }else {
        ended_ = false;
        }
    }

    void setBeginEnd()
    {
        begin_ = true;
        ended_ = true;
    }

    std::string str()
    {
        if ( !begin_ ) begin();
        if ( !ended_ ) end();
        return ss_.str();
    }

    void addPreWork()
    {
        if ( !begin_ ) begin();
        if( ss_.str().length() > 2 )
        {
        ss_ << ",";
        }
    }

    void add(const std::string &key, const long value)
    {
        addPreWork();
        ss_ << "\"" << key << "\":" << value;
    }

    void add(const std::string &key, const string& value)
    {
        addPreWork();
        ss_ << "\"" << key << "\":\"" << value << "\"";
    }

    void add(const std::string &key, JsonStringPacker& value)
    {
        addPreWork();
        ss_ << "\"" << key << "\":" << value.str();
    }


    void add_json_head(const std::string &key)
    {
        if( ss_.str().length() > 2 )
        {
        ss_ << ",";
        }
        ss_ << "\"" << key << "\":" ;
    }

    void append_str(const string& value)
    {
        addPreWork();
        ss_ << "\"" << value << "\"";
    }

    void append_str_only(const string& value)
    {
        ss_ <<  value;
    }

    void append_json_str(const string& value)
    {
        addPreWork();
        ss_ << value;
    }

    void append_json_str_direct(const string& value)
    {
        if ( !begin_ )
        {
        begin();
        }
        else
        {
        if( ss_.str().length() > 2 )
        {
            ss_ << ",";
        }
        }
        
        ss_ << value;
    }

    private:
    bool format_;
    bool begin_;
    bool ended_;
    ObjectType type_;
    std::stringstream ss_;
};

bool BlenderResultPacker::packJson(std::string &rs, std::string &rs_cache)
{
    Json::Value alljs;
    Json::Reader jreader;
    Json::FastWriter jwriter;
    //rs["status"] = _result->_status();
    MsTimer packJsonTimer;
    packJsonTimer.Start();
    MsTimer temptimer;
    temptimer.Start();
    bool isUseJsonOpm = _analysisData->blenderConf()->m_g_packer_json_opm;
    
    JsonStringPacker jsonParagraphStr(JsonStringPacker::ARRAY);

    if ( _result->has__header() )
    {
        jreader.parse(_result->_header(), alljs);
    }
    if ( !alljs.isNull() && !alljs.isObject() )
    {
        BLD_WARN(_analysisData->logStream(), _analysisData->getStrSeqno()<<"packJson alljs.isNull():"<<alljs.isNull()<<" isObject():"<<alljs.isObject()<<" alljs.type:"<<alljs.type());
        alljs = Json::Value();
    }

    Json::Value &head = alljs["Head"];

    
    // ���⴦��only_rcount ����json
    if(_analysisData->blenderConf()->m_g_support_only_rcount && _analysisData->m_only_rcount_url_valid)
    {
        Json::Value onlyRcount;
       
        long long ullClientId = -1;
        try
        {
            ullClientId = boost::lexical_cast<long long>(_analysisData->query()->_client_id());
        }
        catch(...){}

        if( _analysisData->blenderConf()->m_g_only_rcount_client_set.find(ullClientId) != _analysisData->blenderConf()->m_g_only_rcount_client_set.end() )
        {
            if( head["Summary"].isMember("ResultShowCount") && head["Summary"]["ResultShowCount"].isString())
            {
                onlyRcount["ResultCount"] =  head["Summary"]["ResultShowCount"].asString();
            }
            else
            {
                onlyRcount["ResultCount"] =  "merger not response ResultShowCount";
            }
        }
        else
        {
            onlyRcount["ResultCount"] =  "notInWihteList";
        }

        std::string result_str;
        Json::FastWriter w;
        w.write(onlyRcount).swap(result_str);
        
        rs.swap(result_str);
        if ( !rs.empty() )
        {
            rs_cache = rs;
        }
       
        return true;
    }

    if ( head["Query"].isMember("query") )
    {
        string tmpstr = head["Query"]["query"].asString();
        if (_analysisData->query()->_url_encode() && (tmpstr.size() > 0) && (tmpstr[0]!='%'))
        {
            string tmp;
            utils::urlEncode(tmpstr, tmp);
            head["Query"]["query"] = tmp;
        }
    }
    BLD_DEBUG(NULL, "parse head json cost:"<<temptimer.ClockUs());

    //Paragraph
    {
        temptimer.Start();

        //��ȡ��������
        std::string json_intersection;
        Json::Value json_intersection_value;
        int intersection_count;
        intersection_count = packIntersectionData(head, _result->_products_size(), json_intersection_value, json_intersection, isUseJsonOpm);
        
        int pageSize  = _analysisData->query()->_page_size();
        int pageIndex = _analysisData->query()->_page_index();
        if ( head["Summary"]["Page"].isMember("PageSize") && head["Summary"]["Page"]["PageSize"].isString() )
        {
            pageSize = boost::lexical_cast<int>(head["Summary"]["Page"]["PageSize"].asString());
        }
        if ( head["Summary"]["Page"].isMember("PageIndex") && head["Summary"]["Page"]["PageIndex"].isString() )
        {
            pageIndex = boost::lexical_cast<int>(head["Summary"]["Page"]["PageIndex"].asString());
        }

        int add_product_cnt = _result->_products_size();
        if ( _result->_products_size() >= pageSize )
        {
            add_product_cnt -= intersection_count;
        }
        else
        {
            if ( (_result->_products_size() + intersection_count) > pageSize )
            {
                add_product_cnt -= intersection_count - (pageSize - _result->_products_size());
            }
        }
        BLD_DEBUG(_analysisData->logStream(), " intersection_count:"<<intersection_count<<" add_product_cnt:"<<add_product_cnt);

        int new_page_size = 0;
        
        temptimer.Start();
        if(isUseJsonOpm)
        {
            if(_result->_products_size() > 0)
            {
                jsonParagraphStr.add_json_head("Paragraph");
                int product_cnt = 0;
                for ( int i = 0; (i < add_product_cnt) && (product_cnt < _result->_products_size()); i++ )
                {
                    jsonParagraphStr.append_json_str_direct(_result->_products(product_cnt++));
                    new_page_size++;
                }
                    
                if ( _analysisData->blenderConf()->m_g_insert_over_pagesize )
                {
                    while ( product_cnt < _result->_products_size() )
                    {
                        jsonParagraphStr.append_json_str_direct(_result->_products(product_cnt++));
                        new_page_size++;
                    }
                }

                //����������ݷ��ں���
                if(json_intersection.size() > 0 )
                {
                    jsonParagraphStr.append_json_str(json_intersection);
                    new_page_size += intersection_count;
                }
                jsonParagraphStr.end();
            }
            else
            {
                jsonParagraphStr.add_json_head("Paragraph");
                jsonParagraphStr.append_str_only("null");
                jsonParagraphStr.setBeginEnd();
            }
    
        }
        else
        {
            temptimer.Start();
            Json::Value &json_Paragraph = alljs["Paragraph"];

            int product_cnt = 0;
            for ( int i = 0; (i < add_product_cnt) && (product_cnt < _result->_products_size()); i++ )
            {
                Json::Value json_sku;
                if ( !jreader.parse(_result->_products(product_cnt++), json_sku) )
                {
                    Trace_cnt(BLD_STAT_MG_PRODUCT_PARSE_ERR, 1, _analysisData->m_ump2_tag);
                    BLD_WARN(_analysisData->logStream(), _analysisData->getStrSeqno()<<"_products jreader.parse failed:"<<_result->_products(i));
                    i--;
                    continue;
                }
                json_Paragraph.append(json_sku);
                new_page_size++;
            }

            if ( _analysisData->blenderConf()->m_g_insert_over_pagesize )
            {
                while ( product_cnt < _result->_products_size() )
                {
                    Json::Value json_sku;
                    if ( !jreader.parse(_result->_products(product_cnt++), json_sku) )
                    {
                        Trace_cnt(BLD_STAT_MG_PRODUCT_PARSE_ERR, 1, _analysisData->m_ump2_tag);
                        BLD_WARN(_analysisData->logStream(), _analysisData->getStrSeqno()<<"_products jreader.parse failed");
                        continue;
                    }
                    json_Paragraph.append(json_sku);
                    new_page_size++;
                }
            }

            //����������ݷ��ں���
            if(json_intersection_value.size() > 0 )
            {
                for ( size_t i = 0; i < json_intersection_value.size(); i++ )
                {
                    json_Paragraph.append(json_intersection_value[i]);
                    new_page_size++;
                }    
            }
        }
    }

    Json::Value insert_arr;
    insert_arr.resize(0);
    sceneArtcStrategy::getInstance()->packInsert(insert_arr, _analysisData);
    
    if(insert_arr.size() > 0)
    {
        alljs["IntersectionObj"]["data"] = insert_arr;
    }

    temptimer.Start();
    //Head
    packJsonHead(head, _result->_products_size() > 0);
    BLD_DEBUG(NULL, "Head json cost:"<<temptimer.ClockUs());

    temptimer.Start();
    //ObjC_NumberCollection
    packJsonNumberSet(alljs);
    BLD_DEBUG(NULL, "packJsonNumberSet json cost:"<<temptimer.ClockUs());

    temptimer.Start();
    //redEnvelop
    if ( !_analysisData->redpackets_result.empty() )
    {
        Json::Value redEnvelop;
        if ( jreader.parse(_analysisData->redpackets_result, redEnvelop) )
        {
            alljs["redEnvelop"] = redEnvelop;
        }
        else
        {
            Trace_cnt(BLD_STAT_REDPKG_PARSE_ERR, 1, _analysisData->m_ump2_tag);
            BLD_ERROR(_analysisData->logStream(), _analysisData->getStrSeqno()<<"redEnvelop jreader.parse failed:"<<_analysisData->redpackets_result);
        }
    }
    BLD_DEBUG(NULL, "redEnvelop json cost:"<<temptimer.ClockUs());

    temptimer.Start();
    //online-debug
    if ( _result->has__debug_info() )
    {
        Json::Value &json_debug = alljs["debug_info"];
        //merger ��������debug
        jd::search::response::JdDebugInfo *debugInfo = _result->mutable__debug_info();
        for ( int i = 0; i < debugInfo->_debug_size(); i++ )
        {
            std::vector<string> vecstr;
            utils::StringAlgorithms::Split(debugInfo->_debug(i), "\n", vecstr);
            if ( (vecstr.size() > 3) && vecstr[0] == "version1" )
            {
                Json::Value &json_debug_module = json_debug[vecstr[1]][vecstr[2]];
                for ( size_t k = 3; k < vecstr.size(); k++ )
                {
                    json_debug_module.append(vecstr[k]);
                }
            }
            else
            {
                Json::Value &json_debug_others = json_debug["others"];
                for ( vector<string>::iterator it = vecstr.begin(); it != vecstr.end(); it++ )
			    {
				    json_debug_others.append( *it );
			    }
            }
        }
    }

    //qp  online_debug
    if ( _analysisData->qpQuery()->has__debug_info() )
    {    
        Json::Value &json_debug = alljs["debug_info"];
        jd::search::response::JdDebugInfo *debugInfo = _analysisData->qpQuery()->mutable__debug_info();
        for ( int i = 0; i < debugInfo->_debug_size(); i++ )
        {    
            std::vector<string> vecstr;
            utils::StringAlgorithms::Split(debugInfo->_debug(i), "\n", vecstr);
            if ( (vecstr.size() > 3) && vecstr[0] == "version1" )
            {    
                Json::Value &json_debug_module = json_debug[vecstr[1]][vecstr[2]];
                for ( size_t k = 3; k < vecstr.size(); k++ )
                {    
                    json_debug_module.append(vecstr[k]);
                }    
            }    
            else 
            {    
                Json::Value &json_debug_others = json_debug["others"];
                for ( vector<string>::iterator it = vecstr.begin(); it != vecstr.end(); it++ )
                {    
                    json_debug_others.append( *it );
                }    
            }    
        }    
    }

    //blender�Լ���debug
    framework::LogStream* log_stream = _analysisData->logStream(); 
    if ( (NULL != log_stream) && (log_stream->length()> 0) )
    {
        Json::Value &json_debug = alljs["debug_info"];
        if ( framework::LogStream::LOG_INFO >= log_stream->getLevel() )
        {
            packJsonBlenderDebug(json_debug["Blender"]["00_BLD_DEBUG"]);
        }

        Json::Value &json_debug_blender = json_debug["Blender"][_analysisData->blenderConf()->m_g_http_service_ip_port_str];
        std::string dbgstr(log_stream->data(), log_stream->length());
        std::vector<string> vecstr;
    	utils::StringAlgorithms::Split(dbgstr.c_str(), "\n", vecstr);
        for ( vector<string>::iterator it = vecstr.begin(); it != vecstr.end(); it++ )
    	{
    		json_debug_blender.append( *it );
    	}

    }
    BLD_DEBUG(NULL, "blender online-debug json cost:"<<temptimer.ClockUs());

    temptimer.Start();
    MsTimer temptimer1;

    alljs["Head"]["Query"]["HitBlenderCache"]="false";
    std::string result_str;

    if(isUseJsonOpm)
    {
        temptimer1.Start();
        // ����Ʒ��Ϣ��Ľ��д��json
        Json::FastWriter w;
        w.write(alljs).swap(result_str);
        
        BLD_DEBUG(NULL, "write to result_str cost:"<<temptimer1.ClockUs());

        MsTimer temptimer2;
        temptimer2.Start();
        if(_analysisData->is_debug_query())    // ��ʽ����json����ֵ
        {
            // ����paragraph �������ַ�����
            std::size_t last_split = 0;
            std::string styledParagraph;
            if( (last_split = result_str.rfind("}")) != std::string::npos)
            {
                std::string jsonParagraphStrSplit = "," + jsonParagraphStr.str();
                styledParagraph = result_str.replace(last_split, 1, jsonParagraphStrSplit);
                styledParagraph.append("}");
            }

            Json::Value paragraphStyled;
            if ( jreader.parse(styledParagraph, paragraphStyled) )
            {
                paragraphStyled.toStyledString().swap(result_str);
            }
            else
            {
                //alljs["Head"]["Query"]["HitBlenderCache"]="false";
                alljs.toStyledString().swap(result_str);
                Trace_cnt(BLD_STAT_REDPKG_PARSE_ERR, 1, _analysisData->m_ump2_tag);
            }
        }
        else
        {
            // ����paragraph �������ַ�����
            std::size_t last_split = 0;
            std::string tmp_result_str;
            if( (last_split = result_str.rfind("}")) != std::string::npos)
            {
                std::string jsonParagraphStrSplit = "," + jsonParagraphStr.str();
                tmp_result_str = result_str.replace(last_split, 1, jsonParagraphStrSplit);
                tmp_result_str.append("}");
                tmp_result_str.swap(result_str);
            }
        }
        
        BLD_DEBUG(NULL, "Add paragraph string cost:"<<temptimer2.ClockUs());
        temptimer2.End();

    }
    else
    {
        // ԭ���ı�׼json д��ģʽ
        if ( _analysisData->is_debug_query() )
        {
            alljs.toStyledString().swap(result_str);
        }
        else
        {
            Json::FastWriter w;
            w.write(alljs).swap(result_str);
        }
    }

    if ( _analysisData->m_gzip && !_analysisData->is_debug_query())
    {
        _analysisData->m_rs_has_compress = true;
        Zip::gzcompress_mem(rs, result_str);
    }
    else
    {
        temptimer1.Start();
        rs.swap(result_str);
        BLD_DEBUG(NULL, "rs get result_str json cost:"<<temptimer1.ClockUs());
    }
    BLD_DEBUG(NULL, "blender post set string json cost:"<<temptimer.ClockUs());

    // ��packJson
    BLD_DEBUG(NULL, "pack Json cost time:"<<packJsonTimer.ClockUs());
    return true;
}


bool BlenderResultPacker::packJsonHead(Json::Value &json_head, bool hasItems)
{
    json_head["PlatInfo"]["Platform"] = "0";    //������Դ��ƽ������

    Json::Value &json_query = json_head["Query"];

    //��ӡ��־��Ϣ
    {
        bool is_word_search = false;
        std::string word_search_info;
        if ( json_query.isMember("IsWordSearch") && json_query["IsWordSearch"].isString() )
        {
            is_word_search = json_query["IsWordSearch"].asString() == "true";
            word_search_info = _analysisData->query()->_qp_result()._word_search_info();
        }
        if ( is_word_search )
        {
            report_bussiness("word_search", true, _analysisData->m_ump2_tag);
            logData()->ext_add("word_search", word_search_info);
            BLD_INFO(_analysisData->logStream(), _analysisData->getStrSeqno()
                <<" bussiness: key:"<< _analysisData->query()->_original_key()
                <<" IsWordSearch:"<< is_word_search << " word_info:" << word_search_info);
        }
    }

    json_query["Source"]["mg_node"] = _analysisData->m_node_mg_ip_str;
    json_query["Source"]["bld_node"] = _analysisData->blenderConf()->m_g_http_service_ip_port_str;
    json_query["Source"]["qp_node"] = _analysisData->m_node_qp_ip_str;

    json_query["Cost"] = boost::lexical_cast<string>(_analysisData->m_totalCostMs);

    //QueryProcessor
    if (!_analysisData->m_qp_disable || (_analysisData->query()->mutable__qp_result()->_invoke_qp_status() == 0) )
    {
        bool isRequery = false;
        if ( json_head["Query"].isMember("IsRequery") && json_head["Query"]["IsRequery"].isString() )
        {
            isRequery = json_head["Query"]["IsRequery"].asString() == "1";
        }
        Json::Value &json_qp = json_query["QueryProcessor"];
        packQueryProcessorJson(json_qp, _query->_url_encode(), isRequery);
        logData()->_mg_isReqQuery = json_cast(isRequery);
    }

    //Status 
    packJsonHeadStatus(json_head["Status"]);

    if ( !hasItems )
    {
        return true;
    }
    
    json_query["GetingPromotions"] = boost::lexical_cast<string>(_analysisData->promotions_getting);
    json_query["GetingAdvert"] = boost::lexical_cast<string>(_analysisData->advert_getting);
    json_query["GetingShop"] = boost::lexical_cast<string>(_analysisData->shop_getting);
    
    if (_analysisData->promotions_flag)
    {
        json_query["HasPromotions"] = "true";
    }
    else
    {
        json_query["PromotionsInfo"] = _analysisData->promotions.error;
    }
    
    if (_analysisData->advert_flag)
    {
        json_query["HasAdvert"] = "true";
    }
    else
    {
        json_query["AdvertInfo"] = _analysisData->advert.error;
    }

    if (_analysisData->m_shop_search_flag)
    {
        json_query["HasShops"] = "true";
    }
    else if (_analysisData->query()->_debug())
    {
        json_query["ShopSearchInfo"] = _analysisData->m_shop_search_result.context.debug_str;
    }

    if ( _analysisData->blenderConf()->m_g_storetab_valid )
    {
	    if( _analysisData->m_storetab_url_valid)
	    {
	        if( _analysisData->m_storetab_op_valid )
	        {
		        json_query["ShowO2OStoreTab"] = "1";
		        json_query["ShowO2OStoreTab_info"] = "";
		        report_bussiness("storetab", true, _analysisData->m_ump2_tag);
	        }
	        else
	        {
		        json_query["ShowO2OStoreTab"] = "0";
		    json_query["ShowO2OStoreTab_info"] = "op: not in op ";
	        }
	    }
	    else
	    {
	        json_query["ShowO2OStoreTab"] = "0";
            json_query["ShowO2OStoreTab_info"] = "url: url not valid";
	    }
    }
    else
    {
	    json_query["ShowO2OStoreTab"] = "0";
        json_query["ShowO2OStoreTab_info"] = "cfg: cfg not valid";
    }


    if ( _analysisData->m_shoptab_shopsize >= _analysisData->blenderConf()->m_g_shoptab_minisize )
    {
        //if ( ("list" == _analysisData->m_shop_popup_type_str) || ("inshop" == _analysisData->m_shop_popup_type_str) )
        if ( (3 == _analysisData->m_shop_hit_type) || (2 == _analysisData->m_shop_hit_type) )
        {
            json_query["ShowShopTab"] = "2";
            logData()->ext_add("shoptab_showtype", "2");
        }
        else
        {
            json_query["ShowShopTab"] = "1";
            logData()->ext_add("shoptab_showtype", "1");
        }
    }
    else
    {
        json_query["ShowShopTab"] = "0";
        if ( _analysisData->m_shoptab_info.empty() )
        {
            _analysisData->m_shoptab_info = "sp:shop service return empty";
        }
    }
    if ( !_analysisData->m_shoptab_info.empty() )
    {
        json_query["ShowShopTab_info"] = _analysisData->m_shoptab_info;
    }
	
	if ( _analysisData->m_artc_tab_ret_size >= _analysisData->blenderConf()->m_g_artc_tab_minisize )
    {
        json_query["ShowArticleTab"] = "1";
    }
    else
    {
        json_query["ShowArticleTab"] = "0";
        if ( _analysisData->m_artc_tab_info.empty() )
        {
            _analysisData->m_artc_tab_info = "remote:service return empty";
        }
    }
    if ( !_analysisData->m_artc_tab_info.empty() )
    {
        json_query["ShowArticleTab_info"] = _analysisData->m_artc_tab_info;
    }
    
    json_head["Summary"]["insertShopCount"] = boost::lexical_cast<string>(_analysisData->m_shop_search_result.result.shop_list.size());
    json_head["Summary"]["insertPromotionsCount"] = boost::lexical_cast<string>(_analysisData->promotions.info.size());

    return true;
}


bool BlenderResultPacker::packJsonHeadStatus(Json::Value &status)
{
    status["code"] = boost::lexical_cast<string>(_analysisData->m_resp_err_code);
    status["info"] = _analysisData->m_resp_err_info;
    return true;
}


bool BlenderResultPacker::packQueryProcessorJson(Json::Value & json_query, const bool encUrl, bool isRequery)
{
    std::string tmpstr;
    jd::search::request::QPResult* qpResult = _query->mutable__qp_result();

    if ( _analysisData->blenderConf()->m_g_onebox_valid 
        && (_analysisData->m_onebox_mode > 0) )
    {
        if ( !_analysisData->m_onebox_url.empty() )
        {
            json_query["oneboxurl"] = _analysisData->m_onebox_url;
        }
        
        for ( int i = 0; i < qpResult->onebox_size(); i++ )
        {
            const jd::search::request::OneBoxInfo &oneboxinfo = qpResult->onebox(i);

            Json::Value onebox;
            onebox["type"] = oneboxinfo.type();
            onebox["url"] = oneboxinfo.url();

            json_query["onebox"].append(onebox);
        }
    }

    json_query["ShowHiddenInfo"] = boost::lexical_cast<string>(qpResult->hidden_status());

    /*qp have influence*/
    if (_query->_qp_have_influence())
    {
        json_query["QPHasInfluence"] = "true";
    }  else 
    {
        json_query["QPHasInfluence"] = "false";
    }

    if (_analysisData->m_qp_invoke_success == -1)
    {
        json_query["QPInvokeSuccess"] = "-1";
    }  else if (_analysisData->m_qp_invoke_success == 0) 
    {
        json_query["QPInvokeSuccess"] = "false";
    }  else if (_analysisData->m_qp_invoke_success == 1)
    { 
        json_query["QPInvokeSuccess"] = "true";
    }
 
    /*forbidden words*/ 
    if (_analysisData->m_has_forbidden_word == 0)
    {
        json_query["HasForbiddenWord"] = "false";
    } else if (_analysisData->m_has_forbidden_word == 1)
    {
        json_query["HasForbiddenWord"] = "true";
    } else if (_analysisData->m_has_forbidden_word == 2){
        json_query["HasForbiddenWord"] = "noresult";
    }    
    
    /*query type*/
    if (!qpResult->_query_type().empty())
    {
        json_query["QueryType"] = qpResult->_query_type();
    }

    json_query["qptest"] = _analysisData->m_qptest;
  
    /*high cids*/
    /*delete old m_hc_cid1s, m_hc_cid2s?*/
    int high_cid1s_size = qpResult->_hc_cid1s_size();
    int high_cid2s_size = qpResult->_hc_cid2s_size();
    int high_cid3s_size = qpResult->_hc_cid3s_size();
    if (high_cid1s_size > 0 || high_cid2s_size > 0 || high_cid3s_size > 0)
    {
        Json::Value HighCidItems;
#if 0
        if (high_cid1s_size > 0)
        {
            for (int i = 0; i < high_cid1s_size; i++)
            {
                string key = "HcCid1_";
                key += boost::lexical_cast<string>(i+1);
                HighCidItems[key] = boost::lexical_cast<string>(qpResult->_hc_cid1s(i));
            }
        }
        if (high_cid2s_size > 0)
        {
            for (int i = 0; i <high_cid2s_size; i++)
            {
                string key = "HcCid2_";
                key += boost::lexical_cast<string>(i+1);
                HighCidItems[key] = boost::lexical_cast<string>(qpResult->_hc_cid2s(i));
            }
        }
#endif
        if (high_cid3s_size > 0)
        {
            int cid1_id = 1;
            int cid2_id = 1;
            std::set<int> cid1_set;
            std::set<int> cid2_set;
            jd_search_merger::CategoryTree &cate_tree = *(CategoryTreeData::getInstance()->_cat_tree);
            for (int i = 0; i <high_cid3s_size; i++)
            {
                string key = "HcCid3_";
                key += boost::lexical_cast<string>(i+1);
                HighCidItems[key] = boost::lexical_cast<string>(qpResult->_hc_cid3s(i));

                //����cid1��cid2:20161010
                int cid2 = cate_tree.ParentCatID(qpResult->_hc_cid3s(i));
                if ( (cid2 > 0) && cid2_set.find(cid2) == cid2_set.end() )
                {
                    cid2_set.insert(cid2);
                    string key2 = "HcCid2_";
                    key2 += boost::lexical_cast<string>(cid2_id++);
                    HighCidItems[key2] = boost::lexical_cast<string>(cid2);

                    int cid1 = cate_tree.ParentCatID(cid2);
                    if ( (cid1 > 0) && cid1_set.find(cid1) == cid1_set.end() )
                    {
                        cid1_set.insert(cid1);
                        string key1 = "HcCid1_";
                        key1 += boost::lexical_cast<string>(cid1_id++);
                        HighCidItems[key1] = boost::lexical_cast<string>(cid1);
                    }
                }
            }                   
        }
        json_query["HcCids"] = HighCidItems;
    }
  
    /*extended attributes*/
    if (qpResult->_has_extend_attribute())
    {
        json_query["HasExtendAttribute"] = "true";
    } else {
        json_query["HasExtendAttribute"] = "false";
    }
    
    /*season sensitive word*/
    if (qpResult->_is_season_sensitive())
    {
        json_query["HasSeasonSensitive"] = "true";
    } else {
        json_query["HasSeasonSensitive"] = "false";
    }
    
    /*after qp parsing, return web server query*/
    size_t qp_parse_word_size = _query->_key().size();
    if (qp_parse_word_size > 0 || qpResult->m_isbn_key().size() > 0)
    {   
        string parsed_query = _query->_key(); 
        
        if (_query->_expand_status() == "replace" && _query->_query_auto_recovery())
        {
            parsed_query = _query->_expand_key();
        }

        if (encUrl)
        {
            string query_tmp = parsed_query; 
            parsed_query = "";
            utils::urlEncode(query_tmp, parsed_query);
        } 

        json_query["QPParsedQuery"] = parsed_query;
    }  

    json_query["QueryNavType"] = qpResult->_query_nav_type();

    if (_query->_debug())
    {
        std::stringstream ss;

        for (int i = 0; i < qpResult->_term_tags_size(); ++i)
        {
            if (i != 0) ss << ",";
            ss << qpResult->_term_tags(i)._term() << ":" << qpResult->_term_tags(i)._tag();
        }

        if (encUrl)
        {
            utils::urlEncode(ss.str(), tmpstr);
            json_query["QueryTermTypes"] = tmpstr;
        }
        else
        {
            json_query["QueryTermTypes"] = ss.str();
        }
    }

    /*central words*/
    int central_size = qpResult->_center_words_size();
    if (central_size > 0)
    {
        Json::Value CentralWordItems;
        
        int count = 1;
        for ( int i =0; i < qpResult->_center_words_size(); i++, count++ )
        {
            string key = "CentralWord";
            key += boost::lexical_cast<string>(count);
            string central_word = qpResult->_center_words(i)._word(); 
            if (encUrl)
            {
               central_word = "";
               utils::urlEncode(qpResult->_center_words(i)._word(), central_word);
            } 
            CentralWordItems[key] = central_word;
        }
        json_query["CentralWords"] = CentralWordItems;
    }
       
    /*price range filter*/
    if (qpResult->_price_internal()._lower_bound() > 0 || qpResult->_price_internal()._high_bound() > 0)
    {
       Json::Value QueryPriceWordItems;
       //QueryPriceWordItems["QueryPriceRangeWord"] = analysisDat->m_query_price_word;

       QueryPriceWordItems["PriceLowerBound"] = boost::lexical_cast<string>((int)(qpResult->_price_internal()._lower_bound()));
       QueryPriceWordItems["PriceUpperBound"] = boost::lexical_cast<string>((int)(qpResult->_price_internal()._high_bound()));
       
       json_query["QueryPriceRange"] = QueryPriceWordItems; 
    }

    /*expression_key : (color,brand,publisher) filter*/
    if (!qpResult->_filter_show_key().empty() && !isRequery ) 
    {
        string exp_key = qpResult->_filter_show_key();
        if (encUrl)
        {
            exp_key = "";
            utils::urlEncode(qpResult->_filter_show_key(), exp_key);
        } 

        json_query["ExpressionKey"] = exp_key;
    } 

    /*reasonable price range*/
    if (qpResult->_reasonable_cat_price_range_size() > 0)
    {
        Json::Value PriceIntervalItems; 
        int count = 1;
        for ( int i = 0; i < qpResult->_reasonable_cat_price_range_size(); i++, count++ )
        {
            const jd::search::request::CatPriceRange &priceRange = qpResult->_reasonable_cat_price_range(i);
            string cid_key = "CategoryId";
            string low_key = "LowerPrice";
            string upper_key = "UpperPrice";
            int cid = priceRange._catid();
            int lower_price = priceRange._lower_bound();
            int upper_price = priceRange._high_bound();
                        
            string key_index = boost::lexical_cast<string>(count);

            cid_key += key_index; 
            low_key += key_index;
            upper_key += key_index;

            PriceIntervalItems[cid_key] = boost::lexical_cast<string>(cid); 
            PriceIntervalItems[low_key] = boost::lexical_cast<string>(lower_price); 
            PriceIntervalItems[upper_key] = boost::lexical_cast<string>(upper_price);
        }
        json_query["ReasonablePriceRange"] = PriceIntervalItems; 
    }
    
    /*is isbn*/
    if (!qpResult->m_isbn_key().empty())
    {
        json_query["ISBN"] = "true";
    }
    
    /*category filter*/ 
    /*size_t categories_hit_size = analysisDat->m_hit_categories.size();
    if (categories_hit_size > 0)
    {
        Json::Value CategoriesHitItems;
        
        for (size_t i = 0; i < categories_hit_size; i++)
        {
            string key = "CategoryHit";
            key += boost::lexical_cast<string>(i+1); 
            CategoriesHitItems[key] = boost::lexical_cast<string>(analysisDat->m_hit_categories.at(i)); 
        }
        json_query["CategoryFilter"] = CategoriesHitItems;
    }*/
   
    /*qp personality*/
    int personality_types_size = qpResult->_personality_types_size();
    if (personality_types_size > 0)
    {
        Json::Value PersonalityTypesItems;
        
        for (int i = 0; i < personality_types_size; i++)
        {
            string key = "Personality";
            key += boost::lexical_cast<string>(i+1); 
            PersonalityTypesItems[key] = boost::lexical_cast<string>(qpResult->_personality_types(i)); 
        }
        json_query["PersonalityFilter"] = PersonalityTypesItems;
    }

    /*query expand key*/
    if (!_query->_expand_key().empty())
    {
        string expand_key = _query->_expand_key();
        if (encUrl)
        {
            expand_key = "";
            utils::urlEncode(_query->_expand_key(), expand_key);
        } 

        json_query["ExpandQuery"] = expand_key;
    }
     
    /*query expand status*/ 
    if (!_query->_expand_status().empty())
    {
        string expand_status = _query->_expand_status();
        if (encUrl)
        {
            expand_status = "";
            utils::urlEncode(_query->_expand_status(), expand_status);
        } 

        json_query["ExpandQueryStatus"] = expand_status;
    }

    if ( !isRequery )
    {
        /*is jd ware*/
        if (qpResult->_is_jd_ware())
        {
            json_query["IsJDSelfWare"] = "true";
        }

        /*is cod*/
        if (qpResult->_is_cod())
        {
            json_query["IsCod"] = "true";
        }
    
        /*is stock*/
        if (_analysisData->m_qp_specialStoreType == 1)
        {
            json_query["IsStock"] = "true";
        }
    }

    if ( !isRequery || _analysisData->m_qp_specialStoreType == 2 )
    {
        json_query["IsSpecialStock"] = boost::lexical_cast<string>(_analysisData->m_qp_specialStoreType);
    }
    else
    {
        json_query["IsSpecialStock"] = "0";
    }

    json_query["IsRedPacketKey"] = (_analysisData->redpackets_is_key == true) ? "true":"false";

    if ( qpResult->query_synonym().items_size() > 0 )
    {
        Json::Value &sysms = json_query["synonyms"];
        for ( int i = 0; i < qpResult->query_synonym().items_size(); i++ )
        {
            Json::Value sysm;
            if (encUrl)
            {
                std::string tmpw;
                utils::urlEncode(qpResult->query_synonym().items(i).syword(), tmpw);
                sysm["synonym"] = tmpw;
            } 
            else
            {
                sysm["synonym"] = qpResult->query_synonym().items(i).syword();
            }
            sysm["score"] = boost::lexical_cast<string>(qpResult->query_synonym().items(i).weight());
            sysm["id"] = boost::lexical_cast<string>(i+1);
            sysms.append(sysm);
        }
    }

    if ( qpResult->pos_info().items_size() > 0 )
    {
        Json::Value &posinfo= json_query["pos_info"];
        for ( int i = 0; i < qpResult->pos_info().items_size(); i++ )
        {
            Json::Value pos;
            if (encUrl)
            {
                std::string tmpw;
                utils::urlEncode(qpResult->pos_info().items(i).term(), tmpw);
                pos["term"] = tmpw;
            } 
            else
            {
                pos["term"] = qpResult->pos_info().items(i).term();
            }
            pos["score"] = boost::lexical_cast<string>(qpResult->pos_info().items(i).weight());
            pos["tag"] = boost::lexical_cast<string>(qpResult->pos_info().items(i).tag());
            posinfo.append(pos);
        }
        Json::Value &centralWordsinfo= json_query["pos_info_centralProductWords"];
        for ( int i = 0; i < qpResult->pos_info().centralproductwords_size(); i++ )
        {
            Json::Value pos;
            if (encUrl)
            {
                std::string tmpw;
                utils::urlEncode(qpResult->pos_info().centralproductwords(i).term(), tmpw);
                pos["term"] = tmpw;
            } 
            else
            {
                pos["term"] = qpResult->pos_info().centralproductwords(i).term();
            }
            pos["score"] = boost::lexical_cast<string>(qpResult->pos_info().centralproductwords(i).weight());
            pos["tag"] = boost::lexical_cast<string>(qpResult->pos_info().centralproductwords(i).tag());
            centralWordsinfo.append(pos);
        }
    }

    json_query["OPDisableCache"] = json_cast(_analysisData->m_op_disableCache);

    return true;
}


bool BlenderResultPacker::packJsonBlenderDebug(Json::Value &bld_debug)
{
#ifdef BLD_COMPILE_TIME
    bld_debug["0_compile_time"]=BLD_COMPILE_TIME;
#else
    bld_debug["0_compile_time"]="Unknown";
#endif
    /*
    //lentacy
    Json::Value &json_latency = bld_debug["a-Latency"];
    json_latency["total"]   = boost::lexical_cast<string>(_analysisData->m_totalCostMs);
    json_latency["merger"]  = boost::lexical_cast<string>(_analysisData->m_mgTimer.CostMs());
    json_latency["op"]      = boost::lexical_cast<string>(_analysisData->m_opTimer.CostMs());
    json_latency["qp"]      = boost::lexical_cast<string>(_analysisData->m_qpTimer.CostMs());
    json_latency["shop"]    = boost::lexical_cast<string>(_analysisData->m_spTimer.CostMs());
    json_latency["ad"]      = boost::lexical_cast<string>(_analysisData->m_adTimer.CostMs());
    json_latency["pm"]      = boost::lexical_cast<string>(_analysisData->m_pmTimer.CostMs());
    json_latency["shop_flag"]    = boost::lexical_cast<string>(_analysisData->m_shop_search_flag);
    json_latency["ad_flag"]      = boost::lexical_cast<string>(_analysisData->advert_flag);
    json_latency["pm_flag"]      = boost::lexical_cast<string>(_analysisData->promotions_flag);
    json_latency["pm_flag"]      = boost::lexical_cast<string>(_analysisData->promotions_flag);
    json_latency["merger_flag"]      = boost::lexical_cast<string>(_analysisData->m_pb_mergeResult._products_size()>0);
    */
    bld_debug["a-Latency"] = _analysisData->m_getting_cost_info;
   
   
    //Promotion:
    if ( _analysisData->promotions_flag )
    {
        Json::Value &json_pmt = bld_debug["b-Promotions"];
        const blender::PromotionsResult &pmt = _analysisData->promotions;
        json_pmt["type"] = pmt.type;
        json_pmt["intersection_valid"]       = pmt.intersection_valid;
        json_pmt["intersect_valid_pagesize"] = pmt.intersect_valid_pagesize;
        json_pmt["blacklist"] = pmt.blacklist;
        json_pmt["cid3"]    = pmt.cid3;
        json_pmt["cid2"]    = pmt.cid2;
        json_pmt["cid1"]    = pmt.cid1;
        json_pmt["addkey"]  = pmt.addkey;
        json_pmt["error"]   = pmt.error;
        json_pmt["info_size"]   = (int)(pmt.info.size());
        
        Json::Value &json_pmt_dtl = json_pmt["info"];
        for ( size_t i = 0; i < pmt.info.size(); i++ )
        {
            Json::Value dtl;
            dtl["promotion_flag"] = pmt.info[i].promotion_flag;
            dtl["id"]           = boost::lexical_cast<string>(pmt.info[i].id);
            dtl["show_name"]    = pmt.info[i].show_name;
            dtl["url"]          = pmt.info[i].url;
            dtl["banner_url"]   = pmt.info[i].banner_url;
            dtl["from"]         = pmt.info[i].from;
            dtl["desc"]         = pmt.info[i].desc;
            dtl["exposal_url"]  = pmt.info[i].exposal_url;
            
            json_pmt_dtl.append(dtl);
        }
    }

    //AD:
    if ( _analysisData->advert_flag )
    {
        Json::Value &json_ad = bld_debug["b-Advert"];
        const blender::AdvertResult &advert = _analysisData->advert;
        json_ad["type"] = advert.type;
        json_ad["blacklist"] = advert.blacklist;
        json_ad["cid3"]    = advert.cid3;
        json_ad["cid2"]    = advert.cid2;
        json_ad["cid1"]    = advert.cid1;
        json_ad["addkey"]  = advert.addkey;
        json_ad["error"]   = advert.error;
        json_ad["info_size"]   = (int)(advert.info.size());
        
        Json::Value &json_ad_dtl = json_ad["info"];
        for ( size_t i = 0; i < advert.info.size(); i++ )
        {
            Json::Value dtl;
            dtl["promotion_flag"] = advert.info[i].promotion_flag;
            dtl["id"]           = boost::lexical_cast<string>(advert.info[i].id);
            dtl["show_name"]    = advert.info[i].show_name;
            dtl["url"]          = advert.info[i].url;
            dtl["banner_url"]   = advert.info[i].banner_url;
            dtl["from"]         = advert.info[i].from;
            dtl["desc"]         = advert.info[i].desc;
            dtl["exposal_url"]  = advert.info[i].exposal_url;
            
            json_ad_dtl.append(dtl);
        }
    }

    //Shop:
    {
        Json::Value &json_shop = bld_debug["b-Shop"];
        Json::Value &json_shop_context = json_shop["context"];
        {
            const blender::ShopSearchContext &context = _analysisData->m_shop_search_result.context;
            json_shop_context["intersection_valid"] = context.intersection_valid;
            json_shop_context["intersection_empty"] = context.intersection_empty;
            json_shop_context["request_type"] = context.request_type;
            json_shop_context["blacklist"] = context.blacklist;
            json_shop_context["filt_cid1"] = context.filt_cid1;
            json_shop_context["cid2_in_filter"] = context.cid2_in_filter;
            json_shop_context["cid3_in_filter"] = context.cid3_in_filter;
            json_shop_context["service_request_url"] = context.service_request_url;
            json_shop_context["expression_key"] = context.expression_key;
            json_shop_context["debug_str"] = context.debug_str;
            json_shop_context["shop_type"] = context.shop_type;
            json_shop_context["vender_type"] = context.vender_type;
            json_shop_context["hit_shop_id"] = context.hit_shop_id;
            json_shop_context["intersect_strategy"] = context.intersect_strategy;
            json_shop_context["intersect_valid_pagesize"] = context.intersect_valid_pagesize;
            Json::Value &shop_list_idx = json_shop_context["Shop"];
            for ( std::map<int32_t, int32_t>::const_iterator it = context.shop_list_idx.begin(); it != context.shop_list_idx.end(); it++ )
            {
                shop_list_idx[boost::lexical_cast<string>(it->first)] = it->second;
            }
        }
        
        if ( _analysisData->m_shop_search_flag )
        {
            Json::Value &json_shop_result = json_shop["result"];
            const blender::ShopSearchRemoteData &result = _analysisData->m_shop_search_result.result;
            json_shop_result["result_status"] = result.result_status;
            Json::Value &json_shop_list = json_shop_result["shop_list"];
            for ( size_t i = 0; i < result.shop_list.size(); i++ )
            {
                Json::Value json_shop_dtl;
                const blender::ShopInfoDetail &dtl = result.shop_list[i];
                json_shop_dtl["shop_id"] = dtl.shop_id;
                json_shop_dtl["vender_id"] = dtl.vender_id;
                json_shop_dtl["vender_type"] = dtl.vender_type;
                json_shop_dtl["shop_type"] = dtl.shop_type;
                json_shop_dtl["vender_total_score"] = dtl.vender_total_score;
                json_shop_dtl["vender_ware_score"] = dtl.vender_ware_score;
                json_shop_dtl["vender_service_score"] = dtl.vender_service_score;
                json_shop_dtl["vender_effective_score"] = dtl.vender_effective_score;
                json_shop_dtl["shop_icon"] = dtl.shop_icon;
                json_shop_dtl["shop_name"] = dtl.shop_name;
                json_shop_dtl["shop_logo"] = dtl.shop_logo;
                json_shop_dtl["business_category"] = dtl.business_category;
                json_shop_dtl["main_brand"] = dtl.main_brand;
                json_shop_dtl["pic_url"] = dtl.pic_url;
                json_shop_dtl["summary"] = dtl.summary;
                json_shop_dtl["shop_brief"] = dtl.shop_brief;
                json_shop_list.append(json_shop_dtl);
            }
        }
    }


    Json::Value &json_query = bld_debug["c-Merger-Query(jd_search_request)"];
    PB2Json::pb2json(*_query, json_query, false, false);
    if ( _analysisData->m_bld_debug )
    {
        Json::Value &json_qpreq= bld_debug["c-QPRequest"];
        PB2Json::pb2json(*_analysisData->qpQuery(), json_qpreq, false, false);
    }

    _analysisData->debugInfo(true, bld_debug["c-analysisData"]);

    return true;
}


//��������桢���̣����ش��������
int BlenderResultPacker::packIntersectionData(Json::Value &head, int sku_size, Json::Value &json_int_json, std::string &json_int_str, bool isUseJsonOpm)
{
    int allsize   = 0;
    int showCount = 0;
    int pageIndex = 0;
    int pageSize  = 0;
    int pageCount = 0;
    if ( head["Summary"].isMember("ResultCount") && head["Summary"]["ResultCount"].isString() )
    {
        allsize = boost::lexical_cast<int>(head["Summary"]["ResultCount"].asString());
        //allsize = cast2number<int>(head["Summary"]["ResultCount"].asString());
    }
    if ( head["Summary"].isMember("ResultCount") && head["Summary"]["ResultShowCount"].isString() )
    {
        showCount = boost::lexical_cast<int>(head["Summary"]["ResultShowCount"].asString());
    }
    if ( head["Summary"].isMember("Page") )
    {
        if ( head["Summary"]["Page"].isMember("PageIndex") && head["Summary"]["Page"]["PageIndex"].isString() )
        {
            pageIndex = boost::lexical_cast<int>(head["Summary"]["Page"]["PageIndex"].asString());
        }
        if ( head["Summary"]["Page"].isMember("PageSize") && head["Summary"]["Page"]["PageSize"].isString() )
        {
            pageSize = boost::lexical_cast<int>(head["Summary"]["Page"]["PageSize"].asString());
        }
        if ( head["Summary"]["Page"].isMember("PageCount") && head["Summary"]["Page"]["PageCount"].isString() )
        {
            pageCount = boost::lexical_cast<int>(head["Summary"]["Page"]["PageCount"].asString());
        }
    }

    bool has_intersection = (_analysisData->advert_flag || _analysisData->promotions_flag || _analysisData->m_shop_search_flag   ) && sku_size > 0;
    if ( !has_intersection )
    {
        logData()->_ret_result_count = cast2string(showCount);
        logData()->_ret_page_size    = cast2string(pageSize);
        logData()->_ret_page_count   = cast2string(pageCount);
        logData()->_ret_page_index   = cast2string(pageIndex);
        BLD_DEBUG(_analysisData->logStream(), "packIntersectionData has_intersection=false");
        return 0;
    }

    if ( (allsize > 0) && (pageIndex > 0) && (pageSize > 0) )
    {
        int new_size = ResultPageAlternate::TotalResultCount(allsize, pageSize, _analysisData); //����֮��Ľ����
        BLD_DEBUG(_analysisData->logStream(), "packIntersectionData:"
            << " allsize:" << allsize 
            << " pageIndex:" << pageIndex 
            << " pageSize:" << pageSize
            << " new_size:" << new_size); 
        int new_add = new_size - allsize ;
        allsize = new_size;
        if (new_add > 0)
        {
            int page_count = allsize / pageSize;
            if (allsize % pageSize != 0)
            {
                ++page_count;
            }

            logData()->_ret_page_count   = cast2string(page_count);

            head["Summary"]["Page"]["PageCount"] = boost::lexical_cast<string>(page_count);
            //head["Summary"]["Page"]["PageIndex"] = boost::lexical_cast<string>(pageIndex);
            head["Summary"]["ResultCount"] = boost::lexical_cast<string>(new_size);
            
            if ( head["Summary"].isMember("OriginalResultCount") && head["Summary"]["OriginalResultCount"].isString() )
            {
                int org_result_count = boost::lexical_cast<int>(head["Summary"]["OriginalResultCount"].asString());
                head["Summary"]["OriginalResultCount"] = boost::lexical_cast<string>(org_result_count + new_add);
            }

            if ( head["Summary"].isMember("RealCount") && head["Summary"]["RealCount"].isString() )
            {
                int real_count = boost::lexical_cast<int>(head["Summary"]["RealCount"].asString());
                head["Summary"]["RealCount"] = boost::lexical_cast<string>(real_count + new_add);
            }

            if ( head["Summary"].isMember("OrgSkuCount") && head["Summary"]["OrgSkuCount"].isString() )
            {
                int org_sku_count = boost::lexical_cast<int>(head["Summary"]["OrgSkuCount"].asString());
                head["Summary"]["OrgSkuCount"] = boost::lexical_cast<string>(org_sku_count + new_add);
            }
        }
    }

    vector<InterSectionData> part_intersections;
    ResultPageAlternate::pageSplit(_analysisData, part_intersections);
    for ( size_t i = 0; i < part_intersections.size(); i++ )
    {
        if ( isUseJsonOpm )
        {
            std::string item;
            packNotSkuData(part_intersections, i, _analysisData->query()->_url_encode(), item);
            if(json_int_str.size() > 0)
            {
                json_int_str.append(",");
            }
            
            json_int_str.append(item);
        }
        else
        {
            Json::Value item;
            packNotSkuData(part_intersections, i, _analysisData->query()->_url_encode(), item);
            json_int_json.append(item);
        }
    }
    BLD_DEBUG(_analysisData->logStream(), _analysisData->getStrSeqno()<<"packIntersectionData intersections_size:" << part_intersections.size());

    return part_intersections.size();
}



/* �Է���Ʒ����(���̣������߻��)���а�װ */
void BlenderResultPacker::packNotSkuData(
        vector<blender::InterSectionData> & part_intersections,
        int doc_index, 
        const bool & encUrl,
        Json::Value & element)
{
    switch (part_intersections[doc_index].data_type)
    {
        case blender::SHOP:
            {
                blender::ShopInfoDetail& shop_info = _analysisData->m_shop_search_result.result.shop_list[part_intersections[doc_index].data_idx];                
                packShopsDetail(shop_info, encUrl, element);
                break;
            }
        case blender::PROMOTION:
            {
                blender::PromotionsDetail& promotion = _analysisData->promotions.info[part_intersections[doc_index].data_idx];
                packPromotionsDetail(promotion, encUrl, element);
                break;
            }
        case blender::ADVERTISEMENT:
            {
                blender::PromotionsDetail& promotion = _analysisData->promotions.info[part_intersections[doc_index].data_idx];
                packPromotionsDetail(promotion, encUrl, element);
                break;
            }
        default:
            break;
    }
}

/* JSON �Ż���֧���� --- �Է���Ʒ����(���̣������߻��)���а�װ */
void BlenderResultPacker::packNotSkuData(
        vector<blender::InterSectionData> & part_intersections,
        int doc_index, 
        const bool & encUrl,
        std::string & element)
{
    switch (part_intersections[doc_index].data_type)
    {
        case blender::SHOP:
            {
                blender::ShopInfoDetail& shop_info = _analysisData->m_shop_search_result.result.shop_list[part_intersections[doc_index].data_idx];                
                packShopsDetail(shop_info, encUrl, element);
                break;
            }
        case blender::PROMOTION:
            {
                blender::PromotionsDetail& promotion = _analysisData->promotions.info[part_intersections[doc_index].data_idx];
                packPromotionsDetail(promotion, encUrl, element);
                break;
            }
        case blender::ADVERTISEMENT:
            {
                blender::PromotionsDetail& promotion = _analysisData->promotions.info[part_intersections[doc_index].data_idx];
                packPromotionsDetail(promotion, encUrl, element);
                break;
            }
        default:
            break;
    }
}



void BlenderResultPacker::packShopsDetail(blender::ShopInfoDetail& item, 
                     bool url_encode, 
                     Json::Value& element)
{
    if (item.shop_name.length() <= 0)
    {
        return;
    }
    element["type"] = "shop";
    element["wareid"] = boost::lexical_cast<string>(item.shop_id);
    element["shop_icon"] = boost::lexical_cast<string>(item.shop_icon);
    element["vender_type"] = item.vender_type;
    element["pic_url"] = item.pic_url;
    if (url_encode)
    {
        string tmp;
        utils::urlEncode(item.shop_name, tmp);
        element["shop_name"] = tmp;
        tmp.clear();
        utils::urlEncode(item.main_brand, tmp);
        element["main_brand"] = tmp;
        tmp.clear();
        utils::urlEncode(item.summary, tmp);
        element["summary"] = tmp;
    }
    else
    {
        element["shop_name"] = item.shop_name;
        element["main_brand"] = item.main_brand;
        element["summary"] = item.summary;
    }
}

/* JSON �Ż���֧���� --- ��װ�������� */
void BlenderResultPacker::packShopsDetail(blender::ShopInfoDetail& item, 
                     bool url_encode, 
                     std::string& element)
{
    JsonStringPacker jsonShopDetailStr(JsonStringPacker::OBJECT);

    if (item.shop_name.length() <= 0)
    {
        return;
    }
    jsonShopDetailStr.add("type", "shop");
    jsonShopDetailStr.add("wareid", boost::lexical_cast<string>(item.shop_id));
    jsonShopDetailStr.add("shop_icon", boost::lexical_cast<string>(item.shop_icon));
    jsonShopDetailStr.add("vender_type", item.vender_type);
    jsonShopDetailStr.add("pic_url", item.pic_url);

    if (url_encode)
    {
        string tmp;
        utils::urlEncode(item.shop_name, tmp);
        jsonShopDetailStr.add("shop_name", tmp);
        tmp.clear();
        utils::urlEncode(item.main_brand, tmp);
        jsonShopDetailStr.add("main_brand", tmp);
        tmp.clear();
        utils::urlEncode(item.summary, tmp);
        jsonShopDetailStr.add("summary", tmp);
    }
    else
    {
        jsonShopDetailStr.add("shop_name", item.shop_name);
        jsonShopDetailStr.add("main_brand", item.main_brand);
        jsonShopDetailStr.add("summary", item.summary);
    }

    jsonShopDetailStr.end();

    element = jsonShopDetailStr.str();
}

/* JSON �Ż���֧���� --- ��װ������Ϣ */
void BlenderResultPacker::packPromotionsDetail(blender::PromotionsDetail& item, 
                          bool url_encode, 
                          Json::Value& element)
{
    if (item.show_name.length() <= 0)
    {
        return;
    }
    const char *ADVERTSTR = "advert";
    element["type"] = item.from;
    element["wareid"] = boost::lexical_cast<string>(item.id);
    if (url_encode)
    {
        string tmp;
        utils::urlEncode(item.show_name, tmp);
        element["name"] = tmp;
        string tmpDesc;
        utils::urlEncode(item.desc, tmpDesc);
        element["desc"] = tmpDesc;
    }
    else
    {
        element["name"] = item.show_name;
        element["desc"] = item.desc;
    }
    element["url"] = item.url;
    element["banner_url"] = item.banner_url;
    if(item.from.compare(ADVERTSTR) == 0)
    {
        element["exposal_url"] = item.exposal_url;
    }
}

void BlenderResultPacker::packPromotionsDetail(blender::PromotionsDetail& item, 
                          bool url_encode, 
                          std::string& element)
{
    JsonStringPacker jsonPromotionsDetailStr(JsonStringPacker::OBJECT);

    if (item.show_name.length() <= 0)
    {
        return;
    }
    const char *ADVERTSTR = "advert";
    jsonPromotionsDetailStr.add("type", item.from);
    jsonPromotionsDetailStr.add("wareid", boost::lexical_cast<string>(item.id));
    if (url_encode)
    {
        string tmp;
        utils::urlEncode(item.show_name, tmp);
        jsonPromotionsDetailStr.add("name", tmp);
        string tmpDesc;
        utils::urlEncode(item.desc, tmpDesc);
        jsonPromotionsDetailStr.add("desc", tmpDesc);
    }
    else
    {
        jsonPromotionsDetailStr.add("name", item.show_name);
        jsonPromotionsDetailStr.add("desc", item.desc);
    }
    jsonPromotionsDetailStr.add("url", item.url);
    jsonPromotionsDetailStr.add("banner_url", item.banner_url);
    if(item.from.compare(ADVERTSTR) == 0)
    {
        jsonPromotionsDetailStr.add("exposal_url", item.exposal_url);
    }

    jsonPromotionsDetailStr.end();
    element = jsonPromotionsDetailStr.str();
}



// void BlenderResultPacker::packJsonNumberSet(Json::Value& ret)
// {
//     Json::Value element;

//     //����ҳ����������Ϣ
//     if ( _analysisData->shop_top_shop_id > 0 )
//     {
//         element["shop_id"]   = _analysisData->shop_top_shop_id;
//         element["vender_id"] = _analysisData->shop_top_vender_id;
//         element["jd_shop"]   = boost::lexical_cast<string>(_analysisData->shop_top_vender_type);
//     }

//     //����������Ϣ
//     ShopSearchInfo& shop_ret = _analysisData->m_shop_search_result;
//     if (shop_ret.result.result_status == ALL_RIGHT)
//     {
//         Json::Value ssr;
//         ssr["shop_ret_count"] = boost::lexical_cast<string>(shop_ret.result.shop_list.size());
//         switch (shop_ret.context.request_type)
//         {
//             case REQUEST_SHOP_INTERSECTION:
//                 ssr["ret_type"] = REQUEST_SHOP_INTERSECTION;
//                 break;
//             case REQUEST_SHOP_LIST:
//                 ssr["ret_type"] = REQUEST_SHOP_LIST;
//                 break;
//             case REQUEST_SHOP_SINGLE:
//                 ssr["ret_type"] = REQUEST_SHOP_SINGLE;
//                 break;
//             case DO_NOTHING:
//                 ssr["ret_type"] = DO_NOTHING;
//                 break;
//         }
//         ssr["shop_search_err"] = shop_ret.context.debug_str;
//         element["shop_search_info"] = ssr;
//     }

//     element["popup_type"] = _analysisData->m_shop_popup_type_str;

//     if ( _analysisData->query()->_x_json_null() && element.empty()) {
//         return;
//     }

//     ret["ObjC_NumberCollection"] = element;
//     return;
// }

void BlenderResultPacker::packJsonNumberSet(Json::Value& ret)
{
    Json::Value& element = ret["ObjC_NumberCollection"];
    
    //����ҳ����������Ϣ
    if ( (0 != _analysisData->shop_top_shop_id) && (0 != _analysisData->shop_top_vender_id) )
    {
        element["shop_id"]   = boost::lexical_cast<unsigned int>(_analysisData->shop_top_shop_id);
        element["vender_id"] = boost::lexical_cast<unsigned int>(_analysisData->shop_top_vender_id);
        element["jd_shop"]   = boost::lexical_cast<string>(_analysisData->shop_top_vender_type);
    }

    //����������Ϣ
    ShopSearchInfo& shop_ret = _analysisData->m_shop_search_result;
    if (shop_ret.result.result_status == ALL_RIGHT)
    {
        Json::Value ssr;
        ssr["shop_ret_count"] = boost::lexical_cast<string>(shop_ret.result.shop_list.size());
        switch (shop_ret.context.request_type)
        {
            case REQUEST_SHOP_INTERSECTION:
                ssr["ret_type"] = REQUEST_SHOP_INTERSECTION;
                break;
            case REQUEST_SHOP_LIST:
                ssr["ret_type"] = REQUEST_SHOP_LIST;
                break;
            case REQUEST_SHOP_SINGLE:
                ssr["ret_type"] = REQUEST_SHOP_SINGLE;
                break;
            case DO_NOTHING:
                ssr["ret_type"] = DO_NOTHING;
                break;
        }
        ssr["shop_search_err"] = shop_ret.context.debug_str;
        element["shop_search_info"] = ssr;
    }

    element["popup_type"] = _analysisData->m_shop_popup_type_str;
}

//JSON �Ż���֧���� ---  ʹ���ַ����滻����json��װ

std::string BlenderResultPacker::packJsonNumberSet()
{
    JsonStringPacker jsonTopShopStr(JsonStringPacker::OBJECT);

    // ����ҳ����������Ϣ
    if(_analysisData->shop_top_shop_id > 0)
    {
        jsonTopShopStr.add("shop_id", boost::lexical_cast<unsigned int>(_analysisData->shop_top_shop_id));
        jsonTopShopStr.add("vender_id", boost::lexical_cast<unsigned int>(_analysisData->shop_top_vender_id));
        jsonTopShopStr.add("jd_shop", boost::lexical_cast<string>(_analysisData->shop_top_vender_type));
    }
    jsonTopShopStr.add("popup_type", _analysisData->m_shop_popup_type_str);

    // ����������Ϣ
    ShopSearchInfo& shop_ret = _analysisData->m_shop_search_result;
    if(shop_ret.result.result_status == ALL_RIGHT)
    {
        JsonStringPacker jsonShopSearchInfo;
        jsonShopSearchInfo.add("shop_ret_count", boost::lexical_cast<string>(shop_ret.result.shop_list.size()));
        jsonShopSearchInfo.add("ret_type", (int)shop_ret.context.request_type);
        jsonShopSearchInfo.add("shop_search_err", shop_ret.context.debug_str);
        jsonTopShopStr.add("shop_search_info", jsonShopSearchInfo);
    }

    return jsonTopShopStr.str();

}

BLENDER_END;

