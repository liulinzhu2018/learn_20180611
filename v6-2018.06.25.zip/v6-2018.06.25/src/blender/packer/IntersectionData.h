#ifndef __INTERSECTION_INTERFACE_H__
#define __INTERSECTION_INTERFACE_H__

#include <vector>
#include <boost/shared_ptr.hpp>
#include "data_type.h"
#include "ShopSearchData.h"
#include "PromotionsData.h"

namespace blender
{
    struct CountPageInfo
    {
        /* page count of all intersections data size */
        int32_t page_count;
        /* data count of all intersections data size */
        int32_t data_count;
        /* quantity of intersection dispaly in page */
        int32_t page_size;

        CountPageInfo():
            page_count(0),
            data_count(0),
            page_size(0)
        {}

        /* to find a min page count */
        inline static bool greater_sort(const CountPageInfo& l, const CountPageInfo& r)
        {
            return (l.page_count < r.page_count);
        }
    };

    /* type of intersection data */
    enum IntersectionType{PROMOTION, SHOP, ADVERTISEMENT, NONE};

    struct InterSectionData
    {
        /* idx in intersections array */
        int32_t data_idx;
        /* position in page */
        int32_t current_page_idx;
        /* type of intersection data */
        IntersectionType data_type;

        InterSectionData():
            data_idx(-1),
            current_page_idx(-1),
            data_type(NONE)
        {}

        /* sort with position in page */
        inline static bool greater_sort(const InterSectionData& l, const InterSectionData& r)
        {
            return l.current_page_idx < r.current_page_idx;
        }
    };

    /* temporary variable for insert shop, adverts and promotions */
    struct PageCacheIntersectionData
    {
        PageCacheIntersectionData():
            data_type(NONE), seq_no(-1), is_normal(true)
        {
            shop_detail.reset();
            promotion_detail.reset();
        }
        IntersectionType data_type;
        boost::shared_ptr<ShopInfoDetail> shop_detail;
        boost::shared_ptr<PromotionsDetail> promotion_detail;
        int seq_no;
        bool is_normal;
    };

}

#endif
