#include "ShopSearchRank.h"
#include "ResultPageAlternate.h"
#include "blender_analysis_data.h"
#include "blender_header.h"
#include "blender_config.h"
#include <algorithm>
#include <math.h>

namespace blender
{
    static unsigned char NormalStrategy[] = {19};
    static unsigned char NormalStrategy60[] = {19, 49};

    ShopsRankStrategy ShopSearchRank::strategy[2] =
    {
        {1, NormalStrategy},
        {2, NormalStrategy60},
    };

    bool ShopSearchRank::getStrategy(BlenderAnalysisData* analysisDat, CountPageInfo& page_count_info)
    {
        if (!analysisDat->m_shop_search_flag)
        {
            BLD_DEBUG(analysisDat->logStream(), "analysisDat->m_shop_search_flag==false");
            return false;
        }

        ShopSearchInfo& shop_search_info = analysisDat->m_shop_search_result;
        if (shop_search_info.result.shop_list.empty() || shop_search_info.context.intersect_strategy < 0)
        {
            BLD_DEBUG(analysisDat->logStream(), "shop_list.empty or intersect_strategy<0 (" << shop_search_info.context.intersect_strategy);
            return false;
        }
        ShopsRankStrategy* which = &strategy[shop_search_info.context.intersect_strategy];
        int32_t page_intersection_size = which->size;
        unsigned char* position = which->position;

        //计算每页可插入的店铺数目
        int32_t valid_shop_perpage = 0;
        for (int i=0; i<page_intersection_size; ++i)
        {
            if (position[i] > analysisDat->query()->_page_size())
            {
                break;
            }
            valid_shop_perpage += 1;
        }
        if (valid_shop_perpage == 0)
        {
            BLD_ERROR(NULL, "valid_shop_perpage == 0");
            return false;
        }
        shop_search_info.context.intersect_valid_pagesize = valid_shop_perpage;
        shop_search_info.context.intersection_valid = true;

        page_count_info.page_size = valid_shop_perpage;
        page_count_info.page_count = ceil((double)shop_search_info.result.shop_list.size() / valid_shop_perpage);
        page_count_info.data_count = (int)shop_search_info.result.shop_list.size();
        return true;
    }

#if 0
    int32_t ShopSearchRank::PageRemain(int32_t page, CountPageInfo& page_count_info)
    {
        return ((page_count_info.page_size*page) - page_count_info.data_count);
    }
#endif
    void ShopSearchRank::CountIntersection(BlenderAnalysisData* analysisDat, int32_t& intersection_num, std::vector<InterSectionData>& part_intersection)
    {
        ShopSearchInfo& shop_search_info = analysisDat->m_shop_search_result;
        if (!shop_search_info.context.intersection_valid)
        {
            return;
        }
        int32_t valid_shop_perpage = shop_search_info.context.intersect_valid_pagesize;
        if (valid_shop_perpage <= 0)
        {
            return;
        }

        /* 当前pagecache缓存的页面数起始位置 */
        int32_t shop_search_result_count = (int)shop_search_info.result.shop_list.size();

        ShopsRankStrategy* which = &strategy[shop_search_info.context.intersect_strategy];
        unsigned char* position = which->position;

        /* 已经穿插的店铺数 */ 
        int32_t inserted_shop_num = std::min(valid_shop_perpage*(analysisDat->query()->_page_index() - 1), shop_search_result_count);
        intersection_num += inserted_shop_num;
        if (inserted_shop_num < shop_search_result_count)
        {
            int32_t current_page_begin = inserted_shop_num;
            int32_t current_page_end = std::min(inserted_shop_num+valid_shop_perpage, shop_search_result_count);
            /* 当前pagecache缓存的总可能店铺数 */
            int32_t current_page_valid = current_page_end-current_page_begin;
            for (int i=0; i<current_page_valid; ++i)
            {
                InterSectionData id;
                id.data_type = SHOP;
                id.data_idx = current_page_begin + i;
                /* pagecache缓存的页面中所有店铺的位置信息 */
                id.current_page_idx = (i / valid_shop_perpage) * analysisDat->query()->_page_size() + position[i % valid_shop_perpage];
                part_intersection.push_back(id);
            }
        }
    }

}
