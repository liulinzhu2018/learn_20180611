#ifndef __RESULT_PAGE_ALTERNATE_H__
#define __RESULT_PAGE_ALTERNATE_H__
#include "stdint.h"
#include "data_type.h"
#include "ShopSearchRank.h"
#include "PromotionsRank.h"
#include <vector>

namespace blender
{
    class BlenderAnalysisData;
    class ResultPageAlternate 
    {
        public:

            explicit ResultPageAlternate() {}
            ~ResultPageAlternate() {}

#if 0
            static void pageSplit(BlenderAnalysisData* analysisDat,
                    const std::vector<QueryRsItem>& all_rs, 
                    std::vector<QueryRsItem>& part_rs,
                    std::vector<InterSectionData>& part_intersections,
                    int all_size,
                    int page_index,
                    int page_size);
#endif
            static void pageSplit(BlenderAnalysisData* analysisDat, std::vector<InterSectionData>& part_intersections);

            static int32_t TotalResultCount(int32_t query_result_count, int32_t page_size, BlenderAnalysisData* analysisDat);
            static int32_t adjustCount(int32_t rs_count, int32_t page_sz, std::vector<CountPageInfo>& intersections);
    };

}

#endif
