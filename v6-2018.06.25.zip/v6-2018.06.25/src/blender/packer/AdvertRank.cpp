#include "AdvertRank.h"
#include "SimpleThirdPartyData.h"
#include "blender_analysis_data.h"
#include <algorithm>
#include <vector>
#include <iterator>

namespace blender
{

void AdvertRank(BlenderAnalysisData* analysisDat)
{
    std::vector<SimpleThirdPartyData>& promotion = analysisDat->promotions.info;
    const std::vector<SimpleThirdPartyData>& advert = analysisDat->advert.info;

    if (advert.empty())
        return;

    std::vector<SimpleThirdPartyData> result;
    int pm_sz = promotion.size();
    int ad_sz = advert.size();
    int total_sz = pm_sz + ad_sz;

    result.reserve(total_sz);

    const std::vector<SimpleThirdPartyData>* longer_vec = NULL;
    int sz = pm_sz < ad_sz ? (longer_vec = &advert, pm_sz) : (longer_vec = &promotion, ad_sz);

    int i = 0;
    while (i < sz)
    {
        result.push_back(promotion[i]);
        result.push_back(advert[i]);

        ++i;
    }

    int rem_sz = total_sz - sz*2;
    if (rem_sz > 0)
    {
        const SimpleThirdPartyData* beg = &(*longer_vec)[i];
        std::copy(beg, beg+rem_sz, std::back_inserter(result));
    }

    result.swap(promotion);

#if 0
    if (LogTrace::checkTraceFlag(TRACE_ADVERT_INFO))
    {
        stringstream stream;
        stream << "{AdvertRank info: {count:" << promotion.size() << ",[";
        for (size_t i = 0; i < promotion.size(); ++i)
        {
            SimpleThirdPartyData& ret_vec_item = promotion[i];
            stream << ret_vec_item.show_name << ",";
        }
        stream << "]}}\n";

        INFO_MESSAGE(stream.str());
    }
#endif
}

}
