#include "blender_server.h"
#include "framework/command.h"
#include "framework/client.h"
#include "clustermap/cm_client.h"
#include <pthread.h>
#include "framework/server_config.h"
#include "async_service.h"
#include <glog/logging.h>
#include "server/blender_config.h"
#include "hotdata_manager.h"
#include "http_session.h"
#include "blender_state.h"
#include "blender_state.h"
#include "general_states.h"
#include "local_cache.h"
#include "merger_int_state.h"
#include "qp_state.h"
#include "http_flow_control_timer.h"
#include "blender_timer_handler.h"
#include "ump_report.h"
#include "jdsz_counter.h"
#include "blender_config_data.h"
using namespace blender;
int _test_sleep = 0;


bool url_decode(const std::string& in, std::string& out);

BlenderServer::BlenderServer() 
{
	_client = NULL;
}

BlenderServer::~BlenderServer() 
{
    if ( NULL != _blender_conf )
    {
        delete _blender_conf;
        _blender_conf = NULL;
    }

    delete BlenderLogger::instance();

    delete AsyncService::instance();

    delete HotDataManager::getInstance();
    ump_report::uninit_ump();
}

int BlenderServer::init(const char *ini)
{        
    int ret = 0;
    //init blender config
    ret = _blender_conf->loadConfig(ini);
    if (0 != ret)
    {
        printf("load blender_config:%s failed", ini);
        return ret;
    }

    //init glog
    BlenderLogger::instance()->init();

    //UMP init
    ret = ump_report::init_ump(_blender_conf->m_g_app_name, _blender_conf->m_g_ump_auto_reg_key);
    if ( 0 != ret )
    {
        printf("init ump_report failed:%d\n", ret);
        return ret;
    }

    //init base server
    ret = BaseServer::init(ini);
    if (0 != ret)
    {
        LOG(ERROR)<<"init base server failed:"<<ret<<std::endl;
        return ret;
    }

    AsyncService::instance()->init(_thread_num);

    HotDataManager::getInstance()->init();

    LocalCache::instance()->resetCapacity(_blender_conf->m_g_promotionkey_cache_limit_size);

    //下面是状态执行顺序
    BLD_REG_STATE(FSM_STATE_INIT, BlenderInitState, FSM_STATE_PARSER);
    if(_blender_conf->m_g_cachefirst_valid)
    {
        BLD_REG_STATE(FSM_STATE_PARSER, BlenderParserState, FSM_STATE_CACHE);
        BLD_REG_STATE(FSM_STATE_CACHE, BlenderCacheState, FSM_STATE_QP);
        BLD_REG_STATE(FSM_STATE_QP, BlenderQPState, FSM_STATE_MERGER_AND_INT);

    }
    else
    {
        BLD_REG_STATE(FSM_STATE_PARSER, BlenderParserState, FSM_STATE_QP);
        BLD_REG_STATE(FSM_STATE_QP, BlenderQPState, FSM_STATE_CACHE);
        BLD_REG_STATE(FSM_STATE_CACHE, BlenderCacheState, FSM_STATE_MERGER_AND_INT);
    }
    BLD_REG_STATE(FSM_STATE_MERGER_AND_INT, BlenderMergerTIntState, FSM_STATE_FINISH);
    BLD_REG_STATE(FSM_STATE_FINISH, BlenderFinishState, FSM_STATE_NONE);

    //消息映射到状态
    MAP_MSG_2_STATE(BLENDER_MSG_CLIENT,     "default",   FSM_STATE_INIT);
    MAP_MSG_2_STATE(BLENDER_MSG_QP,         "qp",        FSM_STATE_QP);
    MAP_MSG_2_STATE(BLENDER_MSG_MERGER,     "merger",    FSM_STATE_MERGER_AND_INT);
    MAP_MSG_2_STATE(BLENDER_MSG_EXT,        "ext_int",   FSM_STATE_MERGER_AND_INT);

    if ( !BlenderState::check_state_all_ok() )
    {
        BLD_ERROR(NULL, "init fsm state error");
        return -4;
    }

    //初始化定时器处理对象
    new HttpFlowControlTimer();

    printf("init ok\n");
    return 0;
}

int32_t BlenderServer::start()
{
    AsyncService::instance()->start();
    BlenderTimerHanderManager::instance()->start();
	return BaseServer::start();
}

void BlenderServer::stop()
{
	BaseServer::stop();
	Server::stop();
    AsyncService::instance()->stop();
    BlenderTimerHanderManager::instance()->stop();
    ump_report::uninit_ump();
}

void BlenderServer::wait()
{   
    AsyncService::instance()->wait();
	BaseServer::wait();
	Server::wait();
}


bool BlenderServer::is_busy(char **busy_info) const 
{
    if ( BaseServer::is_busy(busy_info) )
    {
        return true;
    }
   
#if 0
    if ( (_blender_conf->m_g_flowctl_thrift_queue_limit > 0) && (AsyncService::instance()->queue_size() >= _blender_conf->m_g_flowctl_thrift_queue_limit) )
    {
        if ( NULL != busy_info ) *busy_info = "thrift_queue busy";
        return true;
    }
#endif

    return false;
}

int BlenderServer::work_cmd(HttpSession* session)
{
    if ( NULL == session )
    {
        return -1;
    }
    int len = 0;
    string url = session->getQuery(len);

    //counter:1s allown 5 reqs
    static utils::Counter g_cmd_counter(1,5);
    if ( g_cmd_counter.check() )
    {
        BLD_INFO(NULL, session->remote_info() << "cmd query busy: cmd url:"<<url.c_str());
        session->response("cmd channel busy!!!\nallown 5 request by 1 second", http::server31::reply::forbidden);
        return 0;
    }

    std::size_t pos = url.find("?");
    std::string cmd;
    if ( std::string::npos == pos ) 
    {
        cmd = url;
    }
    else
    {
        cmd = url.substr(0, pos);
    }
    BLD_INFO(NULL, session->remote_info() << "cmd query: url:"<<url.c_str() <<" cmd:"<<cmd);

    if ( cmd == "info")
    {
        std::string html;
        std::string fm_info = ""; 
        framework::ServerConfig *conf = _client->getConfig();
        if (conf) conf->get(fm_info);
        framework::CMClient *clustermap = _client->getCMClient();
        if (clustermap) clustermap->info(fm_info);
        html.append(fm_info);
        html.append("\n").append(BlenderConfigData::getInstance()->othersInfo());
        std::string info_env = url.substr(pos + 1);
        BlenderConfig *bld_config = BlenderConfigData::getInstance()->getInstance(info_env, false);
        if (bld_config)
        {
            if(info_env != "info")
            {
                html.append(info_env + "  BlenderConfig  -----------------------  \n");
            }else{
                html.append("default  BlenderConfig  -----------------------  \n");
            }
            html.append(bld_config->DebugString());
        }else{
            session->response("not support!!", http::server31::reply::bad_request);
            return 0;            
        }
        html.append(HotDataManager::getInstance()->SystemInfo());
        session->response(html);
            
        return 0;
    }
    else if( cmd == "detail")
    {
        std::string html;
        std::string info_cmd = url.substr(pos + 1);
        HotDataManager::getInstance()->handleInfo(info_cmd, html);
        session->response(html);
            
        return 0;
    }     
    else if ( cmd == "config" )
    {
        std::string fm_param = url.substr(pos + 1);
        framework::ServerConfig *conf = _client->getConfig();
        if (conf) conf->set(fm_param.c_str(), fm_param.length());
        framework::CMClient *clustermap = _client->getCMClient();
        if (clustermap) clustermap->set(fm_param.c_str(), fm_param.length());

        std::string html = "";
        if (conf) conf->get(html);
        if (clustermap) clustermap->info(html);
        HotDataManager::getInstance()->handleConfig(fm_param, html);
   //      if ( 0 == HotDataManager::getInstance()->handleConfig(fm_param, html) )
   //      {
			// html.append(_blender_conf->DebugString());
   //      }
        html.append(HotDataManager::getInstance()->SystemInfo());
        session->response(html);
    }
    else
    {
        session->response("not support!!", http::server31::reply::bad_request);
    }
    return 0;
}


int BlenderServer::work( blender::TaskWrapper * wrapper)
{
    wrapper->_stTimer.End();
    jdsz_logtrace::Trace_latency(BLD_STAT_TASK_QUEUE_WAIT_LATENCY, wrapper->_stTimer.CostUs());
    if (wrapper->isFromClient())
    {
        HttpSession_ptr session = wrapper->getSession();
        framework::SessionType type = session->getType();
        if (type == framework::ss_default)
        {
            int len = 0;
            string url = session->getQuery(len);


            int retCheck = CheckUrl(url);
            if ( retCheck == -1 )
    	    {
    		    BLD_WARN(NULL, session->seqno_str()<<"not path(\"?\") " << session->remote_info() << " req_url:" << url);
    	        wrapper->getSession()->response("{\"Head\":{\"PlatInfo\":{\"Platform\":\"0\"},\"Status\":{\"code\":\"5003\",\"info\":\"blender:no ? in url\"}}}");
                //session_report(session->latency(), false);
                Trace_cnt(BLD_STAT_INVALID_REQ, 1, "");

                BlenderLogData logData(url);
                logData.init(session.get());
                logData._resp_code = "5003";
                logData._resp_info = "blender:invalid url";
                BLD_SMART_LOG(logData.toString());
    	        return 0; 
            }
            else if(retCheck == -2)
            {
                BLD_WARN(NULL, session->seqno_str()<<"only_rcount is closed(set false)! req_url:" << url);
    	        wrapper->getSession()->response("{\"Reason\" : \"only_rcount is diabled\"}");
                //session_report(session->latency(), false);
                Trace_cnt(BLD_STAT_INVALID_REQ, 1, "");
                
                BlenderLogData logData(url);
                logData.init(session.get());
                logData._resp_code = "5003";
                logData._resp_info = "blender:only_rcount is diabled";
                BLD_SMART_LOG(logData.toString());
    	        return 0; 
            }

            //处理收到的新请求
            HandleNewRequest(wrapper->getSession());
        }
        else
        {
    	    wrapper->getSession()->response("{\"Head\":{\"PlatInfo\":{\"Platform\":\"0\"},\"Status\":{\"code\":\"5001\",\"info\":\"blender:first request but type not ss_default\"}}}");
            session_report(session->latency(), false);
        }
    }
    else
    {
        //处理回调的请求
        HandleRetRequest(wrapper);
    }

	return 0;
}

int BlenderServer::HandleNewRequest(HttpSession_ptr session)
{
    int query_size = 0;
	const char *query = session->getQuery(query_size);
    std::string url(query, query_size);

    BlenderMaster_ptr master(new blender::BlenderMaster(session, this, session->seqno(), url));
    BLD_WARN(master->logStream(), master->getStrSeqno() << session->remote_info() <<" req url:"<<url);
    master->logData()->init(session.get());

    MsgData msg_data(BLENDER_MSG_CLIENT, url, _client);
    int ret = master->handleMsg(&msg_data);
    return ret;
}

int BlenderServer::HandleRetRequest(blender::TaskWrapper * wrapper)
{
    BlenderMaster_ptr master = wrapper->getMaster();
    BlenderRequest* res_msg = wrapper->getRequest();
    if (NULL == res_msg)
    {
        BLD_ERROR(NULL, master->getStrSeqno()<<"res_msg is null");
        return -1;
    }

    MsgData msg_data(res_msg, _client);
    master->handleMsg(&msg_data);
    return 0;
}

int BlenderServer::sendtoClient(BlenderRequest *request)
{
    int ret = 0;
    ret = _client->send(request);
    BLD_INFO(request->master()->logStream(),  "sendtoClient: msg_type:" << request->msgType()<<" ret:"<<ret);
    return ret;
}

int BlenderServer::CheckUrl(std::string rcUrl)
{
    // check url size
    if(rcUrl.size() == 0) return -1;

    //check url whether contain '?'
    std::size_t pos = rcUrl.find("?");
    if ( std::string::npos == pos )
    {
        return -1; 
    }

    //check url contain only_rcout and need_rcout = false
    std::size_t onlyRcoutPos = rcUrl.find("only_rcount");
    if(onlyRcoutPos != std::string::npos)
    {
        BLD_DEBUG(NULL, "_blender_conf->m_g_need_only_rcount"<<_blender_conf->m_g_support_only_rcount);
        if(! _blender_conf->m_g_support_only_rcount)
        {
            return -2;
        }
    }
    
    return 0;
    
}


bool url_decode(const std::string& in, std::string& out)
{
  out.clear();
  out.reserve(in.size());

  for (std::size_t i = 0; i < in.size(); ++i)
  {
    if (in[i] == '%')
    {
      if (i + 3 <= in.size())
      {
        int value;
        std::istringstream is(in.substr(i + 1, 2));
        if (is >> std::hex >> value)
        {
          out += static_cast<char>(value);
          i += 2;
        }
        else
        {
          return false;
        }
      }
      else
      {
        return false;
      }
    }
    else
    {
      out += in[i];
    }
  }

  return true;

}

BlenderServer *g_server = NULL;
void sig_usr1(int signum)  
{
    std::cout<<"HttpSession new:"<<atomic32_read(&blender::_new_cnt)<<std::endl;
    std::cout<<"HttpSession delete:"<<atomic32_read(&blender::_delete_cnt)<<std::endl;
    std::cout<<"just test debug"<<std::endl;
#if 0
    if ( signum == SIGUSR2 )
    {
        if ( NULL != g_server )
        {
            std::cout<<"server stop() ....."<<std::endl;
            g_server->stop();
        }
    }
#endif
}


int main(int argc, char **argv)
{
#if 0
    struct sigaction action, old_action;
    action.sa_handler = sig_usr1;
    sigemptyset(&action.sa_mask); 
    action.sa_flags = 0;
    sigaction(SIGUSR1, NULL, &old_action);  
    if (old_action.sa_handler != SIG_IGN) {  
        sigaction(SIGUSR1, &action, NULL);  
        sigaction(SIGUSR2, &action, NULL);  
    }  
#endif
    
    atomic32_set(&blender::_new_cnt, 0);
    atomic32_set(&blender::_delete_cnt, 0);

    google::InitGoogleLogging(argv[0]);

	BlenderServer server;
    g_server = &server;
	framework::Command cmd(&server);
	return cmd.run(argc, argv);
}

