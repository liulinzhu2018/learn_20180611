/**
 * Copyright(c) 360buy.com
 * Author: chenjianyu@360buy.com
 */
#ifndef DIGEST_H_
#define DIGEST_H_

#include <string>

std::string md5(const std::string &text);
void md5(const char* text, unsigned int test_len, char* md5_text);

std::string sha1(const std::string &text);
std::string sha256(const std::string &text);
std::string sha512(const std::string &text);

std::string base64_encode(const std::string &text);
std::string base64_decode(const std::string &text);

#endif // DIGEST_H_
