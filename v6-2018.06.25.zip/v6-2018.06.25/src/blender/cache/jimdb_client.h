#ifndef __JIMDB_CLIENT_H__
#define __JIMDB_CLIENT_H__

#include <string>
#include <map>
#include <vector>
#include <stdint.h>
#include "compressor.h"

//#define JIMDB_USE_AUTH
#ifdef JIMDB_USE_AUTH
struct _jimdb_client;
#else
class _credis_client;
#endif

namespace blender{
class JimDBClient{
public: 
    JimDBClient();
    ~JimDBClient();

    int Init(const std::string& config_id, const std::string& token, 
            bool need_compress = false, 
            const std::string& compress_val_alog = "", const std::string& key_prex = "");


    int Put(const std::string& key, const char* value, size_t value_len, unsigned int expiration_val, int timeout_ms = 5);
    int Get(const std::string& key, char *&value, size_t &value_length, int timeout_ms = 5);

    int setex(const std::string& key, const std::string &value, unsigned int expiration_val, int timeout_ms=5);
    int get(const std::string& key, std::string &value, int timeout_ms=5);

    int msetex(const std::vector<std::string>& keys, const std::vector<std::string> &values, const std::vector<unsigned int> &expire_times, int timeout_ms=5);
    int mget(const std::vector<std::string>& keys, std::vector<std::string> &values, int timeout_ms=5);

    static std::string md5string(const std::string& text);
    
private:
    std::string _key_prex;
#ifdef JIMDB_USE_AUTH
    _jimdb_client *_redis_client;
#else
    _credis_client *_redis_client;
#endif
    bool _need_compress;
    search_frame::Compressor *_val_compressor;
    bool _is_init_ok;
};
};
#endif
