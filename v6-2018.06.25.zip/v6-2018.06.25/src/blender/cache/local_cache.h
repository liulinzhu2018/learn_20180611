#ifndef __LOCAL_CACHE_H__
#define __LOCAL_CACHE_H__

#include <string>
#include <map>
#include <vector>
#include <stdint.h>
#include <boost/thread/mutex.hpp>
#include "lru_cache.h"

namespace blender{

class LocalCacheData
{
public:
    int _timestamp;
    std::string _data;

    LocalCacheData(std::string _d = "")
    {
        _data = _d;
        _timestamp = time(NULL);
    }

    LocalCacheData(const LocalCacheData &_cd)
    {
        _timestamp = _cd._timestamp;
        _data = _cd._data;
    }

    LocalCacheData& operator=(const LocalCacheData &_cd)
    {
        this->_timestamp = _cd._timestamp;
        this->_data = _cd._data;
        return *this;
    }
};

class LocalCache
{
public: 
    LocalCache(unsigned int limit_size = 50000);
    ~LocalCache();

    static LocalCache* instance() 
    {
        static LocalCache* g_localCache = NULL;
        if ( NULL == g_localCache )
        {
            g_localCache = new LocalCache();
        }
        return g_localCache;
    }

    void resetCapacity(int limit_size);
    int  capacity() { return m_lruCache.capacity(); }
    int  size() { return m_lruCache.size(); }

    int set(const std::string& key, const std::string &value);
    std::string get(const std::string& key, unsigned int expire_time = 0);
private:
    LRUCache<std::string, LocalCacheData> m_lruCache;
    boost::mutex m_mutex;
};
};
#endif
