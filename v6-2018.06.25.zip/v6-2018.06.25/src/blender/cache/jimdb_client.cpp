
#ifdef JIMDB_USE_AUTH
#include "jimdb_auth.ini"
#else
#include "jimdb_noauth.ini"
#endif
