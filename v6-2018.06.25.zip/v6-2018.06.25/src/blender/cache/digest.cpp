#include "digest.h"
#include <openssl/evp.h>

static std::string unite_lines(std::string &text) {
    std::string str;
    char ch;
    int size = text.size();

    for (int i = 0; i < size; i++) {
        ch = text[i];

        if (ch != '\n' && ch != '\r') {
            str += ch;
        }
    }

    return str;
}

static void digest_to_hex_string(const unsigned char *digest, int len, char* text) {
    len = len > 510 ? 510 : len;
    for (int i = 0; i < len; i++) {
        sprintf(&text[2 * i], "%02x", digest[i]);
    }
}

static std::string digest_to_hex_string(const unsigned char *digest, int len) {
    char hexstring[len * 2 + 1];
    len = len > 510 ? 510 : len;

    for (int i = 0; i < len; i++) {
        sprintf(&hexstring[2 * i], "%02x", digest[i]);
    }

    return std::string(hexstring);
}

static std::string __base64_string_format(std::string text) {
    text = unite_lines(text);

    std::string str = "";
    int pos = 0;

    while (text.size() > 0) {
        pos = text.size();
        pos = pos>64 ? 64 : pos;
        str += text.substr(0, pos) + "\n";
        text = text.substr(pos, std::string::npos);
    }

    return str;
}

std::string md5(const std::string &text) {
    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE];
    unsigned int md_len;

    EVP_DigestInit(&mdctx, EVP_md5());
    EVP_DigestUpdate(&mdctx, text.c_str(), text.size());
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);

    /* Somewhere has a defect, and the below's a workaround. */
    std::string hex = digest_to_hex_string(md_value, md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    return hex;
}

void md5(const char* text, unsigned int text_len, char* md5_text) {
    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE];
    unsigned int md_len;

    EVP_DigestInit(&mdctx, EVP_md5());
    EVP_DigestUpdate(&mdctx, text, text_len);
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);

    digest_to_hex_string(md_value, md_len, md5_text);
    EVP_MD_CTX_cleanup(&mdctx);
}

std::string sha1(const std::string &text) {
    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE];
    unsigned int md_len;

    EVP_DigestInit(&mdctx, EVP_sha1());
    EVP_DigestUpdate(&mdctx, text.c_str(), text.size());
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    return digest_to_hex_string(md_value, md_len);
}

std::string sha256(const std::string &text) {
    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE];
    unsigned int md_len;

    EVP_DigestInit(&mdctx, EVP_sha256());
    EVP_DigestUpdate(&mdctx, text.c_str(), text.size());
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    return digest_to_hex_string(md_value, md_len);
}

std::string sha512(const std::string &text) {
    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE];
    unsigned int md_len;

    EVP_DigestInit(&mdctx, EVP_sha512());
    EVP_DigestUpdate(&mdctx, text.c_str(), text.size());
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    return digest_to_hex_string(md_value, md_len);
}

std::string base64_encode(const std::string &text) {
    EVP_ENCODE_CTX ectx;
    int size = text.size() * 2;
    unsigned char out[size];
    int outlen = 0;
    int tlen = 0;

    EVP_EncodeInit(&ectx);
    EVP_EncodeUpdate(&ectx, out, &outlen, (const unsigned char*)text.c_str(), text.size());
    tlen += outlen;
    EVP_EncodeFinal(&ectx, out+tlen, &outlen);
    tlen += outlen;

    return std::string((char*)out, tlen);
}

std::string base64_decode(const std::string &text) {
    std::string _text(text);
    _text = __base64_string_format(_text); // silly, but required

    EVP_ENCODE_CTX ectx;
    int size = _text.size();
    unsigned char out[size];
    int outlen = 0;
    int tlen = 0;

    EVP_DecodeInit(&ectx);
    EVP_DecodeUpdate(&ectx, out, &outlen, (const unsigned char*)_text.c_str(), _text.size());
    tlen += outlen;
    EVP_DecodeFinal(&ectx, out+tlen, &outlen);
    tlen += outlen;

    return std::string((char*)out, tlen);
}

