#include "blender_logger.h"
#include "local_cache.h"

using namespace blender;

LocalCache::LocalCache(unsigned int limit_size)
    : m_lruCache(limit_size)
{
}


LocalCache::~LocalCache()
{
}


void LocalCache::resetCapacity(int limit_size)
{
    if ( limit_size > 0 )
    {
        m_mutex.lock();
        m_lruCache.resetCapacity((size_t)limit_size);
        m_mutex.unlock();
    }
}

int LocalCache::set(const std::string& key, const std::string &value)
{
    m_mutex.lock();
    LocalCacheData cd(value);
    m_lruCache.put(key, cd);
    BLD_DEBUG(NULL, "localcache set:"<<key<<" value_len:"<<value.length());
    m_mutex.unlock();
    return 0;
}


std::string LocalCache::get(const std::string& key, unsigned int expire_time)
{
    m_mutex.lock();
    LocalCacheData opData = m_lruCache.get(key);
    if ( !opData._data.empty() )
    {
        if ( (expire_time < 30) || (time(NULL) - opData._timestamp) < expire_time )
        {
            BLD_DEBUG(NULL, "localcache hit:"<<key<<" value_len:"<<opData._data.length());
            m_mutex.unlock();
            return opData._data;
        }
        BLD_DEBUG(NULL, "localcache hit bug overtime");
    }
    else
    {
        BLD_DEBUG(NULL, "localcache not hit");
    }
    m_mutex.unlock();
    static std::string _empty_data = "";
    return _empty_data;
}

