#include <stdio.h>
#include <sys/types.h>
#include <ifaddrs.h>
#include <netinet/in.h> 
#include <string.h> 
#include <arpa/inet.h>
#include <boost/algorithm/string/replace.hpp>
#include "util/simple_config.h"
#include "util/string_algorithms.h"
#include "ls_config.h"
#include "ls_common.h"
#include <log4cplus/helpers/loglog.h>
#include "openssl/md5.h"
#include <fstream>
#include <iostream>

using namespace logging_server;
std::string Compute_file_md5(const std::string &filename);

int LSConfig::init(const std::string& conf_file, const std::string &appenders_conf_file)
{
    int ret = load_serverinfo(conf_file);
    if ( 0 != ret )
    {
        LOGS_ERROR("load_serverinfo("<<conf_file<<") failed:"<<ret);
        return -1;
    }
    
    ret = load_appenders(appenders_conf_file);
    if ( 0 != ret )
    {
        LOGS_ERROR("load_appenders("<<appenders_conf_file<<") failed:"<<ret);
        return -2;
    }
    return 0;
}


int LSConfig::load_serverinfo(const std::string& conf_file)
{
    SimpleConfig conf;
    if (conf.open(conf_file.c_str()) != 0) 
    {
        LOGS_ERROR("SimpleConfig.open("<<conf_file<<") failed!");
        return -1;
    }

    string servernames = conf.read("server", "servernames", "");
    utils::StringAlgorithms::Split(servernames, ",", _server_names);
    for ( unsigned int i = 0; i < _server_names.size(); i++ )
    {
        ServerInfo serInfo;
        const std::string &_srever_name = _server_names[i];
        serInfo._serverName = _srever_name;
        
        std::string _appender_name = conf.read("server", _srever_name + ".template_appender.name", "");
        if ( !_appender_name.empty() )
        {
            serInfo._appenderName = _appender_name;
        }

        std::string _ndc_filter_str = conf.read("server", _srever_name + ".filter.exclude.ndcs", "");
        if ( !_ndc_filter_str.empty() )
        {
            utils::StringAlgorithms::Split(_ndc_filter_str, ",", serInfo._ndcFilters);
        }

        LOGS_INFO("load_server:"<<_srever_name<<":"<<_appender_name<<":"<<_ndc_filter_str);
        _serverinfo_map[_srever_name] = serInfo;
    }

    global_conf.ump2_path = conf.read("ump2", "path", "");
    global_conf.ump2_cluster = conf.read("ump2", "cluster", "p-search");
    
    return 0;
}


int LSConfig::load_appenders(const std::string &conf_file)
{
    helpers::Properties properties(conf_file);
    helpers::Properties appenderProperties = properties.getPropertySubset("appender.");
    std::vector<tstring> appendersProps = appenderProperties.propertyNames();
    for(std::vector<tstring>::iterator it=appendersProps.begin();
        it != appendersProps.end(); ++it)
    {
        if( it->find( LOG4CPLUS_TEXT('.') ) == tstring::npos )
        {
            tstring factoryName = appenderProperties.getProperty(*it);
            spi::AppenderFactory* factory = spi::getAppenderFactoryRegistry().get(factoryName);
            if (! factory)
            {
                std::string err = "PropertyConfigurator::configureAppenders() - Cannot find AppenderFactory:";
                LOGS_ERROR(err<<factoryName);
                continue;
            }
            _appender_factory_map[*it] = factory;

            helpers::Properties props_subset = appenderProperties.getPropertySubset((*it) + LOG4CPLUS_TEXT("."));
            LOGS_INFO("load_appender:"<<*it<<":"<<factoryName);
            _appender_prop_map[*it] = props_subset;
        }
    }

    return 0;
}


log4cplus::Logger* LSConfig::create_logger(const std::string &ndc)
{
    LOGS_DEBUG("create_logger("<<ndc<<") begin");
    if ( ndc.empty() )
    {
        return NULL;
    }

    log4cplus::Logger* logger = NULL;
#if 0
    std::string logfile = LOG_PATH + ndc + LOG_SUFFIX;
    log4cplus::SharedAppenderPtr _fileAppender(new log4cplus::RollingFileAppender(logfile, 1000*1024*1024, 50, false));
    _fileAppender->setName(ndc);
    const std::string pattern = "[%D{%x %X:%q}] %20l %5p - %m%n";
    std::auto_ptr<log4cplus::Layout> _layout(new log4cplus::PatternLayout(pattern));
    _fileAppender->setLayout( _layout );
    
    log4cplus::SharedAppenderPtr _asyncAppender(new log4cplus::AsyncAppender(_fileAppender, 10000));
    
    logger = new log4cplus::Logger(log4cplus::Logger::getInstance(ndc));
    logger->addAppender(_asyncAppender);
#else
    
    std::string::size_type var_start = ndc.find('-');
    if ( 0 == var_start )
    {
        LOGS_ERROR("No server name of:"<<ndc);
        return NULL;
    }

    std::string serverName;
    if ( var_start == std::string::npos )
    {
        serverName = ndc;
    }
    else
    {
        serverName = ndc.substr(0, var_start);
    }

    LOGS_INFO("create_logger server_name:"<<serverName<<"  ndc:"<<ndc);

    //����Ƿ�����servername
    std::map<std::string, ServerInfo>::iterator it = _serverinfo_map.find( serverName );
    if ( it == _serverinfo_map.end() )
    {
        LOGS_WARN("no config server_name:"<<serverName<<"   ndc:"<<ndc);
        return NULL;
    }

    const ServerInfo &serverInfo = it->second;

    //����ndc�Ƿ�filter
    if ( std::find(serverInfo._ndcFilters.begin(), serverInfo._ndcFilters.end(), ndc) != serverInfo._ndcFilters.end() )
    {
        LOGS_DEBUG("filter ndc:"<<ndc);
        return NULL;
    }

    const std::string &appender_name = serverInfo._appenderName;

    std::map<std::string, spi::AppenderFactory*>::iterator fac_it = _appender_factory_map.find(appender_name);
    if ( fac_it == _appender_factory_map.end() )
    {
        LOGS_WARN("no found AppenderFactory for:"<<appender_name);
        return NULL;
    }
    spi::AppenderFactory* factory = fac_it->second;

    std::map<std::string, helpers::Properties>::iterator app_it = _appender_prop_map.find(appender_name);
    if ( app_it == _appender_prop_map.end() )
    {
        LOGS_WARN("no found Properties for:"<<appender_name);
        return NULL;
    }

    helpers::Properties props_subset = app_it->second;
    try
    {
        //�滻��������
        {
            std::vector<tstring> appendersProps = props_subset.propertyNames();
            for(std::vector<tstring>::iterator it=appendersProps.begin();
                it != appendersProps.end(); ++it)
            {
                std::string value = props_subset.getProperty(*it);
                boost::replace_all(value, "${SERVERNAME}", serverName);
                boost::replace_all(value, "${SERVERNAME_LONG}", ndc);
                props_subset.setProperty(*it, value);
            }
        }

        //
        SharedAppenderPtr appender = factory->createObject(props_subset);
        if (! appender)
        {
            std::string err = "PropertyConfigurator::configureAppenders() - Failed to create appender:";
            helpers::getLogLog().error(err + appender_name);
            LOGS_ERROR(err<<appender_name);
        }
        else
        {
            logger = new log4cplus::Logger(log4cplus::Logger::getInstance(ndc));
            logger->removeAllAppenders();
            logger->addAppender(appender);
        }
    }
    catch(std::exception const & e)
    {
       std::string err = "PropertyConfigurator::configureAppenders()- Error while creating Appender: ";
       LOGS_ERROR(err<<e.what());
    }

#endif
    LOGS_DEBUG("create_logger("<<ndc<<") finished");
    return logger;
}


LoggerPool::~LoggerPool()
{
    _mtx.lock();
    std::map<std::string, log4cplus::Logger*>::iterator mit;
    for ( mit = _map_logger.begin(); mit != _map_logger.end(); mit++ )
    {
        if ( NULL != mit->second )
        {
            delete mit->second;
        }
    }
    _map_logger.clear();
    _mtx.unlock();
}


int LoggerPool::init(const std::string& conf_file, const std::string &appenders_conf_file)
{
    return _lsconfig.init(conf_file, appenders_conf_file);
}


log4cplus::Logger* LoggerPool::getLogger(const std::string &ndc)
{
    if ( ndc.empty() )
    {
        return NULL;
    }

    log4cplus::Logger *logger = NULL;
    std::map<std::string, log4cplus::Logger*>::iterator mit = _map_logger.find(ndc);
    if ( mit != _map_logger.end() )
    {
        return mit->second;
    }

    _mtx.lock();
    LOGS_DEBUG("getLogger() create logger for :" << ndc);
    do{
        mit = _map_logger.find(ndc);
        if ( mit != _map_logger.end() )
        {
            logger = mit->second;
            break;
        }

        logger = _lsconfig.create_logger(ndc);
        _map_logger[ndc] = logger; 
    }while(0);
    _mtx.unlock();
    return logger;
}

bool LoggerManager::timeout_handle()
{
    LOGS_INFO("timeout_handle =====================================");
    std::string new_conf_md5 = Compute_file_md5(_conf_file);
    std::string new_appenders_conf_md5 = Compute_file_md5(_appenders_conf_file);
    if ( !new_conf_md5.empty() && !new_appenders_conf_md5.empty() )
    {
        if ( (new_conf_md5 != _conf_file_md5sum) || (new_appenders_conf_md5 != _appenders_conf_file_md5sum) )
        {
            LOGS_INFO("to be update_config ...");
            if ( 0 == update_config() )
            {
                LOGS_INFO("update_config sucessfull!!!"); 
                _conf_file_md5sum = new_conf_md5;
                _appenders_conf_file_md5sum = new_appenders_conf_md5;
            }
            else
            {
                LOGS_INFO("update_config failed!!!"); 
            }
        }
    }
    else
    {
        LOGS_ERROR("calc md5sum error!");
    }

    return true;
}

std::string md5string(const char *str, int len)
{
    unsigned char md[16];
    MD5((const unsigned char*) str, len, md);
    char md5sum[33];
    for (int i = 0; i < 16; i++) {
       sprintf(md5sum + 2 * i, "%02x", md[i]);
    }
    md5sum[32] = 0;
    std::string ret = md5sum;
    return ret;
}

std::string Compute_file_md5(const std::string &filename)
{
    ifstream fin;
    fin.open(filename.c_str());
    if ( !fin )
    {
        return "";
    }

    std::string buffer;
    std::string line;
    while (!fin.eof())
    {
        getline(fin, line);
        buffer += line;
    }
    
    return md5string(buffer.c_str(), buffer.length());
}

GlobalConfig logging_server::global_conf;

