#ifndef __LS_COMMON_H__
#define __LS_COMMON_H__

enum LOGS_LOG_LEVEL{
    LOGS_LOG_DEBUG = 0,
    LOGS_LOG_INFO  = 1,
    LOGS_LOG_WARN = 2,
    LOGS_LOG_ERROR = 3,
};

#define LOGS_DEBUG(log_event) \
if(g_log_level<=LOGS_LOG_DEBUG){\
    std::cout << __FILE__ << ":" << __LINE__ << "[DEBUG]" << log_event << std::endl;\
}else{}

#define LOGS_INFO(log_event) \
if(g_log_level<=LOGS_LOG_INFO){\
    std::cout << __FILE__ << ":" << __LINE__ << "[INFO]" << log_event << std::endl;\
}else{}

#define LOGS_WARN(log_event) \
if(g_log_level<=LOGS_LOG_WARN){\
    std::cout << __FILE__ << ":" << __LINE__ << "[WARN]" << log_event << std::endl;\
}else{}

#define LOGS_ERROR(log_event) \
if(g_log_level<=LOGS_LOG_ERROR){\
    std::cout << __FILE__ << ":" << __LINE__ << "[ERROR]" << log_event << std::endl;\
}else{}

extern int g_log_level;

#define LOGGINGS_STAT_CONN  "search.loggingserver.conn"
#define LOGGINGS_STAT_RECV  "search.loggingserver.recv"

#endif
