#ifndef __LS_CONFIG_H__
#define __LS_CONFIG_H__

#include <string>
#include <set>
#include <iostream>
#include <boost/lexical_cast.hpp>
#include <log4cplus/configurator.h>
#include <log4cplus/logger.h>
#include <log4cplus/layout.h>
#include <log4cplus/thread/syncprims.h>
#include <log4cplus/helpers/socket.h>
#include <log4cplus/thread/threads.h>
#include <log4cplus/spi/loggingevent.h>
#include <log4cplus/spi/factory.h>
#include "blender_timer_handler.h"

using namespace log4cplus;

namespace logging_server{
class LSConfig{
public:
    LSConfig(){}
    ~LSConfig(){}

    int init(const std::string& conf_file, const std::string &appenders_conf_file);	

	log4cplus::Logger* create_logger(const std::string &ndc);
private:
	int load_serverinfo(const std::string& conf_path);
	int load_appenders(const std::string &conf_file);
	

	struct ServerInfo
	{
		std::string _serverName;
		std::string _appenderName;
		std::vector<std::string> _ndcFilters;
	};
private:
	std::vector<std::string> _server_names;
	std::map<std::string, ServerInfo> _serverinfo_map;

	std::map<std::string, helpers::Properties> _appender_prop_map;
	std::map<std::string, spi::AppenderFactory*> _appender_factory_map;
};


class LoggerPool
{
public:
    LoggerPool (){}
    virtual ~LoggerPool();
	int init(const std::string& conf_file, const std::string &appenders_conf_file);

    log4cplus::Logger* getLogger(const std::string &ndc);
private:
    std::map<std::string, log4cplus::Logger*> _map_logger;
    log4cplus::thread::Mutex _mtx;
		
	LSConfig _lsconfig;

};

class LoggerManager : public blender::BlenderTimerHandler
{
public:
	LoggerManager() 
		: BlenderTimerHandler()
        , _loggerPool(NULL)
		, _old_loggerPool(NULL)
		{}

	static LoggerManager* instance()
	{
		static LoggerManager g_instance;
		return &g_instance;
	}

	int init(const std::string& conf_file, const std::string &appenders_conf_file)
	{
		_conf_file = conf_file;
		_appenders_conf_file = appenders_conf_file;
        blender::BlenderTimerHanderManager::instance()->start();
		return update_config();
	}

	~LoggerManager()
	{
		if ( NULL != _old_loggerPool )
		{
			delete _old_loggerPool;
			_old_loggerPool = NULL;
		}
		if ( NULL != _loggerPool )
		{
			delete _loggerPool;
			_loggerPool = NULL;
		}
	}

	log4cplus::Logger* getLogger(const std::string &ndc)
	{
		if ( NULL != _loggerPool )
		{
			return _loggerPool->getLogger(ndc);
		}
        return NULL;
	}

	int update_config()
	{
		LoggerPool *newPool = new LoggerPool();
		int ret = newPool->init(_conf_file, _appenders_conf_file);
		if ( 0 != ret )
		{
			printf("loggerPool->init(%s,%s) failed:%d\n", _conf_file.c_str(), _appenders_conf_file.c_str(), ret);
			return -1;
		}
		
		if ( NULL != _old_loggerPool )
		{
			delete _old_loggerPool;
		}

		_old_loggerPool = _loggerPool;
		_loggerPool = newPool;
		return 0;
	}

    //定时器间隔时间
    virtual uint64_t interval_msecs() const { return 1 * 60 * 1000; }
	
    //Return: true:  定时器继续
    //           false: 停止定时器，如果需要启动，需要调用restartTimer
    virtual bool timeout_handle();
private:
	LoggerPool *_loggerPool;
	LoggerPool *_old_loggerPool;
	std::string _conf_file;
	std::string _appenders_conf_file;
	std::string _conf_file_md5sum;
	std::string _appenders_conf_file_md5sum;
};


class GlobalConfig
{
public:
    std::string ump2_path;
    std::string ump2_cluster;
};

extern GlobalConfig global_conf;

};
#endif
