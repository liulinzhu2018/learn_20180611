// Module:  LOG4CPLUS
// File:    logging_server.cxx
// Created: 5/2003
// Author:  Tad E. Smith
//
//
// Copyright 2003-2015 Tad E. Smith
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <cstdlib>
#include <list>
#include <iostream>
#include <ifaddrs.h>
#include <netinet/in.h> 
#include <arpa/inet.h>
#include <log4cplus/configurator.h>
#include <log4cplus/socketappender.h>
#include <log4cplus/asyncappender.h>
#include <log4cplus/fileappender.h>
#include <log4cplus/helpers/socket.h>
#include <log4cplus/thread/threads.h>
#include <log4cplus/spi/loggingevent.h>
#include <log4cplus/logger.h>
#include <log4cplus/layout.h>
#include <log4cplus/thread/syncprims.h>
#include "ls_config.h"
#include "ls_common.h"
#include "ump_report.h"
#include "util/timer.h"
#include "jdsz_logtrace_manager.h"

int g_log_level = 1;
namespace logging_server
{

typedef std::list<log4cplus::thread::AbstractThreadPtr> ThreadQueueType;


class ReaperThread
    : public log4cplus::thread::AbstractThread
{
public:
    ReaperThread (log4cplus::thread::Mutex & mtx_,
        log4cplus::thread::ManualResetEvent & ev_,
        ThreadQueueType & queue_)
        : mtx (mtx_)
        , ev (ev_)
        , queue (queue_)
        , stop (false)
    { }

    virtual
    ~ReaperThread ()
    { }

    virtual void run ();

    void signal_exit ();

private:
    log4cplus::thread::Mutex & mtx;
    log4cplus::thread::ManualResetEvent & ev;
    ThreadQueueType & queue;
    bool stop;
};


typedef log4cplus::helpers::SharedObjectPtr<ReaperThread> ReaperThreadPtr;


void
ReaperThread::signal_exit ()
{
    log4cplus::thread::MutexGuard guard (mtx);
    stop = true;
    ev.signal ();
}


void
ReaperThread::run ()
{
    ThreadQueueType q;

    while (true)
    {
        ev.timed_wait (30 * 1000);

        {
            log4cplus::thread::MutexGuard guard (mtx);

            // Check exit condition as the very first thing.
            if (stop)
            {
                LOGS_DEBUG("Reaper thread is stopping...");
                return;
            }

            ev.reset ();
            q.swap (queue);
        }

        if (! q.empty ())
        {
            LOGS_DEBUG("Reaper thread is reaping " << q.size () << " threads.");

            for (ThreadQueueType::iterator it = q.begin (), end_it = q.end ();
                 it != end_it; ++it)
            {
                AbstractThread & t = **it;
                t.join ();
            }

            q.clear ();
        }
    }
}



/**
   This class wraps ReaperThread thread and its queue.
 */
class Reaper
{
public:
    Reaper ()
    {
        reaper_thread = ReaperThreadPtr (new ReaperThread (mtx, ev, queue));
        reaper_thread->start ();
    }

    ~Reaper ()
    {
        reaper_thread->signal_exit ();
        reaper_thread->join ();
    }

    void visit (log4cplus::thread::AbstractThreadPtr const & thread_ptr);

private:
    log4cplus::thread::Mutex mtx;
    log4cplus::thread::ManualResetEvent ev;
    ThreadQueueType queue;
    ReaperThreadPtr reaper_thread;
};


void
Reaper::visit (log4cplus::thread::AbstractThreadPtr const & thread_ptr)
{
    log4cplus::thread::MutexGuard guard (mtx);
    queue.push_back (thread_ptr);
    ev.signal ();
}


class ClientThread
    : public log4cplus::thread::AbstractThread
{
public:
    ClientThread(log4cplus::helpers::Socket clientsock_, Reaper & reaper_)
        : self_reference (log4cplus::thread::AbstractThreadPtr (this))
        , clientsock(clientsock_)
        , reaper (reaper_)
    {
        LOGS_INFO("Received a client connection!!!!");
        ump_report::report_tp(LOGGINGS_STAT_CONN".size", g_conn_size, true);
        jdsz_logtrace::Trace_value(LOGGINGS_STAT_CONN, g_conn_size);
    }

    ~ClientThread()
    {
        LOGS_INFO("Client connection closed.");
        g_conn_size -= 1;
        ump_report::report_tp(LOGGINGS_STAT_CONN".size", g_conn_size, true);
        jdsz_logtrace::Trace_value(LOGGINGS_STAT_CONN, g_conn_size);
    }

    virtual void run();

    static int g_conn_size;
private:
    log4cplus::thread::AbstractThreadPtr self_reference;
    log4cplus::helpers::Socket clientsock;
    Reaper & reaper;
};

int logging_server::ClientThread::g_conn_size = 0;

void
logging_server::ClientThread::run()
{
    try
    {
        while (1)
        {
            if (!clientsock.isOpen())
                break;

            log4cplus::helpers::SocketBuffer msgSizeBuffer(sizeof(unsigned int));
            if (!clientsock.read(msgSizeBuffer))
                break;

            long us_start = getMicroTime();
            unsigned int msgSize = msgSizeBuffer.readInt();

            log4cplus::helpers::SocketBuffer buffer(msgSize);
            if (!clientsock.read(buffer))
                break;

            log4cplus::spi::InternalLoggingEvent event
                = log4cplus::helpers::readFromBuffer(buffer);
            LOGS_DEBUG("GET event from :" << event.getNDC());

            log4cplus::Logger *logger = LoggerManager::instance()->getLogger(event.getNDC());
            if ( NULL != logger )
            {
                logger->callAppenders(event);
            }
            else
            {
                LOGS_DEBUG("GET logger failed :" << event.getNDC());
            }

            long us_end = getMicroTime();
            ump_report::report_tp(LOGGINGS_STAT_RECV ".call", us_end-us_start, true);
            jdsz_logtrace::Trace_latency(LOGGINGS_STAT_RECV ".latency", us_end-us_start);
            jdsz_logtrace::Trace_qps(LOGGINGS_STAT_RECV, 1);
        }
    }
    catch (...)
    {
        reaper.visit (self_reference);
        self_reference = log4cplus::thread::AbstractThreadPtr ();
        throw;
    }

    reaper.visit (self_reference);
    self_reference = log4cplus::thread::AbstractThreadPtr ();
}

} // namespace logging_server



int
main(int argc, char** argv)
{
    log4cplus::initialize ();

    if(argc < 2) {
        std::cout << "Usage: port [log_level(0-debug,1-info(default),2-warn,3-error)] [conf=logging_server.conf] [appender_conf=logging_appenders.conf]" << std::endl;
        return 1;
    }
    int port = std::atoi(argv[1]);
    if ( argc >= 3 )
    {
        g_log_level = std::atoi(argv[2]);
        if ( g_log_level < 0 || g_log_level > 3 )
        {
            g_log_level = 1;
        }
    }

    ump_report::init_ump("logging_server");

    int ret = 0;
    if ( argc >= 5 )
    {
        ret = logging_server::LoggerManager::instance()->init(argv[3], argv[4]);
    }
    else
    {
        ret = logging_server::LoggerManager::instance()->init("./logging_server.conf", "./logging_appenders.conf");
    }
    if ( 0 != ret )
    {
        printf("LoggerManager::init() failed:%d\n", ret);
        return 0;
    }

    //初始化性能监控agent
    ret = -1;
    std::string trace_agent = logging_server::global_conf.ump2_path;
    if ( !trace_agent.empty() ) {
        char host[512];
        if (gethostname(host, 512) == 0) {
            std::string hostname = std::string("hostname=") + host + ",cluster=" + logging_server::global_conf.ump2_cluster;
            ret = jdsz_logtrace::JDSZ_LOGTRACE_INIT(hostname, trace_agent, 1, 100);
        }
    }
    if ( 0 != ret )
    {
        printf("init_agent_failed: trace_agent(%s) empty or gethostname failed\n", trace_agent.c_str());
        return -1;
    }

 #if 0
    const log4cplus::tstring configFile = LOG4CPLUS_C_STR_TO_TSTRING(argv[2]);

    log4cplus::PropertyConfigurator config(configFile);
    config.configure();
#endif
    log4cplus::helpers::ServerSocket serverSocket(port);
    if (!serverSocket.isOpen()) {
        std::cerr << "Could not open server socket, maybe port "
            << port << " is already in use." << std::endl;
        return 2;
    }

    logging_server::Reaper reaper;

    for (;;)
    {
        logging_server::ClientThread *thr =
            new logging_server::ClientThread(serverSocket.accept(), reaper);
        thr->start();
    }

    log4cplus::Logger::shutdown();

    return 0;
}
