#ifndef _BLENDER_SERVER_H_
#define _BLENDER_SERVER_H_

#include "server/base_server.h"
#include "server/http_session.h"
#include "blender_master.h"
#include "task_wrapper.h"
#include <stdio.h>

namespace blender {

class BlenderServer : public blender::BaseServer
{
public:
	BlenderServer();
	virtual ~BlenderServer();

	int init(const char *ini);
	int work(blender::TaskWrapper* wrapper);
	int work_cmd(HttpSession* session);
    int32_t start();
	void stop();
	void wait();

    virtual bool is_busy(char **busy_info) const;

    int sendtoClient(BlenderRequest *request);
	int CheckUrl(std::string rcUrl);
private:
    int HandleNewRequest(HttpSession_ptr session);
    int HandleRetRequest(blender::TaskWrapper * wrapper);
};

};
#endif

