
//
// server.hpp
// ~~~~~~~~~~
//
// Copyright (c) 2003-2008 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef HTTP_SERVER3_SERVER_HPP
#define HTTP_SERVER3_SERVER_HPP

#include <boost/asio.hpp>
#include <string>
#include <vector>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include "connection.hpp"
#include "request_handler.hpp"
#include "i_core_worker.hpp"
#include <boost/date_time/posix_time/posix_time_types.hpp>
//#include <boost/date_time/posix_time/posix_time.hpp>

#define USING_TIME_OUT 1

namespace http {
namespace server31 {

/// The top-level class of the HTTP server.
class server
  : private boost::noncopyable
{
public:
  explicit server(
	int port,  const std::string &offline,
	std::size_t thread_pool_size=2,
	#if USING_TIME_OUT
	int timeout=-1,
	#endif
	const std::string& defaultReturnType="xml" // 默认返回网页类型
    , int http_keepalive_overtime = 0 //0表示不启用keep_alive
	);

    ~server();

	void SetCoreWorker(I_CoreWork *refCoreWorker)
	{
		if (NULL == refCoreWorker)
		{
			throw std::bad_exception();
		}
		request_handler_.SetCoreWorker(refCoreWorker);
	}

  /// Run the server's io_service loop.
  void run();
  void runAndSet(I_CoreWork *_server_core);
#ifdef _AD_SERVER_V2_
  void run(I_CoreWork *_server_core);
#endif

  /// Stop the server.
  void stop();

  void wait();

  void closeAcceptor();

private:
  /// Handle completion of an asynchronous accept operation.
  void handle_accept(const boost::system::error_code& e);

  void openSocket();

  /// The io_service used to perform asynchronous operations.
  boost::asio::io_service io_service_;

  /// The number of threads that will call io_service::run().
  std::size_t thread_pool_size_;

  /// Acceptor used to listen for incoming connections.
  boost::asio::ip::tcp::acceptor* acceptor_;

  boost::asio::deadline_timer* timer_;

  std::string defaultReturnType;
  /// The next connection to be accepted.
  connection_ptr new_connection_;

  std::vector<boost::shared_ptr<boost::thread> > threads;

  int listen_port_;
  int timeout_;

  int keepalive_overtime_;

  /// The handler for all incoming requests.
  request_handler request_handler_;
};

} // namespace server31
} // namespace http

#endif // HTTP_SERVER3_SERVER_HPP


