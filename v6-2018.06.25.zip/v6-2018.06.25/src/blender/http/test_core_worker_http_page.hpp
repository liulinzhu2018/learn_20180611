#ifndef HTTP_SERVER_I_CORE_WORKER_HPP
#define HTTP_SERVER_I_CORE_WORKER_HPP

#include "i_core_worker.hpp"

namespace http {

	class HttpCoreWork
		:public I_CoreWork
	{
	public:
		HttpCoreWork()
		{
			_doc_root=".";
		}

		HttpCoreWork(const std::string& doc_root)
			:_doc_root(doc_root)
		{}

		virtual ~HttpCoreWork(){}

		/////�ṩ��ͨhttp����
		virtual bool Work(const std::string& request, std::string& rep_string)
		{
			std::cout<<"request_handler::handle_request"<<std::endl;
			// Open the file to send back.
			std::string full_path = request;
			rep_string = "";
			std::ifstream is(full_path.c_str(), std::ios::in | std::ios::binary);
			if (!is)
			{
				//not_found
				return false;
			}	
			char buf[512];
			while (is.read(buf, sizeof(buf)).gcount() > 0)
				rep_string = rep_string + buf;

			return true;
		}


	private:
		 std::string _doc_root;
	};

}

#endif
