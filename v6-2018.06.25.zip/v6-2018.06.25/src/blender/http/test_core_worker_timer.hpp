#ifndef HTTP_SERVER_I_TIMER_CORE_WORKER_HPP
#define HTTP_SERVER_I_TIMER_CORE_WORKER_HPP

#include "i_core_worker.hpp"

namespace http {

	class Timer_CoreWork
		:public I_CoreWork
	{
	public:
		virtual ~Timer_CoreWork(){}

		/////�ṩ��ͨhttp����
		virtual bool Work(const std::string& request, std::string& rep_string)
		{
			// Open the file to send back.
			rep_string = make_daytime_string();

			return true;
		}

	private:
		std::string make_daytime_string()
		{
		  using namespace std; // For time_t, time and ctime;
		  time_t now = time(0);
		  return ctime(&now);
		}
	};

}

#endif
