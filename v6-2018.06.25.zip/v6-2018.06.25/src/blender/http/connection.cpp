//
// connection.cpp
// ~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2008 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include "connection.hpp"
#include <vector>
#include <boost/bind.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp> 
#include "request_handler.hpp"
#include <iostream>

namespace http {
namespace server31 {

atomic32_t connection::g_connection_cnt = {0};

connection::connection(
	boost::asio::io_service& io_service,
    request_handler& handler, 
	const std::string& tmpdefaultReturnType
#if defined(USE_HTTP_KEEPALIVE_V1)
    , int keepalive_overtime
#endif
    )
  : strand_(io_service),
    socket_(io_service),
    request_handler_(handler),
	defaultReturnType(tmpdefaultReturnType),
    is_new_request_(true)
    , keepalive_(false)
#if defined(USE_HTTP_KEEPALIVE_V1)
    , keepalive_overtime_sec_(keepalive_overtime)
    , keepalive_timer_(io_service)
#endif
{
    atomic32_inc(&g_connection_cnt);
}


connection::~connection()
{
    atomic32_dec(&g_connection_cnt);
}

boost::asio::ip::tcp::socket& connection::socket()
{
  return socket_;
}

void connection::start()
{
  socket_.async_read_some(boost::asio::buffer(buffer_),
      strand_.wrap(
        boost::bind(&connection::handle_read, shared_from_this(),
          boost::asio::placeholders::error,
          boost::asio::placeholders::bytes_transferred)));
}

void connection::send_reply()
{
    if ( keep_alive() )
    {
#if defined(USE_HTTP_KEEPALIVE_V1)
        header head1 = {std::string("Connection"), std::string("keep-alive")};
        reply_.headers.push_back(head1);
        header head2 = {"Keep-Alive", boost::lexical_cast<std::string>(keepalive_overtime_sec_)};
        reply_.headers.push_back(head2);
#endif
    }
    else
    {
        header head1 = {"Connection", "close"};
        reply_.headers.push_back(head1);
    }
      boost::asio::async_write(socket_, reply_.to_buffers(),
      strand_.wrap(
        boost::bind(&connection::handle_write, shared_from_this(),
          boost::asio::placeholders::error)));
}

void connection::handle_read(const boost::system::error_code& e,
    std::size_t bytes_transferred)
{
  if (!e)
  {
    HTTP_TRACE("handle_read size:%lu  :%p  time:%lu", bytes_transferred, this, time(NULL));
    boost::tribool result;
    if ( is_new_request_ )
    {
        request_.reset();
        request_parser_.reset();
    }
    is_new_request_ = false;
    boost::tie(result, boost::tuples::ignore) = request_parser_.parse(
        request_, buffer_.data(), buffer_.data() + bytes_transferred);

    if (result)
    {
      HTTP_TRACE("handle_read result size:%lu  :%p  time:%lu", bytes_transferred, this, time(NULL));
#if defined(USE_HTTP_KEEPALIVE_V1)
      keepalive_timer_.cancel();
      handle_request_header();
#endif
      int ret = request_handler_.handle_request(shared_from_this(),request_,reply_, defaultReturnType);
      if (ret != 0)
      {
        //std::cout<<"handle read"<<std::endl;
          boost::asio::async_write(socket_, reply_.to_buffers(),
              strand_.wrap(
                boost::bind(&connection::handle_write, shared_from_this(),
                  boost::asio::placeholders::error)));
        }
       is_new_request_ = true;
    }
    else if (!result)
    {
      HTTP_TRACE("handle_read !result size:%lu  :%p  time:%lu", bytes_transferred, this, time(NULL));
      reply_ = reply::stock_reply(reply::bad_request);
      boost::asio::async_write(socket_, reply_.to_buffers(),
          strand_.wrap(
            boost::bind(&connection::handle_write, shared_from_this(),
              boost::asio::placeholders::error)));
    }
    else
    {
      HTTP_TRACE("handle_read result-x size:%lu  :%p  time:%lu", bytes_transferred, this, time(NULL));
      socket_.async_read_some(boost::asio::buffer(buffer_),
          strand_.wrap(
            boost::bind(&connection::handle_read, shared_from_this(),
              boost::asio::placeholders::error,
              boost::asio::placeholders::bytes_transferred)));
    }
  }
  else
  {
      HTTP_TRACE("!!!!!handle_read failed size:%lu  :%p  time:%lu", bytes_transferred, this, time(NULL));
  }

  // If an error occurs then no new asynchronous operations are started. This
  // means that all shared_ptr references to the connection object will
  // disappear and the object will be destroyed automatically after this
  // handler returns. The connection class's destructor closes the socket.
}

void connection::handle_write(const boost::system::error_code& e)
{
  if (!e)
  {
    
    // Initiate graceful connection closure.
    if ( keep_alive() )
    {
#if defined(USE_HTTP_KEEPALIVE_V1)
        HTTP_TRACE("handle_write keepalive start +++++++++++++ %p  time:%lu", this, time(NULL));
        keepalive_timer_.expires_from_now(boost::posix_time::seconds(keepalive_overtime_sec_));
        keepalive_timer_.async_wait(
            strand_.wrap(
                boost::bind(&connection::keepalive_timeout, shared_from_this(),
                boost::asio::placeholders::error
                )));
#endif
        socket_.async_read_some(boost::asio::buffer(buffer_),
            strand_.wrap(
                boost::bind(&connection::handle_read, shared_from_this(),
                boost::asio::placeholders::error,
                boost::asio::placeholders::bytes_transferred)));
    }
    else
    {
        close(true);
    }
  }

  // No new asynchronous operations are started. This means that all shared_ptr
  // references to the connection object will disappear and the object will be
  // destroyed automatically after this handler returns. The connection class's
  // destructor closes the socket.
}

#if defined(USE_HTTP_KEEPALIVE_V1)
void connection::keepalive_timeout(const boost::system::error_code& e)
{
    if ( !e )
    {
        HTTP_TRACE("handle_write keepalive stop ------------- %p  time:%lu", this, time(NULL));
        close(false);
    }
}
#endif

void connection::close(bool wait_send_ok)
{
    if ( wait_send_ok )
    {
        boost::system::error_code ignored_ec;
        socket_.shutdown(boost::asio::ip::tcp::socket::shutdown_both, ignored_ec);
    }
    else
    {
        socket_.close();
    }
    keepalive_ = false;
}

void connection::handle_request_header()
{
#if !defined(USE_HTTP_KEEPALIVE_V1) and !defined(USE_HTTP_KEEPALIVE_V2)
    return;
#endif
    std::string connection_value;
    std::vector<header>::iterator it = request_.headers.begin();
    for ( ; it != request_.headers.end(); it++ )
    {
        if ( it->name == "Connection" )
        {
            connection_value = boost::to_lower_copy(it->value);
            break;
        }
    }

    if ( request_.http_version_major == 1 && request_.http_version_minor == 0 )
    {
        if ( connection_value == "keep-alive" )
        {
            keepalive_ = true;
        }
    }
    if ( request_.http_version_major == 1 && request_.http_version_minor == 1 )
    {
        if ( connection_value != "close" )
        {
            keepalive_ = true;
        }
    }
}


std::string connection::remote_info() const
{
    std::stringstream ss;
    ss << " client:";
    try
    {
        boost::asio::ip::tcp::endpoint ep = socket_.remote_endpoint();
        ss << ep;
    }
    catch(...)
    {
        ss << "unkown";
    }

    ss << " X-Forwarded-For:" << http_header("x-forwarded-for");
    return ss.str();
}


std::string connection::http_header(const std::string &key) const
{
    std::string nkey = boost::to_lower_copy(key);
    for ( size_t i = 0; i < request_.headers.size(); i++ )
    {
        if ( nkey == boost::to_lower_copy(request_.headers[i].name) )
        {
            return request_.headers[i].value;
        }
    }
    return "";
}


boost::asio::ip::tcp::endpoint connection::remote_endpoint() const
{
    return socket_.remote_endpoint();
}


} // namespace server31
} // namespace http
