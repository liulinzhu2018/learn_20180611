//
// request_handler.cpp
// ~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2008 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include "request_handler.hpp"
#include <fstream>
#include <sstream>
#include <string>
#include <unistd.h>
#include <boost/lexical_cast.hpp>
#include "mime_types.hpp"
#include "reply.hpp"
#include "request.hpp"
#include "connection.hpp"
#include "i_core_worker.hpp"

namespace http {
namespace server31 {


int request_handler::handle_request(connection_ptr conn, const request& req, reply& rep,
	const std::string& defaultType)
{
	// Decode url to path.
	std::string request_path;

    HTTP_TRACE("handle_request %p", conn.get());
    HTTP_TRACE("request{");
    HTTP_TRACE("    method:%s", req.method.c_str());
    HTTP_TRACE("    uri:%s", req.uri.c_str());
    HTTP_TRACE("    http_version_major:%d", req.http_version_major);
    HTTP_TRACE("    http_version_minor:%d", req.http_version_minor);
    HTTP_TRACE("    headers:");
    for ( size_t i = 0; i < req.headers.size(); i++ )
    {
        HTTP_TRACE("        %s\t:%s", req.headers[i].name.c_str(), req.headers[i].value.c_str());
    }
    HTTP_TRACE("}");

	if (!url_decode(req.uri, request_path))
	{
		rep = reply::stock_reply(reply::bad_request);
        HTTP_TRACE("!!!!!!!!!!!!!!!!! !url_decode() bad_request ");
		return -1;
	}

	if (request_path.compare("/status") == 0) {
		if (access(_offline.c_str(), F_OK) != 0) {
			rep.content.append("ok");
			rep.status = reply::ok;
			return -1;
		}
		else {
			rep = reply::stock_reply(reply::not_found);
			return -1;
		}
	}

	// Request path must be absolute and not contain "..".
	if (request_path.empty() || request_path[0] != '/' )
//	  || request_path.find("..") != std::string::npos)
	{
		rep = reply::stock_reply(reply::bad_request);
        HTTP_TRACE("!!!!!!!!!!!!!!!!! request_path:%s bad_request ", request_path.c_str());
		return -1;
	}

	// If path ends in slash (i.e. is a directory) then add "index.html".
	if (request_path[request_path.size() - 1] == '/')
	{
		//request_path += "index.html";
		request_path += "result.xml";
	}

	// Determine the file extension.
	std::size_t last_slash_pos = request_path.find_last_of("/");

	if (0 == last_slash_pos)
	{
		// ����ͷ��һ����/ʱ
		request_path = request_path.substr(1);
	}

    //std::cout<<"handle_request:usecount:"<<conn.use_count()<<std::endl;

    return m_coreWorker->push_request(conn, request_path);

}

bool request_handler::url_decode(const std::string& in, std::string& out)
{
	out = in;
	return true;

  out.clear();
  out.reserve(in.size());
  for (std::size_t i = 0; i < in.size(); ++i)
  {
    if (in[i] == '%')
    {
      if (i + 3 <= in.size())
      {
        int value;
        std::istringstream is(in.substr(i + 1, 2));
        if (is >> std::hex >> value)
        {
          out += static_cast<char>(value);
          i += 2;
        }
        else
        {
          return false;
        }
      }
      else
      {
        return false;
      }
    }
	#if 0
    else if (in[i] == '+')
    {
      out += ' ';
    }
	#endif
    else
    {
      out += in[i];
    }
  }
  return true;
}

} // namespace server31
} // namespace http


