//
// connection.hpp
// ~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2008 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef HTTP_SERVER3_CONNECTION_HPP
#define HTTP_SERVER3_CONNECTION_HPP

#include <boost/asio.hpp>
#include <boost/array.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/asio/deadline_timer.hpp>
#include "reply.hpp"
#include "request.hpp"
#include "request_handler.hpp"
#include "request_parser.hpp"
#include "atomic.h"

namespace http {
namespace server31 {

/// Represents a single connection from a client.
class connection
  : public boost::enable_shared_from_this<connection>,
    private boost::noncopyable
{
public:
  /// Construct a connection with the given io_service.
  explicit connection(boost::asio::io_service& io_service,
      request_handler& handler, const std::string& tmpdefaultReturnType
#if defined(USE_HTTP_KEEPALIVE_V1)
        , int keepalive_overtime
#endif
        );
  ~connection();

  /// Get the socket associated with the connection.
  boost::asio::ip::tcp::socket& socket();

  /// Start the first asynchronous operation for the connection.
  void start();
  void close(bool wait_send_ok = true);

  request* get_request(){return &request_;}
  reply* get_reply(){return &reply_;}
  const std::string& get_reply_type()const {return defaultReturnType;}
  void send_reply();

  bool keep_alive() const { 
#if defined(USE_HTTP_KEEPALIVE_V1)
      return keepalive_ & (keepalive_overtime_sec_ > 0); 
#else
      return keepalive_; 
#endif
  }

    std::string remote_info() const;
    std::string http_header(const std::string &key) const;
    boost::asio::ip::tcp::endpoint remote_endpoint() const;

    static int connections_count() { return atomic32_read(&g_connection_cnt);}

private:
    void handle_request_header();

#if defined(USE_HTTP_KEEPALIVE_V1)
    void keepalive_timeout(const boost::system::error_code& e);
#endif

private:
  /// Handle completion of a read operation.
  void handle_read(const boost::system::error_code& e,
      std::size_t bytes_transferred);

  /// Handle completion of a write operation.
  void handle_write(const boost::system::error_code& e);

  /// Strand to ensure the connection's handlers are not called concurrently.
  boost::asio::io_service::strand strand_;

  /// Socket for the connection.
  boost::asio::ip::tcp::socket socket_;

  /// The handler used to process the incoming request.
  request_handler& request_handler_;

  /// Buffer for incoming data.
  boost::array<char, 8192> buffer_;

  /// The incoming request.
  request request_;

  /// The parser for the incoming request.
  request_parser request_parser_;

  /// The reply to be sent back to the client.
  reply reply_;

  std::string defaultReturnType;

  bool is_new_request_;
  bool keepalive_;
#if defined(USE_HTTP_KEEPALIVE_V1)
  int keepalive_overtime_sec_;
  boost::asio::deadline_timer keepalive_timer_;
#endif

public:  
    static atomic32_t g_connection_cnt;
  //static atomic32_t _new_cnt;
  //static atomic32_t _delete_cnt;
};

typedef boost::shared_ptr<connection> connection_ptr;

} // namespace server31
} // namespace http

#endif // HTTP_SERVER3_CONNECTION_HPP
