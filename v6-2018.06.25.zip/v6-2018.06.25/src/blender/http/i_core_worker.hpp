#ifndef HTTP_SERVER_I_WORK_HPP
#define HTTP_SERVER_I_WORK_HPP

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <map>
#include <boost/thread.hpp> 
#include "connection.hpp"

namespace http {
namespace server31{
    /*
    class myreq_session{
    public:
        myreq_session(http::server31::connection_ptr conn, std::string request_path):_conn(conn), _request_path(request_path){}
    public:
        http::server31::connection_ptr _conn;
        std::string _request_path;
    };
    */

	class I_CoreWork
	{
	public:
        I_CoreWork();
		virtual ~I_CoreWork(){}

		/////�ṩ��ͨhttp����
		virtual int push_request(http::server31::connection_ptr conn, std::string request_path) = 0;
        //myreq_session* pop_request();
    public:
        std::map<boost::thread::id, std::size_t> m_thread_id_to_index_map;
	};
}
} // namespace http
#endif // HTTP_SERVER_I_WORK_HPP
