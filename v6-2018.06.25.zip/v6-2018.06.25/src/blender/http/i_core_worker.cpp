#include "i_core_worker.hpp"

using namespace http::server31;

I_CoreWork::I_CoreWork()
{
    //_session_queue = new util::Queue<myreq_session*>(10);
}

/*
int I_CoreWork::push_request(connection_ptr  conn, std::string request_path)
{
    //std::cout<<"I_CoreWork:usecount:"<<conn.use_count()<<std::endl;
    myreq_session* my_session = new myreq_session(conn, request_path);
    int ret = _session_queue->enqueue(my_session);
    if (0 != ret)
    {
        //std::cout<<"enqueue failed"<<request_path<<std::endl;
        delete my_session;
    }
    return ret;
}

myreq_session* I_CoreWork::pop_request()
{
    myreq_session* ret = NULL;
    _session_queue->dequeue(ret);
    return ret;
}
*/

