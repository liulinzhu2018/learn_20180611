//
// server.cpp
// ~~~~~~~~~~
//
// Copyright (c) 2003-2008 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include "server.hpp"
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include <vector>

namespace http {
namespace server31 {

using boost::asio::ip::tcp;

server::server(
	int port, const std::string &offline, 
	std::size_t thread_pool_size,
	#if USING_TIME_OUT
	int timeout,
	#endif
	const std::string& defaultReturnType
    , int http_keepalive_overtime
	)
  : thread_pool_size_(thread_pool_size),
	defaultReturnType(defaultReturnType),
    listen_port_(port)
	#if USING_TIME_OUT
	,
	timeout_(timeout)
	#endif
    , keepalive_overtime_(http_keepalive_overtime)
{
	request_handler_.setOffline(offline);
}

server::~server()
{
    if (acceptor_)
        delete acceptor_;

    if (timer_)
        delete timer_;
}

void server::run()
{
    boost::asio::io_service::work work(io_service_);
    // Create a pool of threads to run all of the io_services.
    //std::vector<boost::shared_ptr<boost::thread> > threads;
    for (std::size_t i = 0; i < thread_pool_size_; ++i)
    {
        boost::shared_ptr<boost::thread> thread(new boost::thread(
                    boost::bind(&boost::asio::io_service::run, &io_service_)));
        threads.push_back(thread);
    }

    openSocket();

    // Wait for all threads in the pool to exit.
    //for (std::size_t i = 0; i < threads.size(); ++i)
    //    threads[i]->join();
}

void server::runAndSet(I_CoreWork *_server_core)
{
    boost::asio::io_service::work work(io_service_);
    // Create a pool of threads to run all of the io_services.
    //std::vector<boost::shared_ptr<boost::thread> > threads;
    for (std::size_t i = 0; i < thread_pool_size_; ++i)
    {
        boost::shared_ptr<boost::thread> thread(new boost::thread(
                    boost::bind(&boost::asio::io_service::run, &io_service_)));
        threads.push_back(thread);

        // record thread id and its internal index
        boost::thread::id tid = thread->get_id();
        _server_core->m_thread_id_to_index_map[tid] = i;
    }

    openSocket();

    // Wait for all threads in the pool to exit.
    //for (std::size_t i = 0; i < threads.size(); ++i)
    //    threads[i]->join();
}

#ifdef _AD_SERVER_V2_
void server::run(I_CoreWork *_server_core)
{
    boost::asio::io_service::work work(io_service_);
    // Create a pool of threads to run all of the io_services.
    //std::vector<boost::shared_ptr<boost::thread> > threads;
    for (std::size_t i = 0; i < thread_pool_size_; ++i)
    {
        boost::shared_ptr<boost::thread> thread(new boost::thread(
                    boost::bind(&boost::asio::io_service::run, &io_service_)));
        threads.push_back(thread);

        boost::thread::id tid = thread->get_id();
        _server_core->redis_con_map[tid] = i;
    }

    openSocket();

    // Wait for all threads in the pool to exit.
    //for (std::size_t i = 0; i < threads.size(); ++i)
    //    threads[i]->join();
}
#endif

void server::closeAcceptor()
{
    acceptor_->close();
}

void server::wait()
{
    // Wait for all threads in the pool to exit.
    for (std::size_t i = 0; i < threads.size(); ++i)
        threads[i]->join();

}

void server::stop()
{
    io_service_.stop();
}

void server::handle_accept(const boost::system::error_code& e)
{
    if (!e)
    {
        new_connection_->start();
        new_connection_.reset(
                new connection(io_service_, request_handler_, defaultReturnType
#if defined(USE_HTTP_KEEPALIVE_V1)
                , keepalive_overtime_
#endif
                ));
        acceptor_->async_accept(new_connection_->socket(),
                boost::bind(&server::handle_accept, this,
                    boost::asio::placeholders::error));
    }
}

void server::openSocket()
{
    timer_ = new boost::asio::deadline_timer(io_service_);
    new_connection_.reset(new connection(io_service_, request_handler_, defaultReturnType
#if defined(USE_HTTP_KEEPALIVE_V1)
                , keepalive_overtime_
#endif
                ));
    acceptor_ = new boost::asio::ip::tcp::acceptor(io_service_,tcp::endpoint(tcp::v4(), listen_port_));

    acceptor_->set_option(boost::asio::ip::tcp::acceptor::reuse_address(true));
    acceptor_->listen();
    acceptor_->async_accept(new_connection_->socket(),
            boost::bind(&server::handle_accept, this,
                boost::asio::placeholders::error));

#if USING_TIME_OUT
    if (timeout_ > 0)
    {
        timer_->expires_from_now(boost::posix_time::seconds(timeout_));
        timer_->async_wait(boost::bind(&server::closeAcceptor, this));
    }
#endif

}

} // namespace server31
} // namespace http

