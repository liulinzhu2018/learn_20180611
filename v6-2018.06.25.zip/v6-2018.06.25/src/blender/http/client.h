//
// async_client.cpp
// ~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2008 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef HTTP_CLIENT_HPP
#define HTTP_CLIENT_HPP

#include <iostream>
#include <istream>
#include <ostream>
#include <fstream>
#include <string>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/thread/thread.hpp>
#include <time.h>
#include <vector>
#include <boost/date_time/posix_time/posix_time_types.hpp>
#include <boost/bind.hpp>
//#include "timer.h"
#include <boost/thread/thread.hpp>
using namespace std;

using boost::asio::ip::tcp;

class client
{
public:
	client(string& result,int timeoutmillis,int cid,boost::asio::io_service& io_service,
		const std::string& server,const std::string& port,const std::string& path)
		: resolver_(io_service),
		socket_(io_service),id(cid),
		exit_flag_(false),timer_(io_service),
		timeout_millis(timeoutmillis),
		rs_string(&result)
	{
		// Form the request. We specify the "Connection: close" header so that the
		// server will close the socket after transmitting the response. This will
		// allow us to treat all data up until the EOF as the content.
		std::ostream request_stream(&request_);
		request_stream << "GET " << path << " HTTP/1.0\r\n";
		request_stream << "Host: " << server << "\r\n";
		request_stream << "Accept: */*\r\n";
		request_stream << "Connection: close\r\n\r\n";

		// Start an asynchronous resolve to translate the server and service names
		// into a list of endpoints.
		//tcp::resolver::query query(server, "http");
		tcp::resolver::query query(server, port);
		resolver_.async_resolve(query,
			boost::bind(&client::handle_resolve, this,
			boost::asio::placeholders::error,
			boost::asio::placeholders::iterator));
	}

private:
	void handle_resolve(const boost::system::error_code& err,
		tcp::resolver::iterator endpoint_iterator)
	{
		if (!err)
		{
			// Attempt a connection to the first endpoint in the list. Each endpoint
			// will be tried until we successfully establish a connection.
			tcp::endpoint endpoint = *endpoint_iterator;
			socket_.async_connect(endpoint,
				boost::bind(&client::handle_connect, this,
				boost::asio::placeholders::error, ++endpoint_iterator));

			size_t cancelcnt = timer_.expires_from_now(boost::posix_time::milliseconds(timeout_millis));
			//@return The number of asynchronous operations that were cancelled;��һ��������ʱ��
//			std::cout << "timer canceled count is = " << cancelcnt << std::endl;
			timer_.async_wait(boost::bind(&client::handle_timeout,this,
				boost::asio::placeholders::error));    
		}
		else
		{
			std::cout << "Error: " << err.message() << "\n";
		}
	}

	void handle_connect(const boost::system::error_code& err,
		tcp::resolver::iterator endpoint_iterator)
	{
			if (!err)
			{
				// The connection was successful. Send the request.
				boost::asio::async_write(socket_, request_,
					boost::bind(&client::handle_write_request, this,
					boost::asio::placeholders::error));
			}
			else if (endpoint_iterator != tcp::resolver::iterator())
			{
				// The connection failed. Try the next endpoint in the list.
				socket_.close();
				tcp::endpoint endpoint = *endpoint_iterator;
				socket_.async_connect(endpoint,
					boost::bind(&client::handle_connect, this,
					boost::asio::placeholders::error, ++endpoint_iterator));
			}
			else
			{
			//	std::cout << "Error: " << err.message() << "\n";
				std::cout << "Error: " << err << "\n";
				std::cout << "Error id: " << id << "\n";
				char strtmp[80];
				sprintf(strtmp,"%d subserver is not online<BR>\n",id);
				*rs_string = strtmp;
				this->handle_exit();
			}
		
	}

	void handle_write_request(const boost::system::error_code& err)
	{
		if (!err)
		{
			// Read the response status line.
			boost::asio::async_read_until(socket_, response_, "\r\n",
				boost::bind(&client::handle_read_status_line, this,
				boost::asio::placeholders::error));
		}
		else
		{
			std::cout << "Error: " << err.message() << "\n";
		}
	}

	void handle_read_status_line(const boost::system::error_code& err)
	{
		if (!err)
		{
			// Check that response is OK.
			std::istream response_stream(&response_);
			std::string http_version;
			response_stream >> http_version;
			unsigned int status_code;
			response_stream >> status_code;
			std::string status_message;
			std::getline(response_stream, status_message);
			if (!response_stream || http_version.substr(0, 5) != "HTTP/")
			{
				std::cout << "Invalid response\n";
				return;
			}
			if (status_code != 200)
			{
				std::cout << "Response returned with status code ";
				std::cout << status_code << "\n";
				return;
			}

			// Read the response headers, which are terminated by a blank line.
			boost::asio::async_read_until(socket_, response_, "\r\n\r\n",
				boost::bind(&client::handle_read_headers, this,
				boost::asio::placeholders::error));
		}
		else
		{
			std::cout << "Error: " << err << "\n";
		}
	}

	void handle_read_headers(const boost::system::error_code& err)
	{
		if (!err)
		{
			// Process the response headers.
			std::istream response_stream(&response_);
			std::string header;
			
			std::getline(response_stream, header);
			std::cout << header << "\n";
			sscanf(header.c_str(),"Content-Length: %d",&m_length);
			m_count = 0;
			std::cout <<"m_length" <<m_length << "\n";

			while (std::getline(response_stream, header) && header != "\r")
				std::cout << header << "\n";
			std::cout << "\n";
			
			m_count = m_count + response_.size();
			
			if(m_count >= m_length)
			{
				std::istream is(&response_);
				string s;
				is >> s;
				*rs_string = *rs_string + s;
			
				this->handle_exit();
			}
			else
			{
				std::istream is(&response_);
				string s;
				is >> s;
				*rs_string = *rs_string + s;
		

			// Start reading remaining data until EOF.
			boost::asio::async_read(socket_, response_,
				boost::asio::transfer_at_least(1),
				boost::bind(&client::handle_read_content, this,
				boost::asio::placeholders::error));
			}
		}
		else
		{
			std::cout << "Error: " << err << "\n";
		}
	}

	void handle_read_content(const boost::system::error_code& err)
	{
		if (!err)
		{
			
			m_count = m_count + response_.size();
			
			if(m_count >= m_length)
			{
				std::istream is(&response_);
				string s;
				is >> s;
				*rs_string = *rs_string + s;
			
				this->handle_exit();
			}
			else
			{
				std::istream is(&response_);
				string s;
				is >> s;
				*rs_string = *rs_string + s;
			

			// Continue reading remaining data until EOF.
			boost::asio::async_read(socket_, response_,
				boost::asio::transfer_at_least(1),
				boost::bind(&client::handle_read_content, this,
				boost::asio::placeholders::error));
			}

			
		}
		else if (err != boost::asio::error::eof)
		{
			std::cout << "Error: " << err << "\n";
		}
	}

	void handle_timeout(const boost::system::error_code& e)
	{
		if (e != boost::asio::error::operation_aborted)
		{
			std::cout << id<<" timeout now.\n";  
			char strtmp[80];
			sprintf(strtmp,"%d subserver is timeout<BR>\n",id);
		//	*rs_string = strtmp;
			this->handle_exit();
		}
		else
		{//��ȡ��
//			std::cout << "cancelled now.\n";
		}            
		return;
	}
	void handle_exit()
	{
//		std::cout << "enter handle_exit1.\n";        
		if (!exit_flag_)
		{
//			std::cout << "enter handle_exit2.\n";
			exit_flag_ = true;
			timer_.cancel();
			socket_.close();
//			std::cout << "after socket close.\n";
			/**//*
				Any asynchronous send, receive
				or connect operations will be cancelled immediately, and will complete
				with the boost::asio::error::operation_aborted error
				*/
			//delete this;
			std::cout << id<<" handle_exit.\n";
			return;
		}
		else
		{
			return;
		}
	}

	tcp::resolver resolver_;
	tcp::socket socket_;
	boost::asio::streambuf request_;
	boost::asio::streambuf response_;
	int id;
	boost::asio::deadline_timer timer_;
	bool exit_flag_; 
	int timeout_millis;
	string *rs_string;
	int m_length;
	int m_count;

};
/*
static string sendUrlRequest(const string& ip,const string& port,const string& path)
{
	boost::asio::io_service _io_service;
	string rs;
	string command = "/" + path;
	client c(rs,10000,0,_io_service, ip.c_str(),port.c_str(), command);
	_io_service.run();
	return rs;
}*/

#endif //HTTP_CLIENT_HPP
