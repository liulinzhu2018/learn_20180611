//
// request_handler.hpp
// ~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2008 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef HTTP_SERVER3_REQUEST_HANDLER_HPP
#define HTTP_SERVER3_REQUEST_HANDLER_HPP

#include <string>
#include <boost/noncopyable.hpp>
#include <boost/enable_shared_from_this.hpp>

//#include "i_core_worker.hpp"

namespace http {
namespace server31 {
    
class I_CoreWork;
struct reply;
struct request;
class connection;

/// The common handler for all incoming requests.
class request_handler
  : private boost::noncopyable
{
public:
	request_handler()
	:m_coreWorker(NULL)
	{}

	request_handler(I_CoreWork *ref_coreWorker)
		:m_coreWorker(ref_coreWorker)
	{
		if (NULL == m_coreWorker)
		{
			throw std::bad_exception();
		}
	}

	void SetCoreWorker(I_CoreWork *ref_coreWorker)
	{
		m_coreWorker = ref_coreWorker;

		if (NULL == m_coreWorker)
		{
			throw std::bad_exception();
		}
	}

	void setOffline(const std::string &offline)
	{
		_offline = offline;
	}

  /// Handle a request and produce a reply.
  int handle_request(	boost::shared_ptr<connection> conn, const request& req, reply& rep, 
	const std::string& defaultType="xml" // 返回网页的默认类型：如 txt->text/plain
	);

private:
  /// Perform URL-decoding on a string. Returns false if the encoding was
  /// invalid.
  static bool url_decode(const std::string& in, std::string& out);

 private:
	I_CoreWork *m_coreWorker;
	std::string _offline;
    
};

} // namespace server31
} // namespace http

#endif // HTTP_SERVER3_REQUEST_HANDLER_HPP
