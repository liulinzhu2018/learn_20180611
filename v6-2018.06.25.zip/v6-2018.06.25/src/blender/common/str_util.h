/*
 * str_util.h
 *
 *  Created on: 2013-8-7
 *      Author: samulwang
 */

#ifndef STRUTIL_H_
#define STRUTIL_H_
#include <string>
#include <vector>
#include <set>

using namespace std;

class StrUtil {
public:
    static string trim(const string& str);
    static void split(const string& text, const char* delimeter, set<string>& words);
    static void split(const string& text, const char* delimeter, vector<string>& words);
    static vector<string> split(const string& text, const char* delimeter);
    /**
     * ��strԭ��תΪСд������str���������á�
     */
    static string& toLower(string& str);
    /**
     * ��text��delimeter�зֳ�<K,V>�ԡ��ɹ�ʱ�����k2v�в�����true�����򷵻�false��k2v��ֵ�������ı䡣
     * Key��Value��ǰ��ո񽫻�ȥ��
     */
    static bool splitPair(const string& text, const char* delimeter, pair<string, string>& k2v);
    static bool isNumber(const string& texts);
    static string joinVec(const vector<string>& vec, const char* delimeter="");
    static string format(const char* fmt, ...);
    /** replace string inplace.
     * times: 0 replace all
     * return how many times replaced
    */
    static size_t replace(string& str, const string& src, const string& dest, size_t times=0);
    static size_t replace(string& str, const char* src, size_t szSrc, const char* dest, size_t szDest, size_t times=0);

    static bool convertEncode(const string& fromCode,const string& fromStr,const string& toCcode,string& toStr);

    inline static bool utf82gbk(const string& utf8str,string& gbkstr){
        return convertEncode("UTF-8",utf8str,"GBK",gbkstr);
    }

    inline static bool gbk2utf8(const string& gbkstr,string& utf8str){
        return convertEncode("GBK",gbkstr,"UTF-8",utf8str);
    }


};

#endif /* STRUTIL_H_ */
