#include "jdsz_logtrace_manager.h"
#include <sstream>
#include <boost/lexical_cast.hpp> 

namespace jdsz_logtrace{

long jdsz_getMilliTime()
{
    struct timeval t;
    gettimeofday(&t, NULL);
    return (static_cast<long>(t.tv_sec) * 1000ul
        + static_cast<long>(t.tv_usec) / 1000ul);
}


////////////////////////////////////////////////////////////////////////
ThreadLocalSlot::ThreadLocalSlot(void (*destructor)(void* p))
{
    int ret = pthread_key_create(&m_key, destructor);
    if (ret != 0)
    {
        const char* msg = strerror(ret);
        fprintf(stderr, "%s: Fatal error, %s", __PRETTY_FUNCTION__, msg);
        abort();
    }
}

ThreadLocalSlot::~ThreadLocalSlot()
{
    int ret = pthread_key_delete(m_key);
    if (ret != 0)
    {
        const char* msg = strerror(ret);
        fprintf(stderr, "%s: Fatal error, %s", __PRETTY_FUNCTION__, msg);
        abort();
    }
    m_key = pthread_key_t(); // reset to zero
}

void* ThreadLocalSlot::Get() const
{
    return pthread_getspecific(m_key);
}

int ThreadLocalSlot::Set(void* p)
{
    // if you meet error here, maybe this object has already been destructed
    int ret = pthread_setspecific(m_key, p);
    return ret;
}

//////////////////////////////////////////////////////////////
JDSZLogTraceWrapper::JDSZLogTraceWrapper()
{
    _logtrace= new framework::LogTrace();
    pthread_mutex_init(&_mutex, NULL);
    _first_log_time = 0;
    _total_cnt = 0;
}

JDSZLogTraceWrapper::~JDSZLogTraceWrapper()
{
    flush();
    pthread_mutex_lock(&_mutex);
    if (NULL != _logtrace)
    {
        delete _logtrace;
        _logtrace = NULL;
    }
    pthread_mutex_unlock(&_mutex);

    pthread_mutex_destroy(&_mutex);
}

int JDSZLogTraceWrapper::init( std::string host,std::string server_path)
{
    int ret = _logtrace->Initialize(host.c_str(), server_path.c_str());
    return ret;
}

void JDSZLogTraceWrapper::trace(const char * topic,unsigned int info, const std::string &tag)
{
    pthread_mutex_lock(&_mutex);
    if ( tag.empty() )
    {
        _logtrace->Trace(topic, info);
    }
    else
    {
        std::string infos = boost::lexical_cast<std::string>(info) + "," + tag;
        _logtrace->Trace(topic, infos.c_str());
    }
    if (_total_cnt == 0)
    {
        _first_log_time = jdsz_getMilliTime();
    }
    _total_cnt++;
    pthread_mutex_unlock(&_mutex);
}

void JDSZLogTraceWrapper::flush()
{
    pthread_mutex_lock(&_mutex);
    _logtrace->Flush();
    _first_log_time = 0;
    _total_cnt = 0;
    pthread_mutex_unlock(&_mutex);
}

bool JDSZLogTraceWrapper::needFlush(uint32_t log_max, uint32_t interval_max)
{
    if (_total_cnt > log_max)
    {
        return true;
    }
    
    uint64_t cur_time = jdsz_getMilliTime();
    if (_first_log_time>0 && cur_time > (_first_log_time+interval_max))
    {
        return true;
    }
    return false;
}

//////////////////////////////////////////////////////////////
JDSZLogTraceHelper::JDSZLogTraceHelper():_need_delete(false)
{
    _cur_wrapper = new JDSZLogTraceWrapper();
    _bak_wrapper = new JDSZLogTraceWrapper();
}

JDSZLogTraceHelper::~JDSZLogTraceHelper()
{
    if (NULL != _cur_wrapper)
    {
        delete _cur_wrapper;
        _cur_wrapper = NULL;
    }

    if (NULL != _bak_wrapper)
    {
        delete _bak_wrapper;
        _bak_wrapper = NULL;
    }
}


int JDSZLogTraceHelper::init(std::string host,std::string server_path)
{
    if (_cur_wrapper->init(host, server_path) != 0)
    {
        return -1;
    }
    
    if (_bak_wrapper->init(host, server_path) != 0)
    {
        return -1;
    }
    return 0;
}

void JDSZLogTraceHelper::trace(const std::string& topic,unsigned int info, const std::string &tag)
{
    _cur_wrapper->trace(topic.c_str(), info, tag);
}

void JDSZLogTraceHelper::flush(uint32_t log_max, uint32_t interval_max)
{
    if (!_cur_wrapper->needFlush(log_max, interval_max))
    {
        return;
    }

    std::swap(_cur_wrapper, _bak_wrapper);
    _bak_wrapper->flush();
}

///////////////////////////////////////////////////////////////

ThreadLocalSlot JDSZLogTraceManager::_slot(&JDSZLogTraceManager::Delete);
std::string JDSZLogTraceManager::_host = "";
std::string JDSZLogTraceManager::_server_path = "";
JDSZLogTraceManager* JDSZLogTraceManager::_instance = NULL;
bool JDSZLogTraceManager::_init_ok = false;
bool JDSZLogTraceManager::_ump2_report = true;

JDSZLogTraceManager::JDSZLogTraceManager():_flush_interval(1000*1000),_log_max(100),_stop(false)
{
    pthread_mutex_init(&_mutex, NULL);
}

JDSZLogTraceManager* JDSZLogTraceManager::instance()
{
    if (_instance == NULL)
    {
        _instance = new JDSZLogTraceManager();
    }
    return _instance;
}

int JDSZLogTraceManager::Trace( const std::string &topic, int info, int type, const std::string &tag)
{
    if ( !_init_ok || !_ump2_report || info < 0 )
    {
        return -1;
    }

    JDSZLogTraceHelper* ptr_helper = NULL;
    ptr_helper = (JDSZLogTraceHelper*)_slot.Get();
    if (NULL == ptr_helper)
    {
        if (_server_path.empty() || _host.empty())
        {
            fprintf(stderr, "server_path or host is empty");
            return -1;
        }

        ptr_helper = new JDSZLogTraceHelper();
        int ret = ptr_helper->init(_host, _server_path);
        if (ret != 0)
        {
            delete ptr_helper;
            return -1;
        }

        ret = _slot.Set(ptr_helper);
        if (ret != 0)
        {
            fprintf(stderr, "set failed, error:%d", ret);
            delete ptr_helper;
            return ret;
        }

        JDSZLogTraceManager::instance()->addHelper(ptr_helper);
    }

    //BLD_DEBUG(NULL, "logtrace threadid:<<"<<gettidv1()<<", logtrace:"<<ptr_helper);

    if(type&JDSZ_LOGTRACE_TYPE_MAX)
        ptr_helper->trace(topic+".max", info, tag);
    if(type&JDSZ_LOGTRACE_TYPE_AVG)
        ptr_helper->trace(topic+".avg", info, tag);
    if(type&JDSZ_LOGTRACE_TYPE_TP99)
        ptr_helper->trace(topic+".tp99", info, tag);
    if(type&JDSZ_LOGTRACE_TYPE_CNT)
        ptr_helper->trace(topic+".count", info, tag);
    if(type&JDSZ_LOGTRACE_TYPE_QPS)
        ptr_helper->trace(topic+".qps", info, tag);
    if(type&JDSZ_LOGTRACE_TYPE_RATIO)
        ptr_helper->trace(topic+".ratio", info, tag);
    if(type&JDSZ_LOGTRACE_TYPE_SUM)
        ptr_helper->trace(topic+".sum", info, tag);
    return 0;
}

int JDSZLogTraceManager::init( std::string host, std::string server_path,int flush_interval,int log_max)
{
    _flush_interval = 1000*flush_interval;
    _log_max = log_max;
    _host = host;
    _server_path = server_path;
    _stop = false;

    if ( _host.empty() || _server_path.empty() )
    {
        printf("JDSZLogTraceManager::init: _host(%s) or _server_path(%s) is empty\n", _host.c_str(), _server_path.c_str());
        return -1;
    }

    //启动扫描线程
	pthread_t id;
	if (pthread_create(&id, NULL, thread_worker, this)) {
		return -2;
	}

    printf("start jdsz logtrace thread:%d", (int)id);
    _init_ok = true;
    return 0;
}

void JDSZLogTraceManager::addHelper(JDSZLogTraceHelper * helper)
{
    if (NULL == helper) 
        return;
        
    pthread_mutex_lock(&_mutex);
    _vecHelpers.push_back(helper);
    pthread_mutex_unlock(&_mutex);
}

void JDSZLogTraceManager::flush()
{
    pthread_mutex_lock(&_mutex);
    size_t helper_cnt = _vecHelpers.size();
    pthread_mutex_unlock(&_mutex);

    for (size_t idx = 0; idx < helper_cnt; idx++)
    {
        pthread_mutex_lock(&_mutex);
        JDSZLogTraceHelper * helper = _vecHelpers[idx];
        pthread_mutex_unlock(&_mutex);
        helper->flush(_log_max,_flush_interval);
    }

    //erase deleted helper
    pthread_mutex_lock(&_mutex);
    std::vector<JDSZLogTraceHelper*>::iterator iter;
    for (iter = _vecHelpers.begin(); iter != _vecHelpers.end(); iter++)
    {
        if ((*iter)->needDelete())
        {
            delete *iter;
            iter = _vecHelpers.erase(iter);
        }
        if (iter == _vecHelpers.end())
        {
            break;
        }
    }
    pthread_mutex_unlock(&_mutex);
}

void JDSZLogTraceManager::Delete(void * p)
{
    if (NULL == p)
        return;

    JDSZLogTraceHelper* ptr_helper = (JDSZLogTraceHelper*)p;
    ptr_helper->setDelete();
}

void* JDSZLogTraceManager::thread_worker(void* param)
{
    JDSZLogTraceManager* manager = (JDSZLogTraceManager*)(param);
    do
    {
        usleep(1000000);
        manager->flush();
    }while(!manager->_stop);
    return NULL;
}


void Trace_latency(const std::string &topic_prefix, int cost_time, const std::string &tag, bool use_tag)
{
    if (!topic_prefix.empty())
    {
        if ( use_tag )
        {
            jdsz_logtrace::JDSZ_LOGTRACE4(topic_prefix, cost_time
                , jdsz_logtrace::JDSZ_LOGTRACE_TYPE_AVG|jdsz_logtrace::JDSZ_LOGTRACE_TYPE_MAX|jdsz_logtrace::JDSZ_LOGTRACE_TYPE_TP99
                , tag);
        }
        else
        {
            jdsz_logtrace::JDSZ_LOGTRACE4(topic_prefix, cost_time
            , jdsz_logtrace::JDSZ_LOGTRACE_TYPE_AVG|jdsz_logtrace::JDSZ_LOGTRACE_TYPE_MAX|jdsz_logtrace::JDSZ_LOGTRACE_TYPE_TP99
            , "");
        }
        
    }

    return;
}


void Trace_cnt(const std::string &topic, int cnt, const std::string &tag)
{
    if (!topic.empty() )
    {
        jdsz_logtrace::JDSZ_LOGTRACE4(topic, cnt, jdsz_logtrace::JDSZ_LOGTRACE_TYPE_CNT, tag); 
    }
    return;
}


void Trace_sum(const std::string &topic, int value, const std::string &tag)
{
    if (!topic.empty() )
    {
        jdsz_logtrace::JDSZ_LOGTRACE4(topic, value, jdsz_logtrace::JDSZ_LOGTRACE_TYPE_SUM, tag); 
    }
    return;
}

void Trace_qps(const std::string &topic, int cnt, const std::string &tag)
{
    if (!topic.empty() )
    {
        jdsz_logtrace::JDSZ_LOGTRACE4(topic, cnt, jdsz_logtrace::JDSZ_LOGTRACE_TYPE_QPS, tag); 
    }
    return;
}

void Trace_value(const std::string & topic,int value, const std::string &tag)
{
    if (!topic.empty())
    {
        //value不使用tag，否则会影响avg统计
        jdsz_logtrace::JDSZ_LOGTRACE4(topic, value
            , jdsz_logtrace::JDSZ_LOGTRACE_TYPE_AVG|jdsz_logtrace::JDSZ_LOGTRACE_TYPE_MAX
            , "");
    }
}

void Trace_ratio(const  std::string & topic,bool bValue, const std::string &tag, bool use_tag)
{
    if (!topic.empty())
    {
        //avg不使用tag，否则会影响avg统计
        int dwValue = bValue?1:0;
        if ( use_tag )
        {
            jdsz_logtrace::JDSZ_LOGTRACE4(topic, dwValue, jdsz_logtrace::JDSZ_LOGTRACE_TYPE_RATIO, tag);        }
        else
        {
           jdsz_logtrace::JDSZ_LOGTRACE4(topic, dwValue, jdsz_logtrace::JDSZ_LOGTRACE_TYPE_RATIO, "");
        }
        if ( bValue )
        {
            jdsz_logtrace::JDSZ_LOGTRACE4(topic+".ratio_ok", 1, jdsz_logtrace::JDSZ_LOGTRACE_TYPE_CNT, tag);
        }
    }
}

void Trace_tp(const std::string &topic, int cost_time, bool is_ok, const std::string &tag)
{
    if (!topic.empty() )
    {
        jdsz_logtrace::JDSZ_LOGTRACE4(topic, 1, jdsz_logtrace::JDSZ_LOGTRACE_TYPE_QPS, tag); 

        std::string latency_topic = topic + ".latency";
        jdsz_logtrace::JDSZ_LOGTRACE4(latency_topic, cost_time
            , jdsz_logtrace::JDSZ_LOGTRACE_TYPE_AVG|jdsz_logtrace::JDSZ_LOGTRACE_TYPE_TP99
            , tag);
    }
    return;
}

}

