#ifndef __JDSZ_LOGTRACE_MANAGER_H__
#define __JDSZ_LOGTRACE_MANAGER_H__

#include "log_trace.h"
#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include <stdint.h>

namespace jdsz_logtrace{

enum JDSZ_LOGTRACE_TYPE{
    JDSZ_LOGTRACE_TYPE_MAX = 0x01,
    JDSZ_LOGTRACE_TYPE_AVG = 0x02,
    JDSZ_LOGTRACE_TYPE_TP99 = 0x04,
    JDSZ_LOGTRACE_TYPE_CNT = 0x10,
    JDSZ_LOGTRACE_TYPE_QPS = 0x20,
    JDSZ_LOGTRACE_TYPE_RATIO = 0x40,
    JDSZ_LOGTRACE_TYPE_SUM = 0x80,
};

class ThreadLocalSlot
{
public:
    ThreadLocalSlot(void (*destructor)(void* p));
    ~ThreadLocalSlot();
public:
    void* Get() const;
    int Set(void* p);
private:
    ThreadLocalSlot(const ThreadLocalSlot&); 
    ThreadLocalSlot& operator=(const ThreadLocalSlot&);
private:
    pthread_key_t m_key;
};

class JDSZLogTraceWrapper{
public:
    JDSZLogTraceWrapper();
    ~JDSZLogTraceWrapper();
    int init(std::string host, std::string server_path);
    void trace(const char* topic, unsigned int info, const std::string &tag);
    bool needFlush(uint32_t log_max, uint32_t interval_max);
    void flush();
public:
    framework::LogTrace* _logtrace;
    pthread_mutex_t _mutex;
    uint64_t _first_log_time;
    uint32_t _total_cnt;
};

class JDSZLogTraceHelper
{
public:
    JDSZLogTraceHelper();
    ~JDSZLogTraceHelper();
    int init(std::string host, std::string server_path);
    void trace(const std::string& topic, unsigned int info, const std::string &tag);
    void flush(uint32_t log_max, uint32_t interval_max);
    void setDelete(){_need_delete = true;}
    bool needDelete(){return _need_delete;}
private:
    //˫ָ���ֹ������ռ
    JDSZLogTraceWrapper* _cur_wrapper;
    JDSZLogTraceWrapper* _bak_wrapper;
    bool _need_delete;
};
class JDSZLogTraceManager{

public:
    JDSZLogTraceManager();
    ~JDSZLogTraceManager(){}
    static JDSZLogTraceManager* instance();
    int init(std::string host, std::string server_path, int flush_interval, int log_max);
    void addHelper(JDSZLogTraceHelper* helper);
    void flush();
    static int Trace(const std::string &topic, int info, int type, const std::string &tag = "");
    static void Delete(void* p);
    static void* thread_worker(void* param);
public:
    pthread_mutex_t _mutex;
    std::vector<JDSZLogTraceHelper*> _vecHelpers;

    static std::string _host;
    static std::string _server_path;
    int _flush_interval;         //���log�ۻ�ʱ�䣬Ĭ��1000ms
    int _log_max;
    bool _stop;
    static bool _init_ok;
    static ThreadLocalSlot _slot;   //thread local param point JDSZLogTraceHelper*
    static JDSZLogTraceManager* _instance;
    static bool _ump2_report;
};

#define JDSZ_LOGTRACE_INIT(host, server_path, flush_interval, log_max) \
    JDSZLogTraceManager::instance()->init(host, server_path, flush_interval, log_max);
#define JDSZ_LOGTRACE(topic, info, type) JDSZLogTraceManager::Trace(topic, info, type)
#define JDSZ_LOGTRACE4(topic, info, type, tag) JDSZLogTraceManager::Trace(topic, info, type, tag)
#define JDSZ_SET_UMP2_REPORT_ON(report) jdsz_logtrace::JDSZLogTraceManager::instance()->_ump2_report=report;
#define JDSZ_GET_UMP2_REPORT jdsz_logtrace::JDSZLogTraceManager::instance()->_ump2_report

void Trace_latency(const std::string &topic_prefix, int cost_time, const std::string &tag = "", bool use_tag = false);
void Trace_cnt(const std::string &topic, int cnt = 1, const std::string &tag = "");
void Trace_sum(const std::string &topic, int value, const std::string &tag = "");
void Trace_qps(const std::string &topic, int cnt = 1, const std::string &tag = "");
void Trace_value(const std::string &topic, int value, const std::string &tag = "");
void Trace_ratio(const std::string &topic, bool bValue, const std::string &tag = "", bool use_tag = false);
//like ump tp
void Trace_tp(const std::string &topic, int cost_time, bool is_ok=true, const std::string &tag="");
};
#endif
