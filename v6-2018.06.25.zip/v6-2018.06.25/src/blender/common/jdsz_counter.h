#ifndef __BLENDER_UTILS_COUNTER_H__
#define __BLENDER_UTILS_COUNTER_H__

#include <time.h>
#include "atomic.h"

namespace utils{

class Counter
{
public:
    Counter(int over_sec, long over_count) : m_over_sec(over_sec),m_over_count(over_count)
    {
        m_last_time = time(NULL);
        atomic64_set(&m_counter, 0);
    }

    bool check(bool over_time_clear_count = true, bool not_over_add = true)
    {
        time_t now = time(NULL);
        int secs = time(NULL) - m_last_time;
        long count = get();
        if ( secs >= m_over_sec )
        {
            if ( over_time_clear_count )
            {
                reset();
            }
            if ( count >= m_over_count )
            {
                return true;
            }
        }
        if ( not_over_add )
        {
            add();
        }
        return false;
    }
    
    long add(long count = 1)
    {
        return atomic64_add_return(count, &m_counter);
    }

    long get()
    {
        return atomic64_read(&m_counter);
    }

    void reset()
    {
        m_last_time = time(NULL);
        atomic64_set(&m_counter, 0);
    }

private:
    long m_over_sec;
    long m_over_count;
    atomic64_t m_counter;
    time_t     m_last_time;
};

}

#endif 
