#ifndef _TIMER_UTIL_H
#define _TIMER_UTIL_H
#include <boost/lexical_cast.hpp> 
#include "global.h"
#include <string>
#include <sys/time.h>

using namespace std;
namespace time_util
{

// 精确到微妙（千分之一毫秒）
class MsTimer
{
private:
	struct timeval tvafter,tvpre;
	struct timezone tz;
    bool is_start_;

public:
    MsTimer():is_start_(false){}

	// 开始计时
	void Start()
	{
        is_start_ = true;
		gettimeofday(&tvpre , &tz);
	}
	// 结束计时
	void End()
	{
        if ( is_start_ )
        {
		    gettimeofday(&tvafter , &tz);
        }
	}

    //临时计时
    int ClockUs() 
    {
		End();
        return CostUs();
    }

    //临时计时
    int ClockMs() 
    {
		End();
        return CostMs();
    }

	int CostUs() const
	{
        if ( is_start_ )
        {
		    return (tvafter.tv_sec-tvpre.tv_sec)*1000000+(tvafter.tv_usec-tvpre.tv_usec);
        }
        return 0;
	}

	int CostMs() const
	{
        if ( is_start_ )
        {
		    return (tvafter.tv_sec-tvpre.tv_sec)*1000+(tvafter.tv_usec-tvpre.tv_usec)/1000;
        }
        return 0;
	}
};

};//namesapce time_util
#endif
