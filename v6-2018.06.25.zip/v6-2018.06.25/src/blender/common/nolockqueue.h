/*********************************************************************
 * $Author: weilei 2011-05-20 $
 *
 * $LastChangedBy: weilei 2014-06-27 $
 *
 * $Brief: 同步队列. $
 ********************************************************************/

#ifndef UTIL_NOLOCKQUEUE_H_
#define UTIL_NOLOCKQUEUE_H_

#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#include <pthread.h>
#include <errno.h>
#include "atomic.h"
#include <unistd.h>



namespace blender
{

/**
 * 同步队列模板, 其特例化对象必须是支持operator=
 */
template<typename T>
class NoLockQueue
{
    public:
        /**
         * 构造函数
		 * @param limit 代表队列限制，0代表不受限
         */
        NoLockQueue(uint32_t limit = 10000) : _limit(limit)
        {
            if ( _limit <= 0 )
            {
                _limit = 1;
            }
			_terminated = false;
            _array = new T[_limit];
			_head = _tail = 0;
            _max_read_idx = 0;
            int ret;
            ret = pthread_mutex_init(&_mutex, NULL);
            assert(ret == 0);
            ret = pthread_cond_init(&_cond, NULL);
            assert(ret == 0);
            atomic32_set(&_size, 0);
        }

        /**
         * 析构函数
         */
        ~NoLockQueue()
        {
            delete []_array;
        }

    public:
        /**
         * 进队操作，不会阻塞，即该队列没有上限.
         * @param [in] ele 待插入元素.
         *        [in] make_sure_ok 如果队列满是否一直等待，确保入队列成功
         * @return 0  表示成功 
         *         -1 表示失败, 在此之前stop()必然已被调用，
         *            该队列不再有效.
         * @ref template<typename T> void NoLockQueue<T>::stop()
         */
        int enqueue(const T & ele, bool make_sure_ok = true);

        /**
         * 出队操作. 如果没有元素，会阻塞.
         * @param [out] ele 出队元素存放缓冲区
         *        [in] timeout_us 等等这么长时间还没有渠道元素的时候返回1,0表示一直等待不超时
         * @return 0         表示成功
         *         -1        表示失败，在此之前stop()必然已被调用，
         *                   该队列不再有效.
         *                   调用者此时可尝试重新deNoLockQueue
         * @ref template<typename T> void NoLockQueue<T>::stop()
         */
        int dequeue(T & ele, uint32_t timeout_us = 0);

        /**
         * 打断该队列上所有调用，并将该队列置为无效，在该调用完成后
         * 无论是之前阻塞在该队列上的调用，还是以后的调用 deNoLockQueue和
         * enNoLockQueue都会返回-1.
         * 该函数一般在shutdown前调用
         * @ref template<typename T> int NoLockQueue<T>::deNoLockQueue(ele)
         * @ref template<typename T> int NoLockQueue<T>::enNoLockQueue(ele)
         */

        void stop();
        /**
         * 返回该队列中的保留元素个数。
         * 注意，该函数函数不安全.
         * @return 该队列中的保留元素个数
         */

        uint32_t size() const { return atomic32_read(&_size); }

        static uint64_t getCurrentUSec() 
        {
            struct timeval tv;
            gettimeofday(&tv, NULL);
            return tv.tv_sec * 1000000 + tv.tv_usec;
        }

    private:
        bool _terminated;
        T *_array;
        int _head;
        int _tail;
        uint32_t _max_read_idx;
        atomic32_t _size;
		uint32_t _limit;
        pthread_mutex_t _mutex;
        pthread_cond_t _cond;
};

template<typename T>
int NoLockQueue<T>::enqueue(const T & ele, bool make_sure_ok)
{
    __sync_synchronize();
    int o_tail;
    int n_tail;
    do {
        o_tail = _tail;
        n_tail = (o_tail + 1) % _limit;
        if ( n_tail == _head ) 
        { 
            printf("#######queue full!!!!!!!!!!!!!!!!!!!!!!!\n");
            if ( !make_sure_ok) {
                return -1;
            }
            continue;
        }
    }while(__sync_bool_compare_and_swap(&_tail, o_tail, n_tail) != true);
    _array[o_tail] = ele;
    while ( !__sync_bool_compare_and_swap(&_max_read_idx, o_tail, n_tail) )
    {
        //usleep(1);
    }
    atomic32_inc(&_size);
    //printf("===%d enqueue:%d  size:%d  o_tail:%d  n_tail:%d  _tail:%d  _head:%d  _max_read_idx:%d\n", pthread_self(), ele, atomic32_read(&_size), o_tail, n_tail, _tail, _head, _max_read_idx);
    return 0;
}

template<typename T>
int NoLockQueue<T>::dequeue(T & ele, uint32_t timeout_us)
{
    int head_o;
    int head_n;
    bool swap = false;
    uint64_t start_us = getCurrentUSec();
    __sync_synchronize();
    do {
        if ( _terminated )
        {
            return -1;
        }

        if ( (timeout_us > 0) && ((getCurrentUSec() - start_us) >= timeout_us) )
        {
            return 1;
        }

        head_o = _head;
        head_n = (head_o + 1) % _limit;

        if ( (head_o == _max_read_idx) || (head_o == _tail) ) 
        {
            usleep(100);
            continue;
        }
        swap = __sync_bool_compare_and_swap(&_head, head_o, head_n);
    }while(!swap);
    ele = _array[head_o];
    atomic32_sub(1, &_size);
    //printf("===%d dequeue:%d  size:%d  head_o:%d  head_n:%d  _head:%d _tail:%d  _max_read_idx:%d\n", pthread_self(), ele, atomic32_read(&_size), head_o, head_n, _head, _tail, _max_read_idx);
    return 0;
}

template<typename T>
void NoLockQueue<T>::stop() 
{
    _terminated = true;
}

typedef NoLockQueue<char *> NoLockTaskQueue;
typedef NoLockQueue<size_t> NoLockNumberQueue;

}
#endif //UTIL_NoLockQueue_H_
