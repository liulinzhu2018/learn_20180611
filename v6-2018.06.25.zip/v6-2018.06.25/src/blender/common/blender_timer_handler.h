
#ifndef __BLENDER_TIMER_HANDLER_H__
#define __BLENDER_TIMER_HANDLER_H__

#include <boost/asio.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/asio/deadline_timer.hpp>

namespace blender {
class BlenderTimerHanderManager;

class BlenderTimerHandler
    : public boost::enable_shared_from_this<BlenderTimerHandler>,
      private boost::noncopyable
{
public:
    BlenderTimerHandler();
    
    virtual ~BlenderTimerHandler();

    //Return: true:  ��ʱ������
    //           false: ֹͣ��ʱ���������Ҫ��������Ҫ����restartTimer
    virtual bool timeout_handle() = 0;

    //��ʱ�����ʱ��
    virtual uint64_t interval_msecs() const { return 1000; }

    //һ���Զ�ʱ������stop֮����Ҫ������ʱ����������Ҫrestart
    void restart();
    
    void stop();
    
private:
    void timeout(const boost::system::error_code& e);
    
private:
    boost::asio::deadline_timer _timer;
};

typedef boost::shared_ptr<BlenderTimerHandler> BlenderTimerHandler_ptr;

class BlenderTimerHanderManager
{
public:
    BlenderTimerHanderManager();
    static BlenderTimerHanderManager* instance();
    
    void reg_timer(BlenderTimerHandler *handler);

    void start();

    void stop();

    boost::asio::io_service& io_service() { return _io_service; }
   
private:
    boost::asio::io_service _io_service;
    boost::shared_ptr<boost::thread> _timer_thread;
    std::list<BlenderTimerHandler_ptr > _handler_list;
};

};
#endif 
