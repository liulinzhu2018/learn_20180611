#include "TpsLog.h"
#include "ump_report.h"
#include <boost/lexical_cast.hpp> 
#include <string>
#include <stdio.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <netinet/in.h> 

namespace ump_report{

std::string _tpLogMsg(const std::string &ump_key, uint64_t cost, int is_ok);
std::string _businessLogMsg(const std::string &ump_key, const std::string &detail);
std::string _bizLogMsg(const std::string& key, int type, uint64_t value);
std::string getLocalIpAddr();

class UMPReportObj
{
private:
    const std::string _ump_log_path;
    TpsLog* _tp_tps;
    TpsLog* _business_tps;
    TpsLog* _biz_tps;

    TpsLog* create_tpslog(const std::string &suffix, const std::string &type)
    {
        std::string log_path = _ump_log_path + "_" + type;
        TpsLog* tpslog = new TpsLog();
        tpslog->SetBasename(log_path.c_str());
        tpslog->SetExtension(suffix.c_str());
        tpslog->SetLogServity(google::INFO);
        tpslog->SetMaxLogSize(10);
        tpslog->SetInitialized(true);

        LOG_TO_DEFINEED_SINK(tpslog) << "demo:" << &tpslog << std::endl << std::endl;
        return tpslog;
    }

public:
    UMPReportObj(const std::string &ump_log_path)
        : _ump_log_path(ump_log_path)
        , _tp_tps(NULL)
        , _business_tps(NULL)
        , _biz_tps(NULL)
    {}

    ~UMPReportObj()
    {
        if ( NULL != _tp_tps )
        {
            delete _tp_tps;
            _tp_tps = NULL;
        }
        if ( NULL != _business_tps)
        {
            delete _business_tps;
            _business_tps = NULL;
        }
        if ( NULL != _biz_tps)
        {
            delete _biz_tps;
            _biz_tps = NULL;
        }
    }

    TpsLog* tp_tps()
    {
        if ( NULL == _tp_tps )
        {
            _tp_tps = create_tpslog("_tp.log", "tp");
        }
        return _tp_tps;
    }
    TpsLog* business_tps()
    {
        if ( NULL == _business_tps )
        {
            _business_tps = create_tpslog("_business.log", "business");
        }
        return _business_tps;
    }
    TpsLog* biz_tps()
    {
        if ( NULL == _biz_tps )
        {
            _biz_tps = create_tpslog("_biz.log", "biz");
        }
        return _biz_tps;
    }

public:
    static int g_report_status;
};

int UMPReportObj::g_report_status = 1;

static UMPReportObj *s_umpReportObj = NULL;
static char g_hostname[256];
static std::string g_traceinfo;
static bool g_auto_reg_umpkey = false;
static std::string g_appname = "";

int init_ump(const std::string &appname, bool auto_reg_umpkey, const std::string &ump_log_path)
{
    if ( appname.empty() || ump_log_path.empty() )
    {
        return -1;
    }

    if (0 != ::access(ump_log_path.c_str(),F_OK|R_OK|W_OK|X_OK)) 
    {
        return -2;
    }

    std::string::size_type pos = ump_log_path.find_last_of('/');
    if (std::string::npos == pos) 
    {
        return -4;
    }

    g_auto_reg_umpkey = auto_reg_umpkey;
    g_appname = appname;

    std::string log_path = ump_log_path;
    if (pos + 1 != ump_log_path.size()) 
    {
        log_path.append("/");
    }
    log_path.append(appname);

    gethostname(g_hostname, 256);

    g_traceinfo.append("[app:").append(appname);
    g_traceinfo.append(", host:").append(g_hostname);
    g_traceinfo.append(", ip:").append(getLocalIpAddr());
    g_traceinfo.append("]");

    printf("ump_report traceinfo:%s\n", g_traceinfo.c_str());

    InitializeTpsLog();
    if ( NULL == s_umpReportObj )
    {
        s_umpReportObj = new UMPReportObj(log_path);
    }
    return 0;
}

int report_status(int status)
{
    switch( status )
    {
        case 0:
            UMPReportObj::g_report_status = 0;
            break;
        case 1:
            UMPReportObj::g_report_status = 1;
            break;
        default:
            break;
    }
    return UMPReportObj::g_report_status;
}

int uninit_ump()
{
    if ( NULL != s_umpReportObj )
    {
        delete s_umpReportObj;
        s_umpReportObj = NULL;
    }
    return 0;
}


bool is_need_report(const std::string &ump_key)
{
    if ( (NULL == s_umpReportObj) || (! s_umpReportObj->tp_tps()->IsInitialized()) || ump_key.empty() || (0 == UMPReportObj::g_report_status) )
    {
        return false;
    }
    return true;
}


void report_tp(const std::string &ump_key, uint64_t cost_ms, bool isok)
{
    if ( !is_need_report(ump_key) )
    {
        return;
    }

    if ( isok )
    {
        LOG_TO_DEFINEED_SINK(s_umpReportObj->tp_tps()) << _tpLogMsg(ump_key, cost_ms, 0) << std::endl;
    }
    else
    {
        LOG_TO_DEFINEED_SINK(s_umpReportObj->tp_tps()) << _tpLogMsg(ump_key, cost_ms, 1) << std::endl;
    }
    return;
}

void report_business(const std::string &ump_key, const std::string &detail)
{
    if ( !is_need_report(ump_key) )
    {
        return;
    }

    LOG_TO_DEFINEED_SINK(s_umpReportObj->business_tps()) << _businessLogMsg(ump_key, detail) << std::endl;
    return;
}


void report_biz_sum(const std::string &ump_key, uint64_t value)
{
    if ( !is_need_report(ump_key) )
    {
        return;
    }

    LOG_TO_DEFINEED_SINK(s_umpReportObj->biz_tps()) << _bizLogMsg(ump_key, 1, value) << std::endl;
    return;
}

void report_biz_count(const std::string &ump_key, uint64_t count)
{
    if ( !is_need_report(ump_key) )
    {
        return;
    }

    LOG_TO_DEFINEED_SINK(s_umpReportObj->biz_tps()) << _bizLogMsg(ump_key, 2, count) << std::endl;
    return;
}

std::string _tpLogMsg(const std::string &key, uint64_t cost, int status)
{
    char buf[1024];
    struct timeval tv;
    gettimeofday(&tv, NULL);

    struct ::tm tm_time;
    localtime_r(&tv.tv_sec, &tm_time);

    if ( g_auto_reg_umpkey )
    {
        snprintf(buf, 1024, "{\"time\":\"%04d%02d%02d%02d%02d%02d%03d\","
            "\"key\":\"%s\","
            "\"appName\":\"%s\","
            "\"hostname\":\"%s\","
            "\"processState\":\"%d\","
            "\"elapsedTime\":\"%lu\"}\n",
            1900+tm_time.tm_year,
            1+tm_time.tm_mon,
            tm_time.tm_mday,
            tm_time.tm_hour,
            tm_time.tm_min,
            tm_time.tm_sec,
            (int32_t)(tv.tv_usec/1000),
            key.c_str(),
            g_appname.c_str(),
            g_hostname,
            status,
            cost
            );
    }
    else
    {
        snprintf(buf, 1024, "{\"time\":\"%04d%02d%02d%02d%02d%02d%03d\","
            "\"key\":\"%s\","
            "\"hostname\":\"%s\","
            "\"processState\":\"%d\","
            "\"elapsedTime\":\"%lu\"}\n",
            1900+tm_time.tm_year,
            1+tm_time.tm_mon,
            tm_time.tm_mday,
            tm_time.tm_hour,
            tm_time.tm_min,
            tm_time.tm_sec,
            (int32_t)(tv.tv_usec/1000),
            key.c_str(),
            g_hostname,
            status,
            cost
            );
    }
    return std::string(buf);
}

std::string _businessLogMsg(const std::string& key,
                        const std::string& detail)
{
    char buf[1024];
    struct timeval tv;
    gettimeofday(&tv, NULL);                                                       

    std::string busiinfo = g_traceinfo + detail;
    
    struct ::tm tm_time;
    localtime_r(&tv.tv_sec, &tm_time);
    snprintf(buf, 1024, "{\"time\":\"%04d%02d%02d%02d%02d%02d%03d\","
            "\"key\":\"%s\","
            "\"hostname\":\"%s\","
            "\"type\":\"0\","
            "\"value\":\"0\","                                           
            "\"detail\":\"%s\"}\n",                                           
            1900+tm_time.tm_year,                                                  
            1+tm_time.tm_mon,                                                      
            tm_time.tm_mday,                                                       
            tm_time.tm_hour,                                                       
            tm_time.tm_min,                                                        
            tm_time.tm_sec,
            (int32_t)(tv.tv_usec/1000),                                            
            key.c_str(),                                                           
            g_hostname,                                                            
            busiinfo.c_str()
            );                                                                     
    
    return std::string(buf);
}

std::string _bizLogMsg(const std::string& key, int type, uint64_t value)
{
    char buf[1024];
    struct timeval tv;
    gettimeofday(&tv, NULL);                                                       

    const char *value_name = (type == 1) ? "bValue" : "bCount";
    
    struct ::tm tm_time;
    localtime_r(&tv.tv_sec, &tm_time);
    snprintf(buf, 1024, "{\"bTime\":\"%04d%02d%02d%02d%02d%02d%03d\","
            "\"logtype\":\"BIZ\","
            "\"bKey\":\"%s\","
            "\"bHost\":\"%s\","
            "\"type\":\"%d\","
            "\"%s\":\"%lu\"}\n",                                           
            1900+tm_time.tm_year,                                                  
            1+tm_time.tm_mon,                                                      
            tm_time.tm_mday,                                                       
            tm_time.tm_hour,                                                       
            tm_time.tm_min,                                                        
            tm_time.tm_sec,
            (int32_t)(tv.tv_usec/1000),                                            
            key.c_str(),                                                           
            g_hostname,                                                            
            type,
            value_name,
            value
            );                                                                     
    
    return std::string(buf);
}

std::string getLocalIpAddr()
{
    std::string ip_addr;
    struct ifaddrs * ifAddrStruct=NULL;
    void * tmpAddrPtr=NULL;

    getifaddrs(&ifAddrStruct);

    while (ifAddrStruct!=NULL) {
        // check it is IP4
        if (ifAddrStruct->ifa_addr->sa_family==AF_INET) 
        {
            // is a valid IP4 Address
            tmpAddrPtr=&((struct sockaddr_in *)ifAddrStruct->ifa_addr)->sin_addr;
            char addressBuffer[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
            //printf("%s IP Address %s\n", ifAddrStruct->ifa_name, addressBuffer); 
            if ( (NULL != tmpAddrPtr) && (strcmp(addressBuffer, "127.0.0.1") != 0) )
            {
                printf("%s : %s\n", ifAddrStruct->ifa_name, addressBuffer); 
                ip_addr = addressBuffer;
            }
        } 
        // check it is IP6
        else if (ifAddrStruct->ifa_addr->sa_family==AF_INET6) 
        {
            tmpAddrPtr=&((struct sockaddr_in *)ifAddrStruct->ifa_addr)->sin_addr;
            char addressBuffer[INET6_ADDRSTRLEN];
            inet_ntop(AF_INET6, tmpAddrPtr, addressBuffer, INET6_ADDRSTRLEN);
            //printf("%s IP Address %s\n", ifAddrStruct->ifa_name, addressBuffer); 
        } 
        ifAddrStruct=ifAddrStruct->ifa_next;
    }
    return ip_addr;
}

};

