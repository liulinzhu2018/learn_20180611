#include "bld_global.h"
//#include <boost/filesystem.hpp>
#include <boost/regex.hpp>
#include <boost/algorithm/string.hpp>
//#include <boost/tokenizer.hpp>
//using namespace boost::filesystem;
#define _snprintf snprintf
#define _access access
#define _chdir chdir
#define _mkdir mkdir
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <signal.h>
#include <dirent.h>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdint.h>
#include "GBKTool.h"
#include "blender_header.h"
#include "blender_config.h"
#include "ump_report.h"
#include "blender_analysis_data.h"
#include "client2env_data.h"

namespace blender 
{
    // 根据某个特殊字符串，对某个字符串进行拆分；
    // 并把拆分后的结果保存到vector中
    vector<string> GetStrings(
            const string& stringList, const string& splitWord)
    {
        vector<string> result;

        if (splitWord.empty())
        {
            // 当分割标志为空时，则认为全部字符串不必被分割，直接返回即可
            //result.push_back(stringList);
        }
        else
        {
            string stringList_cpy = splitWord + stringList;

            string::size_type lastPos = 0;

            while (stringList_cpy[stringList_cpy.size()-1] == '\n'
                    ||
                    stringList_cpy[stringList_cpy.size()-1] == '\r')
            {
                stringList_cpy.resize(stringList_cpy.size() - 1);
            }

            lastPos = stringList_cpy.find_last_of(splitWord);
            // 去掉尾部的“slitWord”
            while (lastPos == stringList_cpy.size()-1)
            {
                stringList_cpy.resize(stringList_cpy.size() - splitWord.size());
            }

            string::size_type firstPos = 0;
            string::size_type secondPos = 0;

            firstPos = stringList_cpy.find(splitWord, 0);

            while (firstPos != string::npos)
            {
                secondPos = stringList_cpy.find(splitWord, firstPos+splitWord.size());
                string curItem; // 临时存储当前被分割的子串
                if (secondPos == string::npos)
                {
                    curItem = stringList_cpy.substr(firstPos+splitWord.size(), stringList_cpy.size()-firstPos-splitWord.size());
                }
                else
                {
                    curItem = stringList_cpy.substr(firstPos+splitWord.size(), secondPos-firstPos-splitWord.size());			
                }

                if (! curItem.empty())
                {
                    // 整个字符串中不含有分割符号
                    result.push_back(curItem);
                }

                // 向后移动firstPos
                firstPos = secondPos;
            }
        }

        return result;	
    }

#define MICRO_IN_SEC 1000000
    uint64_t currentUSec()
    {
        struct timeval tv;
        gettimeofday(&tv, NULL);

        return tv.tv_sec*MICRO_IN_SEC+tv.tv_usec;
    }


void Normalize(const std::string& in, std::string& out)
{
	int wb;
    const char* b = in.c_str();
	const char* p = b;

	while ((wb = GBKTool::WordBytes(p)))
	{
		if ((wb == 1) && (*p == '('))
		{
            out.assign(b, p-b);
            return;
		}
        else if ((wb == 2) && ((unsigned char)*p == 0xA3) && ((unsigned char)p[1] == 0xA8))
        {
            out.assign(b, p-b);
            return;
        }

		p += wb;
	}

    out.assign(in);
    return;
}


std::string ump2tag(const std::string &client, const std::string &req_type)
{
    std::string tag = "caller=";
    tag.append(Client2EnvData::getInstance()->caller_key(client));
    if ( req_type.empty() )
    {
        tag.append(",reqtype=main");
    }
    else
    {
        tag.append(",reqtype=").append(req_type);
    }
    return tag;
}


void session_report(int64_t cost_ms, bool isok, BlenderAnalysisData *analysisData)
{
    std::string tag;
    std::string caller;
    if ( NULL != analysisData )
    {
        //forcebot
        if ( !analysisData->m_forcebot.empty() )
        {
            Trace_qps(BLD_STAT_CALLER_COUNT, 1, "caller=forcebot");
        }

        //caller
        caller = Client2EnvData::getInstance()->caller_key(analysisData->query()->_client_id());
        Trace_qps(BLD_STAT_CALLER_COUNT, 1, "caller=" + caller);

        tag = ump2tag(analysisData->query()->_client_id(), analysisData->m_reqtype);
    }
    else
    {
        caller = "psearch.caller.unkown";
        tag = ump2tag("", "");
    }

    //session resp
    Trace_ratio(BLD_STAT_RESP_OK, isok, tag);

    //ump
    if ( cost_ms >= 0 )
    {
        ump_report::report_tp(BLD_STAT_BLD_CALL_ENV, cost_ms, isok);
        ump_report::report_tp(BLD_STAT_BLD_CALL, cost_ms, isok);
        ump_report::report_tp(caller, cost_ms, isok);
    }

    //mtest
    if ( (0 == _blender_conf->m_g_report_off_flag) && (NULL != analysisData) )
    {
        std::string tag_prex = "mtest=";
        std::set<std::string>::iterator it = analysisData->m_mtest_set.begin();
        for ( ; it != analysisData->m_mtest_set.end(); it++ )
        {
            std::string tag = tag_prex + *it;
            Trace_tp(BLD_STAT_MTEST_DIM, cost_ms, isok, tag);
        }
    }
}


void report_bussiness(const std::string &key, bool isok, const std::string &tag)
{
    const static std::string biz_key_prefix = "search.blender.bussiness";

    std::string ntag = tag;
    if ( !tag.empty() )
    {
        ntag.append(",");
    }
    ntag.append("bussiness=").append(key);

    Trace_ratio(biz_key_prefix, isok, ntag);

    std::string umpkey = biz_key_prefix;
    umpkey.append(".").append(key).append(".").append(_blender_conf->m_g_env);
    ump_report::report_tp(umpkey, 0, isok);
}


int checkFiltTypeInBlacklist(const std::pair<std::string, std::string> &kv, std::multimap<std::string,std::string> &blacklist)
{
    if( kv.first.empty() || blacklist.size() == 0 )
    {
        return -1;
    }

    std::pair<std::multimap<std::string, std::string>::iterator, std::multimap<std::string, std::string>::iterator > riter =  blacklist.equal_range(kv.first);
    std::multimap<std::string, std::string>::iterator miter = riter.first;
    for ( ; miter != riter.second; miter++ )
    {
        if ( miter->second.empty() || (kv.second == miter->second) )
        {
            //in blacklist
            return 0;
        }
    }
    return -2;
}


int checkFiltTypeInWhitelist(const std::pair<std::string, std::string> &kv, std::multimap<std::string,std::string> &whitelist)
{
    if( kv.first.empty() || (whitelist.size() == 0) )
    {
        return 1;
    }

    std::pair<std::multimap<std::string, std::string>::iterator, std::multimap<std::string, std::string>::iterator > riter =  whitelist.equal_range(kv.first);
    if ( riter.first == riter.second )
    {
        return -2;
    }
    std::multimap<std::string, std::string>::iterator miter = riter.first;
    for ( ; miter != riter.second; miter++ )
    {
        if ( miter->second.empty() )
        {
            return 0;
        }

        if ( kv.second == miter->second )
        {
            return 0;
        }
    }
    return -3;
}

};

