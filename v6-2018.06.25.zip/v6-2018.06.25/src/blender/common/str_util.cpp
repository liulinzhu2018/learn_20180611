/*
 * str_util.cpp
 *
 *  Created on: 2013-8-7
 *      Author: samulwang
 */

#include "str_util.h"
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <algorithm>
#include <iconv.h>
string StrUtil::trim(const string& str) {
    string ret(str);
    ret.erase(0, str.find_first_not_of("\r\n\t "));
    size_t lastSpaceChar = str.find_last_not_of("\r\n\t ") + 1;
    if(lastSpaceChar < str.size()) { ret.erase(lastSpaceChar); }
    return ret;
}


void StrUtil::split(const string& text, const char* delimeter, set<string>& words)
{
    words.clear();
    size_t deliLen = strlen(delimeter);
    size_t beg = 0, end = 0;
    do {
        end = text.find(delimeter, beg);
        if(end == string::npos) { end = text.size(); }
        if ( end > beg )
        {
            words.insert(text.substr(beg, end-beg));
        }
        beg = end + deliLen;
    } while(beg < text.size());
}

void StrUtil::split(const string& text, const char* delimeter, vector<string>& words)
{
    words.clear();
    size_t deliLen = strlen(delimeter);
    size_t beg = 0, end = 0;
    do {
        end = text.find(delimeter, beg);
        if(end == string::npos) { end = text.size(); }
        if ( end > beg )
        {
            words.push_back(text.substr(beg, end-beg));
        }
        beg = end + deliLen;
    } while(beg < text.size());
}

vector<string> StrUtil::split(const string& text, const char* delimeter) {
    vector<string> ret;
    split(text, delimeter, ret);
    return ret;
}

bool StrUtil::splitPair(const string& text, const char* delimeter, pair<string, string>& k2v) {
    size_t pos = text.find(delimeter);
    size_t posStartV = pos + strlen(delimeter);
    if(pos == string::npos || posStartV > text.size()) { return false; }
    k2v.first = StrUtil::trim(text.substr(0, pos));
    k2v.second = StrUtil::trim(text.substr(posStartV));
    return true;
}

bool StrUtil::isNumber(const string& text) {
    bool hasDot = false;
    for(size_t i = 0; i < text.size(); i++) {
        if(text[i] == '.') {
            if(!hasDot) hasDot = true;
            else return false;
        } else if ('0' <= text[i] && text[i] <= '9') {
            //
        } else {
            return false;
        }
    }
    return true;
}

string StrUtil::joinVec(const vector<string>& vec, const char* delimeter){
    string ret;
    for(size_t i = 0; i < vec.size(); i++) {
        if(delimeter && i != 0) ret.append(delimeter);
        ret.append(vec[i]);
    }
    return ret;
}

string StrUtil::format(const char* fmt, ...) {
    int size = 128;
    std::string str;
    va_list ap;
    while (1) {
        str.resize(size);
        va_start(ap, fmt);
        int n = vsnprintf((char *) str.c_str(), size, fmt, ap);
        va_end(ap);
        if (n > -1 && n < size) {
            str.resize(n);
            return str;
        }
        if (n > -1) { size = n + 1; }
        else { size *= 2; }
    }
    return str;
}

string& StrUtil::toLower(string& str) {
    std::transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
}

size_t StrUtil::replace(string& str, const string& src, const string& dest, size_t times) {
    string::size_type pos = 0; size_t nTime = 0;
    do {
        pos = str.find(src, pos);
        if(pos == string::npos) { break; }
        str.replace(pos, src.size(), dest);
        pos += dest.size();
        nTime++;
    } while (times == 0 || nTime < times);
    return nTime;
}

size_t StrUtil::replace(string& str, const char* src, size_t szSrc, const char* dest, size_t szDest, size_t times) {
    string tmpSrc(src, szSrc), tmpDest(dest, szDest); 
    return replace(str, tmpSrc, tmpDest, times);
}

bool StrUtil::convertEncode(const string& fromCode,const string& fromStr,const string& toCode,string& toStr)
{
    char * pin=(char *)fromStr.c_str();
    char * pout=NULL;
    size_t inlen=fromStr.size();
    size_t outlen=inlen*2;
    iconv_t ico=(iconv_t)-1;

    char * ptemp=(char*)calloc(outlen+1,sizeof(char));
    if(!(pout=ptemp))
    {
        return false;
    }

    if((ico=iconv_open(toCode.c_str(),fromCode.c_str()))==(iconv_t)-1)
    {
        free(ptemp);
        return false;
    }

    if (iconv(ico,&pin,&inlen,&pout,&outlen)==(size_t)-1)
    {
        iconv_close(ico);
        free(ptemp);
        return false;
    }
    toStr=string(ptemp);
    iconv_close(ico);
    free(ptemp);
    return true;
}
