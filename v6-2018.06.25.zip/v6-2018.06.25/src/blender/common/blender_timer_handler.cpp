#include "blender_timer_handler.h"
#include <boost/bind.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp> 
#include <iostream>

using namespace blender;

BlenderTimerHandler::BlenderTimerHandler() 
    : _timer(BlenderTimerHanderManager::instance()->io_service())
{
    BlenderTimerHanderManager::instance()->reg_timer(this);
}


BlenderTimerHandler::~BlenderTimerHandler()
{
    _timer.cancel();
}


void BlenderTimerHandler::timeout(const boost::system::error_code& e)
{
    if ( !e )
    {
        if ( timeout_handle() )
        {
            restart();
        }
    }
}

void BlenderTimerHandler::restart()
{
    _timer.expires_from_now(boost::posix_time::milliseconds(interval_msecs()));
    _timer.async_wait(
        boost::bind(&BlenderTimerHandler::timeout, shared_from_this(),
            boost::asio::placeholders::error
            ));
}


void BlenderTimerHandler::stop()
{
    _timer.cancel();
}


BlenderTimerHanderManager* BlenderTimerHanderManager::instance() 
{
    static BlenderTimerHanderManager manager;
    return &manager;
}


BlenderTimerHanderManager::BlenderTimerHanderManager()
{
}

    
void BlenderTimerHanderManager::reg_timer(BlenderTimerHandler *handler) 
{
    _handler_list.push_back(BlenderTimerHandler_ptr(handler));
}

void BlenderTimerHanderManager::start()
{
    boost::asio::io_service::work work(_io_service);
    _timer_thread.reset(new boost::thread(
                    boost::bind(&boost::asio::io_service::run, &_io_service)));
        
    for ( std::list<BlenderTimerHandler_ptr >::iterator it = _handler_list.begin(); it != _handler_list.end(); it++ )
    {
        (*it)->restart();
    }
}

void BlenderTimerHanderManager::stop()
{
    for ( std::list<BlenderTimerHandler_ptr >::iterator it = _handler_list.begin(); it != _handler_list.end(); it++ )
    {
        (*it)->stop();
    } 
}


