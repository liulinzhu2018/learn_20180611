#ifndef BLENDER_HEADER_H_
#define BLENDER_HEADER_H_
//#include "util/simple_log.h"
#include <unistd.h>
#include <pthread.h>
#include "bld_global.h"
#include "blender_logger.h"
#include "jdsz_logtrace_manager.h"
using namespace jdsz_logtrace;

#if (USE_NOBLOCK_QUEUE == 1)
#include "common/nolockqueue.h"
typedef blender::NoLockTaskQueue  BlenderTaskQueue;
#else
#include "queue.h"
typedef util::TaskQueue  BlenderTaskQueue;
#endif

#define BLENDER_BEGIN namespace blender { 
#define BLENDER_END }

#ifndef S_DSC
#define S_DSC(des) 1
#endif

#ifndef BLD_QP_THRIFT_VALID
//#define BLD_QP_THRIFT_VALID
#endif
#ifndef BLD_QP_AB_VALID
//#define BLD_QP_AB_VALID
#endif

enum BLENDER_MSG_TYPE{
    BLENDER_MSG_CLIENT = 0,     //前端消息
    BLENDER_MSG_QP,      //QP
    BLENDER_MSG_MERGER,      //Merger返回的消息
    BLENDER_MSG_EXT,
    BLENDER_MSG_NUM,
};

enum
{
    BLD_SERVICE_WORK = 0, //工作服务
    BLD_SERVICE_CMD = 1,  //命令服务
};


#define BLD_STAT_QP_LATENCY             "search.blender.qp.latency"
#define BLD_STAT_QP_REQ_QPS             "search.blender.qp"
#define BLD_STAT_QP_REQ                 "search.blender.qp.req"
#define BLD_STAT_QP_ACT_LATENCY         "search.blender.qp.act_latency"
#define BLD_STAT_QP_ERROR_COUNT         "search.blender.qp.req_error_count"
#define BLD_STAT_QP_SEND_FAILED_RETRY   "search.blender.qp.send_failed.retry"
#define BLD_STAT_QPAB_LATENCY           "search.blender.qpab.latency"
#define BLD_STAT_QPAB_REQ_QPS           "search.blender.qpab"
#define BLD_STAT_QPAB_REQ               "search.blender.qpab.req"
#define BLD_STAT_QPAB_ACT_LATENCY       "search.blender.qpab.act_latency"
#define BLD_STAT_QPAB_ERROR_COUNT       "search.blender.qpab.req_error_count"
#define BLD_STAT_QPAB_SEND_FAILED_RETRY "search.blender.qpab.send_failed.retry"
#define BLD_STAT_OP_LATENCY             "search.blender.op.latency"
#define BLD_STAT_OP_REQ_QPS             "search.blender.op"
#define BLD_STAT_OP_RESP_NODATA_COUNT   "search.blender.op.resp_nodata_count"
#define BLD_STAT_OP_ERROR_COUNT         "search.blender.op.error"
#define BLD_STAT_AD_ERROR         		"search.blender.ad.error"
#define BLD_STAT_PM_ERROR         		"search.blender.pm.error"
#define BLD_STAT_SP_ERROR  				"search.blender.sp.error"
#define BLD_STAT_ARTC_ERROR       		"search.blender.artc.error"
#define BLD_STAT_MG_LATENCY             "search.blender.mg.latency"
#define BLD_STAT_MG_REQ_QPS             "search.blender.mg"
#define BLD_STAT_MG_REQ                 "search.blender.mg.req"
#define BLD_STAT_MG_RESP_NODATA         "search.blender.mg.resp_nodata"
#define BLD_STAT_MG_RESP_NODATA_COUNT   "search.blender.mg.resp_nodata_count"
#define BLD_STAT_MG_RESP_NOPRODUCT      "search.blender.mg.resp_noproduct"
#define BLD_STAT_MG_RESP_NOPRODUCT_NORMAL   "search.blender.mg.resp_noproduct_normal"
#define BLD_STAT_MG_PRODUCT_PARSE_ERR   "search.blender.mg.resp_product.parse_error"
#define BLD_STAT_MG_ERROR_COUNT         "search.blender.mg.error_count"
#define BLD_STAT_MG_SEND_FAILED         "search.blender.mg.send.failed"
#define BLD_STAT_MG_SEND_FAILED_RETRY   "search.blender.mg.send_failed.retry"
#define BLD_STAT_TOTAL_LATENCY          "search.blender.latency"
#define BLD_STAT_REQ_QPS                "search.blender"
#define BLD_STAT_REQ                    "search.blender.req"
#define BLD_STAT_ERROR_COUNT            "search.blender.error_count"
#define BLD_STAT_RESP_ERROR             "search.blender.resp.error"
#define BLD_STAT_RESP_OK             "search.blender.resp.ok"
#define BLD_STAT_RESP_CODE             "search.blender.resp.code"
#define BLD_STAT_INVALID_REQ             "search.blender.req.invalid"

#define BLD_STAT_REENQUEUE_RESP_COUNT            "search.blender.requeue.resp_count"

#define BLD_STAT_SYNC_QUEUE_WAIT_LATENCY        "search.blender.thrift.queue_wait.latency"
#define BLD_STAT_TASK_QUEUE_SIZE        "search.blender.task.queue"
#define BLD_STAT_SYNC_QUEUE_SIZE        "search.blender.thrift.queue"

#define BLD_STAT_TASK_QUEUE_WAIT_LATENCY  "search.blender.task.queue_wait.latency"

#define BLD_STAT_SESSION_LOCK_LATENCY   "search.blender.session_lock.latency"

#define BLD_STAT_JIMDB_REQ				"search.blender.jimdb"
#define BLD_STAT_JIMDB_REQ_HIT			"search.blender.jimdb.hit"
#define BLD_STAT_THRIFT_REQ				"search.blender.thrift"
#define BLD_STAT_LOCALCACHE_REQ         "search.blender.localcache"

#define BLD_STAT_CACHE_HIT_RATIO        "search.blender.cache.hit"
#define BLD_STAT_CACHE_SETFAIL_COUNT    "search.blender.cache_set_fail_count"

#define BLD_STAT_SCENE_HIT_RATIO        "search.blender.scene.hit"
#define BLD_STAT_SCENE_GET_COUNT        "search.blender.scene.req_count"
#define BLD_STAT_SCENE_GET_LATENCY      "search.blender.scene.req_latency"

#define BLD_STAT_SCENE2_HIT_RATIO        "search.blender.scene2.hit"
#define BLD_STAT_SCENE2_GET_COUNT        "search.blender.scene2.req_count"
#define BLD_STAT_SCENE2_GET_LATENCY      "search.blender.scene2.req_latency"

#define BLD_STAT_QP_CACHE_HIT_RATIO        "search.blender.qp_cache.hit"
#define BLD_STAT_QP_CACHE_SETFAIL_COUNT    "search.blender.qp_cache_set_fail_count"

#define BLD_STAT_QP_DISABLE_FIELD_COUNT "search.blender.qp_disable_field_count"

#define BLD_STAT_REDPKG_REQ             "search.blender.req_packets"
#define BLD_STAT_REDPKG_JIMDB_OK        "search.blender.req_packets.jimdb_ok"
#define BLD_STAT_REDPKG_PARSE_ERR       "search.blender.req_packets.parse_error"
#define BLD_STAT_REDPKG_REQ_HIT_RATIO   "search.blender.req_packets.hit"

#define BLD_STAT_CALLER_COUNT           "search.blender.caller"

//second report:avg,max,min,tp99
#define BLD_STAT_HTTP_CONNECTIONS  "search.blender.flowctrl.http.connections"
#define BLD_STAT_MG_REQUESTING     "search.blender.mg.requesting"
#define BLD_STAT_FLOWCTRL_REPLAY_COUNT  "search.blender.flowctrl.reply_null"
#define BLD_STAT_TASK_ENQUEUE_ERR_COUNT        "search.blender.task.enqueue_err"
#define BLD_STAT_FLOWCTRL_LIMIT_COUNT  "search.blender.flowctrl.limit_over"

#define BLD_STAT_PERSONALIZE_WHITELIST_KEY_HIT_COUNT "search.blender.hit.whitelist_key"

#define BLD_STAT_MTEST_DIM       "search.blender.mtest"
#define BLD_STAT_REL_IP_ERR_CNT       "search.blender.relip.err"

#define UMP_BLENDER_RUNNING_CALL       "search.blender.running.call"

#ifdef DEBUG
#define BLD_TRACE(fm, args...)\
    printf("%s:%d "fm"\n", __FILE__,__LINE__,##args);
#else
#define BLD_TRACE(fm, args...)
#endif

#endif
