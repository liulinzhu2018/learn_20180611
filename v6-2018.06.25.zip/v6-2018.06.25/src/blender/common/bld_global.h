#ifndef _BLD_GLOBAL_
#define _BLD_GLOBAL_

//#include "common_libs.h"
#include <vector>
#include <set>
#include <map>
//#include "log.h"
//#include "singleton.h"
#include <boost/lexical_cast.hpp> 
//#include "dd_character.h"
#include <glog/logging.h>
#include "log_trace.h"

#define CONSOLE_OUTPUT 1
#define DD_INT_NULL 0xdeadbeef

using namespace std;
using namespace boost;

#ifndef gettidv1
#include <sys/syscall.h> 
#define gettidv1(args...) (long int)syscall(__NR_gettid)
#define gettidv2(args...) (long int)syscall(SYS_gettid)
#endif

namespace blender
{
class BlenderAnalysisData;
vector<string> GetStrings(
        const string& stringList, const string& splitWord);

uint64_t currentUSec();
void Normalize(const std::string& in, std::string& out);

void session_report(int64_t cost_ms, bool isok, BlenderAnalysisData *analysisData = NULL);

std::string ump2tag(const std::string &client = "", const std::string &req_type = "");

//bussiness report key
void report_bussiness(const std::string &key, bool isok, const std::string &tag = "");

int checkFiltTypeInBlacklist(const std::pair<std::string, std::string> &kv, std::multimap<std::string,std::string> &blacklist);
int checkFiltTypeInWhitelist(const std::pair<std::string, std::string> &kv, std::multimap<std::string,std::string> &whitelist);

template <class T1>
T1 cast2number(std::string t)
{
    T1 _d = 0;
    try
    {
        _d = boost::lexical_cast<T1>(t);
    }catch(...){}
    return _d;
}


template <class Type>
std::string cast2string(Type t)
{
    return boost::lexical_cast<string>(t);
}


};


#endif
